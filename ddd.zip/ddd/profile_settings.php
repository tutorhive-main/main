<?php 
error_reporting(0);
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use Aws\S3\S3Client;
use Aws\S3\Exception\S3Exception;
require '../../vendor/autoload.php';
ob_start();
ini_set('session.gc_maxlifetime', '28800');
session_start();
if( !isset($_SESSION['username_name']))
 {
   header("Location: login.php");
 }
include("common/connection.php");
 $_SESSION['ggg_userid'] = "";
         $_SESSION['ggg_firstn'] = "";
         $_SESSION['ggg_lastn'] = "";
         $_SESSION['ggg_email'] = "";
		 $_SESSION['ggg_name'] = "";



 $s3Client = new S3Client([
    'region' => 'eu-west-2',
    'version' => 'latest',
    'credentials' => [
        'key'  => "AKIA2KHLYWYGMG6UVH5P",
        'secret' => "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"
    ]
]);
$bucketName = 'qul-documents';

if(isset($_POST['submit'])){
   $data = [
    'DOCSTATUS' => 1,
    'USER_ID' => $_SESSION['tutor_admin_id'],
	'LAST_UPDATE' => $tutor_date,
];
$sqlupdate = "UPDATE tutorhive_users SET DOCSTATUS=:DOCSTATUS, LAST_UPDATE=:LAST_UPDATE WHERE USER_ID=:USER_ID";
$stmtuodate= $tutor_db->prepare($sqlupdate);
$stmtuodate->execute($data);
header("Location:profile_settings.php?succ=doc");
exit();
}
if(isset($_POST['submit1'])){
    if ((($_FILES["thumbimg_file"]["type"] == "image/jpeg")
|| ($_FILES["thumbimg_file"]["type"] == "image/png")
|| ($_FILES["thumbimg_file"]["type"] == "image/pjpeg") || ($_FILES["thumbimg_file"]["type"] == "video/mp4")))
  {

  if ($_FILES["thumbimg_file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["thumbimg_file"]["error"] . "<br />";
    }
  else
    {
    echo "Upload: " . $_FILES["thumbimg_file"]["name"] . "<br />";
    echo "Type: " . $_FILES["thumbimg_file"]["type"] . "<br />";
    echo "Size: " . ($_FILES["thumbimg_file"]["size"] / 1024) . " Kb<br />";
    echo "Temp file: " . $_FILES["thumbimg_file"]["tmp_name"] . "<br />";
	
	$image_name = $_FILES['thumbimg_file']['name'];
        $filename = basename($_FILES['thumbimg_file']['name']);
        $ext = substr($filename, strrpos($filename, '.') + 1);
        $ext = strtolower($ext);
        $split=explode(".",$image_name);
        $timestamp=rand(1,99999);
        //$image_name=$split[0].".".$ext;
        $image_name=$split[0].$timestamp.".".$ext;
        $image_name=str_replace(" ","",$image_name);
    if (file_exists("assets/issueimage/" . $image_name))
      {
	  
       $image_name . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES["thumbimg_file"]["tmp_name"],
      "assets/issueimage/" . $image_name);
	 
       "Stored in: " . "assets/issueimage/" . $image_name;
      }
    }
  }
else
  {
  echo "Invalid file";
  }
 
$imagename = $_POST['imagename'];
$firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$fullname= $_POST['firstname'].' '.$_POST['lastname'];
$mobileno = $_POST['mobileno'];
 $gstatus = $_POST['gstatus'];
$dateof = $_POST['dateof'];
$monthof = $_POST['monthof'];
$yearof = $_POST['yearof'];
$mobileapp = $_POST['mobileapp'];
$hobbies = $_POST['hobbies'];
$hobbies1 = $_POST['hobbies1'];
$hobbies2 = $_POST['hobbies2'];
//$refcode = $_POST['refcode'];
$radius = $_POST['radius'];
$ts_bio = $_POST['ts_bio'];

$addresshiv1 = $_POST['addresshiv1'];
$latitudehiv1 = $_POST['latitudehiv1'];
$longitudehiv1 = $_POST['longitudehiv1'];
$pincodehiv1 = $_POST['pincodehiv1'];


$dateofbirth=$yearof."-".$monthof."-".$dateof;


if($lessons!=""){
$less=$lessons2;
}else {
$less=$lessons1;
}

 $data1 = [  
    'IMG1' => $image_name,
    'FIRST_NAME' => $firstname,
    'LAST_NAME' => $lastname,  
    'FULL_NAME' => $fullname, 
    'USER_MOBILE' => $mobileno,
    'USER_EMAIL' => $mobileapp,   
    'DATEOF' => $dateof,
    'MONTHOF' => $monthof,   
    'YEAROF' => $yearof,
	'DATE_OF_BIRTH' => $dateofbirth,
    'GENDER' => $gstatus,   
	'PROFILE_PIC' => $imagename,
	'RADIUS' => $radius,
	'ADDRESSHIV' => $addresshiv1,
	'LATITUDE' => $latitudehiv1,
	'LONGITUDE' => $longitudehiv1,
	'PINCODE' => $pincodehiv1,
	'TEACH_STYLE_BIO' => $ts_bio,
	'PROFILE_STATUS' => 1,
    'USER_ID' => $_SESSION['tutor_admin_id'],
	'LAST_UPDATE' => $tutor_date,
]; 
$sqlupdate1 = "UPDATE tutorhive_users SET FIRST_NAME=:FIRST_NAME, LAST_NAME=:LAST_NAME,  FULL_NAME=:FULL_NAME, USER_MOBILE=:USER_MOBILE, USER_EMAIL=:USER_EMAIL, DATEOF=:DATEOF, MONTHOF=:MONTHOF, YEAROF=:YEAROF, DATE_OF_BIRTH=:DATE_OF_BIRTH, GENDER=:GENDER, PROFILE_PIC=:PROFILE_PIC, RADIUS=:RADIUS, ADDRESSHIV=:ADDRESSHIV, LATITUDE=:LATITUDE, LONGITUDE=:LONGITUDE, PINCODE=:PINCODE, PROFILE_STATUS=:PROFILE_STATUS, TEACH_STYLE_BIO=:TEACH_STYLE_BIO, IMG1=:IMG1, LAST_UPDATE=:LAST_UPDATE  WHERE USER_ID=:USER_ID";
$stmtuodate1= $tutor_db->prepare($sqlupdate1);
$stmtuodate1->execute($data1);

if($_SESSION['admin_type']=="Tutor"){
$userquery = $tutor_db->prepare("SELECT TUTORBVMAIL FROM tutorhive_users WHERE USER_ID=:USER_ID AND TUTORBVMAIL=0");
$userquery->execute(['USER_ID' => $_SESSION['tutor_admin_id']]); 
}else {
$userquery = $tutor_db->prepare("SELECT STUDENTEMAILL FROM tutorhive_users WHERE USER_ID=:USER_ID AND STUDENTEMAILL=0");
$userquery->execute(['USER_ID' => $_SESSION['tutor_admin_id']]); 
}

$mailslagCount = $userquery->rowCount();
if($mailslagCount>0){

$imagename=$SEVER_NAME."/assets/images/tutorhive-logo.png";
$insta=$SEVER_NAME."/assets/images/instagramIconf.png";
$linkedin=$SEVER_NAME."/assets/images/ic-linkedin.png";

$usernameapp= $firstname;
 $useremailapp=$mobileapp;

if($_SESSION['admin_type']=="Tutor"){			
$subject = ' WELCOME TO TUTORHIVE! ';
           $bodyHtml ='
    <body style="margin:0px;">
<table>
                                <tr>
                                    <td style="padding:0px" valign="top"></td>
                                    <td  width="600" style="  display: block !important; max-width: 600px !important; clear: both !important;" valign="top">
                                        <div>
                                            <table  width="100%" cellpadding="0" cellspacing="0" style="border: 25px solid #ffd142;border-radius: 5px;background: #FFD142;">
                                                <tr>
                                                    <td  style="background:#fff;border-radius: 5px;" align="center" valign="top">
                                                        <table width="100%" cellpadding="0" cellspacing="0">
                                                            <tr>
                                                                <td style="padding: 20px 10px;border-bottom: 1px solid #ffd142;">
                                                                    <a href="'.$SEVER_NAME.'"><img src="'.$imagename.'" style="height: 50px; margin-left: auto; margin-right: auto; display:block;"></a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td  style="padding: 0 0 20px;" valign="top">
                                                                    <h2  style="font-family:Helvetica,Arial,sans-serif;font-size: 24px; line-height: 1.2em; font-weight: 600; text-align: center;padding-top:20px" align="center"><span style="color: #FFD142; font-weight: 700;">WELCOME </span> TO TUTORHIVE!</h2>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td  style="padding: 0 0 20px;" align="center" valign="top">
                                                                    <table  style="width: 90%;">
                                                                        <tr>
                                                                            <td style="padding: 5px 0;" valign="top">
                                                                                <table  cellpadding="0" cellspacing="0" style="width: 100%;">
                                                                                    <tr>
                             <td style="font-weight:bold;font-family:Helvetica,Arial,sans-serif; font-size: 14px; vertical-align: top; margin: 0; padding: 10px 0;" valign="top">
                                <p >Hey  '.$usernameapp.', welcome to the Hive!</p>
								<p >We hope you are excited to start your teaching journey with us.</p>
								 <p >We started TutorHive to help both Tutors and Students gain more from private tuition. To ensure this, our Worker Bees are busy buzzing through our new tutors as quickly as possible.</p>
								 
								 <p >If you have any questions, please do not hesitate to reach out to the TutorHive Team at helperbee@tutorhive.co.uk</p>
								 <p >All the best,</p>
								  <p ><span style="color:#ffd142;">TutorHive Team</span></p>
								   <p style="text-align: center;">
		<a href="'.$SEVER_NAME.'" style="background: #FFD142;color: #000;text-decoration: none;padding: 10px 10px 8px 10px;font-size: 20px;border-radius: 5px;">tutorhive.co.uk</a>
	
		<a href="https://www.instagram.com/tutor.hive/" style="background: #FFD142;color: #000;text-decoration: none;padding: 17px 8px 9px 8px;border-radius: 5px;"><img src="'.$insta.'"></a>
		<a href="https://www.linkedin.com/uas/login?session_redirect=%2Fcompany%2F34928667" style="background: #FFD142;color: #000;text-decoration: none;padding: 17px 8px 9px 8px;border-radius: 5px;"><img src="'.$linkedin.'"></a>
		</p>  
		<p ><span style="color:#ffd142;">#BeeTheChange</span></p>
							
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;color: #FFD142;font-family:Helvetica,Arial,sans-serif;padding: 20px 10px;border-top: 1px solid #ffd142;" align="center" valign="top">&copy; Copyright'.date("Y").' - TutorHive</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </table>                                            
                                        </div>
                                    </td>
                                    <td style="font-family:Helvetica,Arial,sans-serif; font-size: 14px; vertical-align: top; margin: 0;" valign="top"></td>
                                </tr>
                            </table> </body>';
							

$recipient = $useremailapp;
$mail = new PHPMailer(true);

try {
    // Specify the SMTP settings.
    $mail->isSMTP();
    $mail->setFrom($sender, $senderName);
    $mail->Username   = $usernameSmtp;
    $mail->Password   = $passwordSmtp;
    $mail->Host       = $host;
    $mail->Port       = $port;
    $mail->SMTPAuth   = true;
    $mail->SMTPSecure = 'tls';
  
    // Specify the message recipients.
    $mail->addAddress($recipient);
    // You can also add CC, BCC, and additional To recipients here.

    // Specify the content of the message.
    $mail->isHTML(true);
    $mail->Subject    = $subject;
    $mail->Body       = $bodyHtml;
    $mail->Send();
   // echo "Email sent!" , PHP_EOL;
} catch (phpmailerException $e) {
    echo "An error occurred. {$e->errorMessage()}", PHP_EOL; //Catch errors from PHPMailer.
} catch (Exception $e) {
    echo "Email not sent. {$mail->ErrorInfo}", PHP_EOL; //Catch errors from Amazon SES.
}
 $data = [
    'TUTORBVMAIL' => 1,
    'USER_ID' => $_SESSION['tutor_admin_id'],
];
$sqlupdate = "UPDATE tutorhive_users SET TUTORBVMAIL=:TUTORBVMAIL WHERE USER_ID=:USER_ID";
$stmtuodate= $tutor_db->prepare($sqlupdate);
$stmtuodate->execute($data);

}else{
 $subject ='WELCOME TO THE HIVE';

           $bodyHtml ='
    <body style="margin:0px;">
<table>
                                <tr>
                                    <td style="padding:0px" valign="top"></td>
                                    <td  width="600" style="  display: block !important; max-width: 600px !important; clear: both !important;" valign="top">
                                        <div>
                                            <table  width="100%" cellpadding="0" cellspacing="0" style="border: 25px solid #ffd142;border-radius: 5px;background: #ffd142;">
                                                <tr>
                                                    <td  style="background:#fff;border-radius: 5px;" align="center" valign="top">
                                                        <table width="100%" cellpadding="0" cellspacing="0">
                                                            <tr>
                                                                <td style="padding: 20px 10px;border-bottom: 1px solid #ffd142;">
                                                                    <a href="'.$SEVER_NAME.'"><img src="'.$imagename.'" style="height: 50px; margin-left: auto; margin-right: auto; display:block;"></a>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td  style="padding: 0 0 20px;" valign="top">
                                                                    <h2  style="font-family:Helvetica,Arial,sans-serif;font-size: 24px; line-height: 1.2em; font-weight: 600; text-align: center;padding-top:20px" align="center"><span style="color: #ffd142; font-weight: 700;">WELCOME </span> TO THE HIVE!</h2>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td  style="padding: 0 0 20px;" align="center" valign="top">
                                                                    <table  style="width: 90%;">
                                                                        <tr>
                                                                            <td style="padding: 5px 0;" valign="top">
                                                                                <table  cellpadding="0" cellspacing="0" style="width: 100%;">
                                                                                    <tr>
                             <td style="font-weight:bold;font-family:Helvetica,Arial,sans-serif; font-size: 14px; vertical-align: top; margin: 0; padding: 10px 0;" valign="top">
                                <p >Hey  '.$usernameapp.', welcome to the Hive!</p>
								<p >We hope you are excited to start your learning journey with us.</p>
								 <p > Don&#900;t wait to start learning and earning today. If you have any questions, please do not hesitate to reach out to the TutorHive Team at helperbee@tutorhive.co.uk</p>
								 <p >All the best,</p>
								  <p style="color:#ffd142;">TutorHive Team</p>
								   <p style="text-align: center;">
		<a href="'.$SEVER_NAME.'" style="background: #FFD142;color: #000;text-decoration: none;padding: 10px 10px 8px 10px;font-size: 20px;border-radius: 5px;">tutorhive.co.uk</a>
	
		<a href="https://www.instagram.com/tutor.hive/" style="background: #FFD142;color: #000;text-decoration: none;padding: 17px 8px 9px 8px;border-radius: 5px;"><img src="'.$insta.'" ></a>
		<a href="https://www.linkedin.com/uas/login?session_redirect=%2Fcompany%2F34928667" style="background: #FFD142;color: #000;text-decoration: none;padding: 17px 8px 9px 8px;border-radius: 5px;"><img src="'.$linkedin.'" ></a>
		</p> 
		<p style="color:#ffd142;">#BeeTheChange</p>
                                                                                        </td>
                                                                                    </tr>
                                                                                </table>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </td>
                                                            </tr>
                                                            <tr>
                                                                <td style="font-weight:bold;color: #ffd142;font-family:Helvetica,Arial,sans-serif;padding: 20px 10px;border-top: 1px solid #ffd142;" align="center" valign="top">&copy; Copyright'.date("Y").' - TutorHive</td>
                                                            </tr>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </table>                                            
                                        </div>
                                    </td>
                                    <td style="font-family:Helvetica,Arial,sans-serif; font-size: 14px; vertical-align: top; margin: 0;" valign="top"></td>
                                </tr>
                            </table> </body>';

 
$recipient = $useremailapp;
$mail = new PHPMailer(true);

try {
    // Specify the SMTP settings.
    $mail->isSMTP();
    $mail->setFrom($sender, $senderName);
    $mail->Username   = $usernameSmtp;
    $mail->Password   = $passwordSmtp;
    $mail->Host       = $host;
    $mail->Port       = $port;
    $mail->SMTPAuth   = true;
    $mail->SMTPSecure = 'tls';
  
    // Specify the message recipients.
    $mail->addAddress($recipient);
    // You can also add CC, BCC, and additional To recipients here.

    // Specify the content of the message.
    $mail->isHTML(true);
    $mail->Subject    = $subject;
    $mail->Body       = $bodyHtml;
    $mail->Send();
   // echo "Email sent!" , PHP_EOL;
} catch (phpmailerException $e) {
    echo "An error occurred. {$e->errorMessage()}", PHP_EOL; //Catch errors from PHPMailer.
} catch (Exception $e) {
    echo "Email not sent. {$mail->ErrorInfo}", PHP_EOL; //Catch errors from Amazon SES.	
}
$data = [
    'STUDENTEMAILL' => 1,
    'USER_ID' => $_SESSION['tutor_admin_id'],
];
$sqlupdate = "UPDATE tutorhive_users SET STUDENTEMAILL=:STUDENTEMAILL WHERE USER_ID=:USER_ID";
$stmtuodate= $tutor_db->prepare($sqlupdate);
$stmtuodate->execute($data);
}
}
header("Location:profile_settings.php?succ=profile");
exit();
}
if(isset($_POST['submit2'])){
$teach_style = $_POST['teach_style'];
$teach_style1 = $_POST['teach_style1'];
$teach_style2 = $_POST['teach_style2'];

if($teach_style!=""){
$teach=$teach_style2;
}else {
$teach=$teach_style1;
}

$learn_style = $_POST['learn_style'];
$learn_style1 = $_POST['learn_style1'];
$learn_style2 = $_POST['learn_style2'];

if($learn_style!=""){
$learn=$learn_style2;
}else {
$learn=$learn_style1;
}


 $data2 = [
     'TEACH_STYLE' => $teach,
	'LEARN_STYLE' => $learn,
    'EDUACTIONSTATUS' => 1,
    'USER_ID' => $_SESSION['tutor_admin_id'],
	'LAST_UPDATE' => $tutor_date,
];
$sqlupdate = "UPDATE tutorhive_users SET TEACH_STYLE=:TEACH_STYLE, LEARN_STYLE=:LEARN_STYLE, EDUACTIONSTATUS=:EDUACTIONSTATUS, LAST_UPDATE=:LAST_UPDATE WHERE USER_ID=:USER_ID";
$stmtuodate= $tutor_db->prepare($sqlupdate);
$stmtuodate->execute($data2);
header("Location:profile_settings.php?succ=educat");
exit();
}
if(isset($_POST['submit4'])){
 $number = $_POST['number'];
 $expdate = $_POST['sortcode'];
 $cvc = $_POST['ibannumber'];
 $acounrname = $_POST['acounrname'];
 $data3 = [
     'CARDNO' => $number,
	'EXPDATE' => $expdate,
    'CVC' => $cvc,
	'CARDHOLDER' => $acounrname,
	'TUTOPAY_STATUS' => 1,
    'USER_ID' => $_SESSION['tutor_admin_id'],
];
$sqlupdate = "UPDATE tutorhive_users SET CARDNO=:CARDNO, EXPDATE=:EXPDATE, CVC=:CVC, CARDHOLDER=:CARDHOLDER, TUTOPAY_STATUS=:TUTOPAY_STATUS WHERE USER_ID=:USER_ID";
$stmtuodate= $tutor_db->prepare($sqlupdate);
$stmtuodate->execute($data3);
header("Location:profile_settings.php?succ=paymt");
exit();
}
?>
<!doctype html>
<html lang="en" dir="ltr">

    <head>
        <meta charset="utf-8" />
        <title>TutorHive - Admin Dashboard </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="TutorHive - Admin Dashboard" />
        <meta name="keywords" content="TutorHive - Admin Dashboard" />
        <meta name="author" content="Shreethemes" />
        <meta name="email" content="support@shreethemes.in" />
        <meta name="website" content="https://shreethemes.in" />
        <meta name="Version" content="v4.2.0" />

         <?php include('common/headerlinks.php');?>
         <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css" integrity="sha512-mR/b5Y7FRsKqrYZou7uysnOdCIJib/7r5QeJMFvLNHNhtye3xJp1TdJVPLtetkukFn227nKpXD9OjUc09lx97Q==" crossorigin="anonymous"
  referrerpolicy="no-referrer" />
	<link rel="stylesheet" href="https://unpkg.com/dropzone/dist/dropzone.css" />
		<link href="https://unpkg.com/cropperjs/dist/cropper.css" rel="stylesheet"/>
		<script src="https://unpkg.com/dropzone"></script>
		<script src="https://unpkg.com/cropperjs"></script>
         <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
         
        
		 <style>
		 
.ph{width: 100%}
		 nav > .nav.nav-tabs{

  border: none;
    color:#fff;
    background:#272e38;
    border-radius:0;

}
nav > div a.nav-item.nav-link,
nav > div a.nav-item.nav-link.active
{
  border: none;
    padding: 18px 25px;
    color:#fff;
    background:#000;
    border-radius:0;
}

nav > div a.nav-item.nav-link.active:after
 {
  content: "";
  position: relative;
  bottom: -60px;
  left: -10%;
  border: 15px solid transparent;
  border-top-color: #ffd85d ;
}
.tab-content{
  background: #fdfdfd;
    line-height: 25px;
    border: 1px solid #ddd;
    border-top:5px solid #ffd85d;
    border-bottom:5px solid #ffd85d;
    padding:30px 25px;
}

nav > div a.nav-item.nav-link:hover,
nav > div a.nav-item.nav-link:focus
{
  border: none;
    background: #ffd85d;
    color:#000;
    border-radius:0;
    transition:background 0.20s linear;
}

.image_area {
		  position: relative;
		}

		img {
		  
		  	max-width: 100%;
		}

		.preview {
		display:none!important;
  			overflow: hidden;
  			width: 130px; 
  			height: 130px;
  			margin: 10px;
  			border: 1px solid red;
		}

		.modal-lg{
  			max-width: 1000px !important;
		}

		.overlay {
		  position: absolute;
		  bottom: 10px;
		  left: 0;
		  right: 0;
		  background-color: rgba(255, 255, 255, 0.5);
		  overflow: hidden;
		  height: 0;
		  transition: .5s ease;
		  width: 100%;
		}

		.image_area .overlay {
		  height: 50%;
		  cursor: pointer;
		}
		
		.loader {
  height:175px;
  width: 175px;
  border-radius: 50%;
  border: 10px solid orange;
  border-top-color: #002147;
  box-sizing: border-box;
  background: transparent;
  animation: loading 1s linear infinite;
}

@keyframes loading {
  0% {
    transform: rotate(0deg);
  }
  0% {
    transform: rotate(360deg);
  }
}
.popwithdstyle{
    max-width: 60%;
}
popwithdstyle1{
 max-width: 35%;
}

.bootstrap-select:not([class*=col-]):not([class*=form-control]):not(.input-group-btn){
         width: 100%;
    border: 1px solid #ffd85d;
    background: #fff;
}
.field-icon {
    float: right;
    margin-top: -38px;
    margin-right: 15px;
}

.valid {
  color: green;
  padding: 0px 10px;
}
.valid:before {
  position: relative;
  content: "✔";
}
.invalid {
  color: red;
  padding: 0px 10px;
}
.invalid:before {
  position: relative;
  content: "✖";
}
.bootstrap-select .bs-ok-default:after{
    color:#000;
}

._3mZgT {
    display: flex;
    position: relative;
        margin-bottom: 10px;
}
.Al5GE {
    position: relative;
    flex: 1;
}
._2oQ4_ {
    padding: 0 5px;
    border: 1px solid #bebfc5;
    box-shadow: none;
}
._3Um38 {
    border: 1px solid #ffd85d;
    padding: 0;
    display: block;
    position: relative;
    transform: translateZ(0);
}
._3BIgv {
    height: 58px!important;
    line-height: 28px!important;
    padding-top: 0!important;
    padding-left: 15px!important;
    padding-right: 160px!important;
    caret-color: #fc8019;
    font-size: 14px!important;
   
}
._381fS {
    background-color: #fff;
    
    border: none;
    outline: none;
   
    width: 100%;
   
    margin: 0;
    padding: 0 20px;
   
    box-shadow: none;
    box-sizing: border-box;
    border-radius: 0;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
   
}
._2EeI1 {
    position: absolute;
    right: 20px;
    bottom: 26px;
    font-size: 14px;
    font-weight: 500;
    color: #5d8ed5;
    transform: translateZ(0);
    cursor: pointer;
    will-change: transform;
    transition: .2s ease;
}
._2tL9P {
    font-size: 12px;
    font-weight: 500;
    color: #7e808c;
   transform: translateY(-70%);
}
._1Cvlf {
    position: absolute;
    left: 0;
    bottom: 24px;
    padding-left: 20px;
    line-height: 20px;
   
    cursor: text;
    transition: .2s ease;
    width: 100%;
   
    will-change: transform,color,font-size;
    pointer-events: none;
  
}
._1fiQt {
    color: #000;
}
._1fiQt, .NqZN6 {
    position: absolute;
    right: 10px;
    top: 10px;
    padding: 12px 10px;
    font-weight: 800;
    font-size: 14px;
    cursor: pointer;
    letter-spacing: -.35px;
}
._25lQg {
    margin-right: 6px;
    top: 2px;
    position: relative;
}
[class*=" icon-"], [class^=icon-] {
    font-family: icomoon;
    speak: none;
    font-style: normal;
    font-weight: 400;
    font-variant: normal;
    text-transform: none;
    line-height: 1;
    -webkit-font-smoothing: antialiased;
}
._3iFC5 {
    
    text-decoration: none;
    cursor: pointer;
    display: inline-block;
    text-align: center;
    border: none;
    color: #fff;
    background-color: #fc8019;
    box-shadow: 0 1px 3px 0 rgb(0 0 0 / 12%);
    right: 0;
    height: 60px;
    line-height: 60px;
    width: 80px;
    font-size: 14px;
    font-weight: 700;
    letter-spacing: .53px;
    padding: 0;
}

._3iFC5 {
    position: absolute;
    z-index: 1;
}
._1fiQt:hover {
    background: #e9e9eb;
}

.hexa,
 .hexa div {
 margin: 0 auto;
transform-origin: 50% 50%;
 overflow: hidden;
 width: 115px;
 height: 103px;
 }
 
 .hexab,
 .hexab div {
 margin: 0 auto;
transform-origin: 50% 50%;
 overflow: hidden;
 width: 324px;
 height: 285px;
 }

 .hex2 > img {
 width: 100%;
 height: 100%;
 }
.hexa {
 transform: rotate(149deg);
 }
 .hexab {
 transform: rotate(149deg);
 }
 .hex1 {
 transform: rotate(-60deg);
 }
 .hex2 {
 transform: rotate(-60deg);
 }
 .dropdown-item.active, .dropdown-item:active {
    color: #fff;
    background-color: #ffd85d;
}


.btn {
    padding: 2px 14px;
   
}
.verfmargin{
margin-top:23px;

}
.imagechang{
width:300px;
height:300px;
}

.noteicond{
width:30px;
height:30px;}
 
@media (max-width: 767px) {
p {
   font-size: 12px;
}
.h6, h6 {
    font-size: 14px;
}
.h5, h5 {
    font-size: 16px;
}
.mt-4 {
    margin-top: 0.7rem!important;
}
.form-control {
    font-size: 12px;
    line-height: 18px;
}
.p-4 {
    padding: 1.0rem!important;
}
.p-3 {
    padding: 0.3rem!important;
}
th, td {
font-size:10px;
}
.btn-group-sm>.btn, .btn.btn-sm {
    padding: 2px 6px;
    font-size: 8px;
}
.breadcrumb .breadcrumb-item {
    font-size: 14px;
}
.mobpadd{
padding:0px;
}
.btn {
    padding: 2px 4px;
    font-size: 10px;
}
.card .card-body {
    padding:0.5rem;
}
.tab-content {
    padding: 15px 15px;
}
.form-check-label, .form-label {
    font-weight: 700;
    font-size: 10px;
}
.hidemob{
display:none;
}
.verfmargin{
margin-top:0px;

}
.imagechang{
width:200px;
height:200px;
}
}

@media (max-width: 1396px){
.page-wrapper.toggled .sidebar-wrapper {
    left: -300px!important;
}
.page-wrapper.toggled .top-header {
    left: 0!important;
}
.page-wrapper .page-content .top-header .header-bar .logo-icon {
    display: block!important;
}
.page-wrapper .page-content .top-header .header-bar .logo-icon .big {
    display: block!important;
}
.page-wrapper.toggled .page-content {
    padding-left: 0px!important;
}
}

@media (max-width: 767px){
.page-wrapper .page-content .top-header .header-bar .logo-icon .small {
    display: none!important;
}
}

@media screen and (min-width: 1396px){
.page-wrapper.toggled .page-content {
    padding-left: 300px!important;
}
}

@media (max-width: 1275px) {
.noteicond{
width:20px;
height:20px;}
.form-check-label, .form-label {
    font-weight: 700;
    font-size: 12px;
}
}
@media (max-width: 1111px) {
.noteicond{
width:16px!important;
height:16px!important;}
.form-check-label, .form-label {
    font-weight: 700;
    font-size: 10px!important;
}
}
@media (max-width: 1486px) {
    .nk1{
        font-size:14px;
    }
}
@media (max-width: 1485px) {
    .nk1{
        font-size:12px;
    }
}
@media (max-width: 1295px) {
    .nk2{
        font-size:12px;
    }
}


		 </style>
		  <script>
        function initMap() {
            let a = { lat: 50.064192, lng: -130.605469 },
                b = { north: a.lat + 0.1, south: a.lat - 0.1, east: a.lng + 0.1, west: a.lng - 0.1 },
                c = document.getElementById("pac-input"),
                d = new google.maps.places.Autocomplete(c, { bounds: b, componentRestrictions: { country: "uk" }, fields: ["address_components", "geometry", "name"], strictBounds: !1 });
                d.addListener("place_changed", function () {
                var a = d.getPlace();
                let b = a.address_components.filter((a, b) => "postal_code" === a.types[0]),
                    e = b.length > 0 ? b[0].long_name : "No PostCode";
                $("#infoDisplay").html(`
                            <h4>Address : <span id="addresshiv">${c.value}</span> </h4>
                            <h4>latitude : <span id="latitudehiv">${a.geometry.location.lat()} </span></h4>
                            <h4>longitude : <span id="longitudehiv"> ${a.geometry.location.lng()} </span></h4>
                            <h4>Postal Code : <span id="pincodehiv"> ${e} </span></h4>
                          `);
            });
        }
        window.initMap = initMap;
          
        </script>
                <script defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCgT1jEBs2SE1vAIAWHJ9NM8zRfXAcccvs&libraries=places&callback=initMap"></script>

    </head>

    <body>
        <!-- Loader -->
        <!-- <div id="preloader">
            <div id="status">
                <div class="spinner">
                    <div class="double-bounce1"></div>
                    <div class="double-bounce2"></div>
                </div>
            </div>
        </div> -->
        <!-- Loader -->

        <div class="page-wrapper toggled">
            <!-- sidebar-wrapper -->
             <?php include('common/leftmenu.php');?>
            <!-- sidebar-wrapper  -->

            <!-- Start Page Content -->
            <main class="page-content bg-light">
                <!-- Top Header -->
                 <?php include('common/header.php');?>
                <!-- Top Header -->
 <?php 
                        $userquery = $tutor_db->prepare("SELECT * FROM tutorhive_users WHERE USER_ID=:USER_ID");
                                       $userquery->execute(['USER_ID' => $_SESSION['tutor_admin_id']]); 
                                       $userdata = $userquery->fetch();
                        ?>
                <div class="container-fluid">
                    <div class="layout-specing">
                        <div class="d-md-flex justify-content-between align-items-center">
                            <h5 class="mb-0">Profile Settings  <?php if($_SESSION['admin_type']=="Tutor"){ if($userdata['TUTORDOC_STATUS']!="1" || $userdata['EDUACTIONSTATUS']!="1" || $userdata['PROFILE_STATUS']!="1"){ ?> <a data-bs-toggle="modal" data-bs-target="#tooltip1" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a><?php } }else { if($userdata['EDUACTIONSTATUS']!="1" || $userdata['PROFILE_STATUS']!="1"){ ?> <a data-bs-toggle="modal" data-bs-target="#tooltip1" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a><?php } }?></h5> 

						

                            <nav aria-label="breadcrumb" class="d-inline-block mt-2 mt-sm-0">
                                <ul class="breadcrumb bg-transparent rounded mb-0 p-0">
                                    <li class="breadcrumb-item text-capitalize"><a href="#">TutorHive</a></li>
                                    <li class="breadcrumb-item text-capitalize"><a href="#">Profile</a></li>
                                    <li class="breadcrumb-item text-capitalize active" aria-current="page">Settings</li>
                                </ul>
                            </nav>
                        </div>
						
						
                    <div class="row" style=" margin:20px 0px;">
							  <div class="col-xl-3 col-lg-3 col-md-4 col-12 mobpadd">
                                <div class="card rounded border-0 shadow ">
                                    <ul class="nav nav-pills nav-link-soft nav-justified flex-column bg-white-color mb-0" id="pills-tab" role="tablist">
                                     
									  <li class="nav-item mt-2">
                                            <a class="nav-link rounded active"  id="starred-tab" data-bs-toggle="pill" href="#starred" role="tab" aria-controls="starred" aria-selected="false">
                                                <div class="text-start px-3">
                                                    <span class="mb-0"><span class="mdi mdi-account-settings"></span>&nbsp;&nbsp; Profile Edit</span>
                                                </div>
                                            </a><!--end nav link-->
                                        </li><!--end nav item-->
										 <li class="nav-item mt-2">
                                            <a class="nav-link rounded" <?php if($userdata['PROFILE_STATUS']=="0"){?> style="pointer-events: none;opacity: 0.3;"  <?php } ?>  id="edction-tab" data-bs-toggle="pill" href="#edction" role="tab" aria-controls="edction" aria-selected="false">
                                                <div class="text-start px-3">
                                                    <span class="mb-0"><span class="mdi mdi-book-open-variant"></span>&nbsp;&nbsp; <?php if($_SESSION['admin_type']=="Tutor"){echo "Tuition Set Up";}else {echo "Education";}?></span>
                                                </div>
                                            </a><!--end nav link-->
                                        </li><!--end nav item-->
										
										<li class="nav-item mt-2">
                                            <a class="nav-link rounded" href="#" data-bs-toggle="modal" data-bs-target="#changepass">
                                                <div class="text-start px-3">
                                                    <span class="mb-0"><span class="mdi mdi-key-change"></span>&nbsp;&nbsp; Change Password</span>
                                                </div>
                                            </a><!--end nav link-->
                                        </li>
										
										
										
                                       
										   <?php if($_SESSION['admin_type']=="Tutor"){?>
										   <li class="nav-item mt-2">
                                            <a class="nav-link rounded" <?php if($_SESSION['admin_type']=="Tutor"){if($userdata['EDUACTIONSTATUS']=="0"){?> style="pointer-events: none;opacity: 0.3;"  <?php }} ?>  href="setavailabilityv2">
                                                <div class="text-start px-3">
                                                    <span class="mb-0"><span class="mdi mdi-av-timer"></span>&nbsp;&nbsp; Set Availability</span>
                                                </div>
                                            </a><!--end nav link-->
                                        </li>
										
                                        <li class="nav-item mt-2">
                                            <a class="nav-link rounded" <?php if($_SESSION['admin_type']=="Tutor"){if($userdata['EDUACTIONSTATUS']=="0"){?> style="pointer-events: none;opacity: 0.3;"  <?php }} ?> id="inbox-tab" data-bs-toggle="pill" href="#inbox" role="tab" aria-controls="inbox" aria-selected="false">
                                                <div class="text-start px-3">
                                                    <span class="mb-0"><span class="mdi mdi-file-document"></span>&nbsp;&nbsp; Documents Upload</span>
                                                </div>
                                            </a><!--end nav link-->
                                        </li><!--end nav item-->
                                      
                                        <li class="nav-item mt-2">
                                            <a class="nav-link rounded" <?php if($_SESSION['admin_type']=="Tutor"){if($userdata['DOCSTATUS']=="0"){?> style="pointer-events: none;opacity: 0.3;"  <?php }} ?> id="spam-tab" <?php if($userdata['PROFILE_STATUS']=="0"){?> style="pointer-events: none;opacity: 0.3;"  <?php } ?> data-bs-toggle="pill" href="#spam" role="tab" aria-controls="spam" aria-selected="false">
                                                <div class="text-start px-3">
                                                    <span class="mb-0"><span class="mdi mdi-credit-card"></span>&nbsp;&nbsp; Payment Method</span>
                                                </div>
                                            </a><!--end nav link-->
                                        </li><!--end nav item-->
										<?php } ?>
                                    </ul><!--end nav pills-->
									
                                </div>
								
                            </div>
							 <div class="col-xl-9 col-lg-9 col-md-8 col-12 mobpadd">
                            <div class="col-lg-11">
							 <div class="tab-content rounded-0 shadow-0" id="pills-tabContent">
							 <div class="tab-pane fade active show" id="starred" role="tabpanel" aria-labelledby="starred-tab">
                                 <?php if($userdata['PROFILE_STATUS']=="1"){ ?>
								 <div class="row" style="margin: 10px 0px;">
								<div class="col-md-7">
								 <?php if($_GET['succ']=='profile'){?>
							     <p style="font-size: 18px;font-weight: 700;color: #03b303;">Profile updated successfully </p>
								 <?php } ?>
								  </div>
								<div class="col-md-5" style="text-align:right" >
                                <input type="button" onClick="return validateForm1()" class="btn btn-primary" style="padding: 10px 14px;" value="SAVE">
								<a class="btn btn-primary" id="edcredi" style="padding: 10px 14px; " onClick="return edctnext()">NEXT</a>
								</div>
								</div>
							    <?php }else if($userdata['PROFILE_STATUS']=="0"){ ?>
							    <p style="font-size: 18px;font-weight: 700;color: #f90303;">Please fill in the mandatory fields below</p>
							    <?php } ?>
                                <div class="card border-0 rounded shadow">
                                    <div class="card-body">
                                        <h5 class="text-md-start text-center mb-0"> <?php echo $_SESSION['admin_type']; ?> Profile Edit :</h5>
          <form name="admindetails1" id="form-box1" action=""  enctype="multipart/form-data" method="post" >
		    <div class="row" style="margin-bottom: 15px;">
                                                <div class="col-md-7">
                                        <div class="mt-4 text-md-start text-center d-sm-flex">
										 <?php if($userdata['PROFILE_PIC']!=""){?>
										 <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"  style="width:130px;height:130px;">
                                                                      <defs>
                                                                       <pattern id="img<?php echo $userdata['USER_ID'] ?>4" patternUnits="userSpaceOnUse" width="100" height="100">
                                                              <image xlink:href="<?php echo $userdata['PROFILE_PIC'] ?>" id="uploaded_image2"  x="-25" width="150" height="100" />
                                                                        </pattern>
                                                                      </defs>
                                                                      <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img<?php echo $userdata['USER_ID'] ?>4)" stroke-linejoin="round" stroke="#000" stroke-width="3"/>
                                                                    </svg>
																	<input type="hidden" name="imagename" id="imagename" value="<?php echo $userdata['PROFILE_PIC'];?>">
																	  <?php }else {?>
															<svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"  style="width:130px;height:130px;">
                                                                      <defs>
                                                                       <pattern id="img<?php echo $userdata['USER_ID'] ?>4" patternUnits="userSpaceOnUse" width="100" height="100">
                                                                      <image xlink:href="assets/images/profileicon.png" id="uploaded_image2"  x="-25" width="150" height="100" />
                                                                        </pattern>
                                                                      </defs>
                                                                      <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img<?php echo $userdata['USER_ID'] ?>4)" stroke-linejoin="round" stroke="#000" stroke-width="3"/>
                                                                    </svg>
																	   <input type="hidden" name="imagename" id="imagename" value="">
                                                                        <?php } ?>
										
										
										
                                            
                                            
                                            
                                           <!-- <img src="<?php echo $userdata['PROFILE_PIC'];?>" id="uploaded_image2" class="avatar float-md-left avatar-medium rounded-circle shadow " alt="">-->
                                             
                                            <div class="mt-md-4 mt-3 mt-sm-0">
											<a href="#" onClick="return selectimg()" class="btn btn-primary mt-2">Change Picture</a> <span>*</span>
                                               <!-- <a href="#" data-bs-toggle="modal" data-bs-target="#wishlist" class="btn btn-primary mt-2">Change Picture</a>-->
												<h5 id="uploadimgst" style="display:none; color:#FF0000;">Please wait image uploading....!</h5>
                                            </div>
											
                                        </div>
										</div>
										
										
											</div>
        
                                       
                                            <div class="row ">
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">First Name *</label>
                                                        <div class="form-icon position-relative">
                                                           
                                                            <input name="firstname"  id="firstname" type="text" value="<?php $neew=$userdata['FIRST_NAME'];$neew1= strtolower($neew); echo ucfirst($neew1); ?>" class="form-control" placeholder="First Name :">
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                                <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Last Name *</label>
                                                        <div class="form-icon position-relative">
                                                            
                                                            <input name="lastname" id="lastname" type="text" value="<?php $neew2=$userdata['LAST_NAME'];$neew3= strtolower($neew2); echo ucfirst($neew3); ?>" class="form-control" placeholder="Last Name :">
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                                 <div class="col-md-6 col-sm-6 col-xs-6">
                                                   <div class="mb-3">
                                                        <label class="form-label">Country Code *</label>
                                                        <div class="form-icon position-relative">
                                   <select class="form-control" id="countryscode" tabindex="3" name="countryscode" placeholder="Country Code">
									<option data-countryCode="GB" value="44" <?php if($userdata['MOBILE_COUNTRYCODE']=="44"){ echo "selected"; } ?> >UK (+44)</option>
                                                    <option data-countryCode="US" value="1" <?php if($userdata['MOBILE_COUNTRYCODE']=="1"){ echo "selected"; } ?>>USA (+1)</option>
                                                    <optgroup label="Other countries">
                                                        <option data-countryCode="DZ" value="213" <?php if($userdata['MOBILE_COUNTRYCODE']=="213"){ echo "selected"; } ?>>Algeria (+213)</option>
                                                        <option data-countryCode="AD" value="376" <?php if($userdata['MOBILE_COUNTRYCODE']=="376"){ echo "selected"; } ?>>Andorra (+376)</option>
                                                        <option data-countryCode="AO" value="244" <?php if($userdata['MOBILE_COUNTRYCODE']=="244"){ echo "selected"; } ?>>Angola (+244)</option>
                                                        <option data-countryCode="AI" value="1264" <?php if($userdata['MOBILE_COUNTRYCODE']=="1264"){ echo "selected"; } ?>>Anguilla (+1264)</option>
                                                        <option data-countryCode="AG" value="1268" <?php if($userdata['MOBILE_COUNTRYCODE']=="1268"){ echo "selected"; } ?>>Antigua &amp; Barbuda (+1268)</option>
                                                        <option data-countryCode="AR" value="54" <?php if($userdata['MOBILE_COUNTRYCODE']=="54"){ echo "selected"; } ?>>Argentina (+54)</option>
                                                        <option data-countryCode="AM" value="374" <?php if($userdata['MOBILE_COUNTRYCODE']=="374"){ echo "selected"; } ?>>Armenia (+374)</option>
                                                        <option data-countryCode="AW" value="297" <?php if($userdata['MOBILE_COUNTRYCODE']=="297"){ echo "selected"; } ?>>Aruba (+297)</option>
                                                        <option data-countryCode="AU" value="61" <?php if($userdata['MOBILE_COUNTRYCODE']=="61"){ echo "selected"; } ?>>Australia (+61)</option>
                                                        <option data-countryCode="AT" value="43" <?php if($userdata['MOBILE_COUNTRYCODE']=="43"){ echo "selected"; } ?>>Austria (+43)</option>
                                                        <option data-countryCode="AZ" value="994" <?php if($userdata['MOBILE_COUNTRYCODE']=="994"){ echo "selected"; } ?>>Azerbaijan (+994)</option>
                                                        <option data-countryCode="BS" value="1242" <?php if($userdata['MOBILE_COUNTRYCODE']=="1242"){ echo "selected"; } ?>>Bahamas (+1242)</option>
                                                        <option data-countryCode="BH" value="973" <?php if($userdata['MOBILE_COUNTRYCODE']=="973"){ echo "selected"; } ?>>Bahrain (+973)</option>
                                                        <option data-countryCode="BD" value="880" <?php if($userdata['MOBILE_COUNTRYCODE']=="880"){ echo "selected"; } ?>>Bangladesh (+880)</option>
                                                        <option data-countryCode="BB" value="1246" <?php if($userdata['MOBILE_COUNTRYCODE']=="1246"){ echo "selected"; } ?>>Barbados (+1246)</option>
                                                        <option data-countryCode="BY" value="375" <?php if($userdata['MOBILE_COUNTRYCODE']=="375"){ echo "selected"; } ?>>Belarus (+375)</option>
                                                        <option data-countryCode="BE" value="32" <?php if($userdata['MOBILE_COUNTRYCODE']=="32"){ echo "selected"; } ?>>Belgium (+32)</option>
                                                        <option data-countryCode="BZ" value="501" <?php if($userdata['MOBILE_COUNTRYCODE']=="501"){ echo "selected"; } ?>>Belize (+501)</option>
                                                        <option data-countryCode="BJ" value="229" <?php if($userdata['MOBILE_COUNTRYCODE']=="229"){ echo "selected"; } ?>>Benin (+229)</option>
                                                        <option data-countryCode="BM" value="1441" <?php if($userdata['MOBILE_COUNTRYCODE']=="1441"){ echo "selected"; } ?>>Bermuda (+1441)</option>
                                                        <option data-countryCode="BT" value="975" <?php if($userdata['MOBILE_COUNTRYCODE']=="975"){ echo "selected"; } ?>>Bhutan (+975)</option>
                                                        <option data-countryCode="BO" value="591" <?php if($userdata['MOBILE_COUNTRYCODE']=="591"){ echo "selected"; } ?>>Bolivia (+591)</option>
                                                        <option data-countryCode="BA" value="387" <?php if($userdata['MOBILE_COUNTRYCODE']=="387"){ echo "selected"; } ?>>Bosnia Herzegovina (+387)</option>
                                                        <option data-countryCode="BW" value="267" <?php if($userdata['MOBILE_COUNTRYCODE']=="267"){ echo "selected"; } ?>>Botswana (+267)</option>
                                                        <option data-countryCode="BR" value="55" <?php if($userdata['MOBILE_COUNTRYCODE']=="55"){ echo "selected"; } ?>>Brazil (+55)</option>
                                                        <option data-countryCode="BN" value="673" <?php if($userdata['MOBILE_COUNTRYCODE']=="673"){ echo "selected"; } ?>>Brunei (+673)</option>
                                                        <option data-countryCode="BG" value="359" <?php if($userdata['MOBILE_COUNTRYCODE']=="359"){ echo "selected"; } ?>>Bulgaria (+359)</option>
                                                        <option data-countryCode="BF" value="226" <?php if($userdata['MOBILE_COUNTRYCODE']=="226"){ echo "selected"; } ?>>Burkina Faso (+226)</option>
                                                        <option data-countryCode="BI" value="257" <?php if($userdata['MOBILE_COUNTRYCODE']=="257"){ echo "selected"; } ?>>Burundi (+257)</option>
                                                        <option data-countryCode="KH" value="855" <?php if($userdata['MOBILE_COUNTRYCODE']=="855"){ echo "selected"; } ?>>Cambodia (+855)</option>
                                                        <option data-countryCode="CM" value="237" <?php if($userdata['MOBILE_COUNTRYCODE']=="237"){ echo "selected"; } ?>>Cameroon (+237)</option>
                                                        <option data-countryCode="CA" value="1" <?php if($userdata['MOBILE_COUNTRYCODE']=="1"){ echo "selected"; } ?>>Canada (+1)</option>
                                                        <option data-countryCode="CV" value="238" <?php if($userdata['MOBILE_COUNTRYCODE']=="238"){ echo "selected"; } ?>>Cape Verde Islands (+238)</option>
                                                        <option data-countryCode="KY" value="1345" <?php if($userdata['MOBILE_COUNTRYCODE']=="1345"){ echo "selected"; } ?>>Cayman Islands (+1345)</option>
                                                        <option data-countryCode="CF" value="236" <?php if($userdata['MOBILE_COUNTRYCODE']=="236"){ echo "selected"; } ?>>Central African Republic (+236)</option>
                                                        <option data-countryCode="CL" value="56" <?php if($userdata['MOBILE_COUNTRYCODE']=="56"){ echo "selected"; } ?>>Chile (+56)</option>
                                                        <option data-countryCode="CN" value="86" <?php if($userdata['MOBILE_COUNTRYCODE']=="86"){ echo "selected"; } ?>>China (+86)</option>
                                                        <option data-countryCode="CO" value="57" <?php if($userdata['MOBILE_COUNTRYCODE']=="57"){ echo "selected"; } ?>>Colombia (+57)</option>
                                                        <option data-countryCode="KM" value="269" <?php if($userdata['MOBILE_COUNTRYCODE']=="269"){ echo "selected"; } ?>>Comoros (+269)</option>
                                                        <option data-countryCode="CG" value="242" <?php if($userdata['MOBILE_COUNTRYCODE']=="242"){ echo "selected"; } ?>>Congo (+242)</option>
                                                        <option data-countryCode="CK" value="682" <?php if($userdata['MOBILE_COUNTRYCODE']=="682"){ echo "selected"; } ?>>Cook Islands (+682)</option>
                                                        <option data-countryCode="CR" value="506" <?php if($userdata['MOBILE_COUNTRYCODE']=="506"){ echo "selected"; } ?>>Costa Rica (+506)</option>
                                                        <option data-countryCode="HR" value="385" <?php if($userdata['MOBILE_COUNTRYCODE']=="385"){ echo "selected"; } ?>>Croatia (+385)</option>
                                                        <option data-countryCode="CU" value="53" <?php if($userdata['MOBILE_COUNTRYCODE']=="53"){ echo "selected"; } ?>>Cuba (+53)</option>
                                                        <option data-countryCode="CY" value="90392" <?php if($userdata['MOBILE_COUNTRYCODE']=="90392"){ echo "selected"; } ?>>Cyprus North (+90392)</option>
                                                        <option data-countryCode="CY" value="357" <?php if($userdata['MOBILE_COUNTRYCODE']=="357"){ echo "selected"; } ?>>Cyprus South (+357)</option>
                                                        <option data-countryCode="CZ" value="42" <?php if($userdata['MOBILE_COUNTRYCODE']=="42"){ echo "selected"; } ?>>Czech Republic (+42)</option>
                                                        <option data-countryCode="DK" value="45" <?php if($userdata['MOBILE_COUNTRYCODE']=="45"){ echo "selected"; } ?>>Denmark (+45)</option>
                                                        <option data-countryCode="DJ" value="253" <?php if($userdata['MOBILE_COUNTRYCODE']=="253"){ echo "selected"; } ?>>Djibouti (+253)</option>
                                                        <option data-countryCode="DM" value="1809" <?php if($userdata['MOBILE_COUNTRYCODE']=="1809"){ echo "selected"; } ?>>Dominica (+1809)</option>
                                                        <option data-countryCode="DO" value="1809" <?php if($userdata['MOBILE_COUNTRYCODE']=="1809"){ echo "selected"; } ?>>Dominican Republic (+1809)</option>
                                                        <option data-countryCode="EC" value="593" <?php if($userdata['MOBILE_COUNTRYCODE']=="593"){ echo "selected"; } ?>>Ecuador (+593)</option>
                                                        <option data-countryCode="EG" value="20" <?php if($userdata['MOBILE_COUNTRYCODE']=="20"){ echo "selected"; } ?>>Egypt (+20)</option>
                                                        <option data-countryCode="SV" value="503" <?php if($userdata['MOBILE_COUNTRYCODE']=="503"){ echo "selected"; } ?>>El Salvador (+503)</option>
                                                        <option data-countryCode="GQ" value="240" <?php if($userdata['MOBILE_COUNTRYCODE']=="240"){ echo "selected"; } ?>>Equatorial Guinea (+240)</option>
                                                        <option data-countryCode="ER" value="291" <?php if($userdata['MOBILE_COUNTRYCODE']=="291"){ echo "selected"; } ?>>Eritrea (+291)</option>
                                                        <option data-countryCode="EE" value="372" <?php if($userdata['MOBILE_COUNTRYCODE']=="372"){ echo "selected"; } ?>>Estonia (+372)</option>
                                                        <option data-countryCode="ET" value="251" <?php if($userdata['MOBILE_COUNTRYCODE']=="251"){ echo "selected"; } ?>>Ethiopia (+251)</option>
                                                        <option data-countryCode="FK" value="500" <?php if($userdata['MOBILE_COUNTRYCODE']=="500"){ echo "selected"; } ?>>Falkland Islands (+500)</option>
                                                        <option data-countryCode="FO" value="298" <?php if($userdata['MOBILE_COUNTRYCODE']=="298"){ echo "selected"; } ?>>Faroe Islands (+298)</option>
                                                        <option data-countryCode="FJ" value="679" <?php if($userdata['MOBILE_COUNTRYCODE']=="679"){ echo "selected"; } ?>>Fiji (+679)</option>
                                                        <option data-countryCode="FI" value="358" <?php if($userdata['MOBILE_COUNTRYCODE']=="358"){ echo "selected"; } ?>>Finland (+358)</option>
                                                        <option data-countryCode="FR" value="33" <?php if($userdata['MOBILE_COUNTRYCODE']=="33"){ echo "selected"; } ?>>France (+33)</option>
                                                        <option data-countryCode="GF" value="594" <?php if($userdata['MOBILE_COUNTRYCODE']=="594"){ echo "selected"; } ?>>French Guiana (+594)</option>
                                                        <option data-countryCode="PF" value="689" <?php if($userdata['MOBILE_COUNTRYCODE']=="689"){ echo "selected"; } ?>>French Polynesia (+689)</option>
                                                        <option data-countryCode="GA" value="241" <?php if($userdata['MOBILE_COUNTRYCODE']=="241"){ echo "selected"; } ?>>Gabon (+241)</option>
                                                        <option data-countryCode="GM" value="220" <?php if($userdata['MOBILE_COUNTRYCODE']=="220"){ echo "selected"; } ?>>Gambia (+220)</option>
                                                        <option data-countryCode="GE" value="7880" <?php if($userdata['MOBILE_COUNTRYCODE']=="7880"){ echo "selected"; } ?>>Georgia (+7880)</option>
                                                        <option data-countryCode="DE" value="49" <?php if($userdata['MOBILE_COUNTRYCODE']=="49"){ echo "selected"; } ?>>Germany (+49)</option>
                                                        <option data-countryCode="GH" value="233" <?php if($userdata['MOBILE_COUNTRYCODE']=="233"){ echo "selected"; } ?>>Ghana (+233)</option>
                                                        <option data-countryCode="GI" value="350" <?php if($userdata['MOBILE_COUNTRYCODE']=="350"){ echo "selected"; } ?>>Gibraltar (+350)</option>
                                                        <option data-countryCode="GR" value="30" <?php if($userdata['MOBILE_COUNTRYCODE']=="30"){ echo "selected"; } ?>>Greece (+30)</option>
                                                        <option data-countryCode="GL" value="299" <?php if($userdata['MOBILE_COUNTRYCODE']=="299"){ echo "selected"; } ?>>Greenland (+299)</option>
                                                        <option data-countryCode="GD" value="1473" <?php if($userdata['MOBILE_COUNTRYCODE']=="1473"){ echo "selected"; } ?>>Grenada (+1473)</option>
                                                        <option data-countryCode="GP" value="590" <?php if($userdata['MOBILE_COUNTRYCODE']=="590"){ echo "selected"; } ?>>Guadeloupe (+590)</option>
                                                        <option data-countryCode="GU" value="671" <?php if($userdata['MOBILE_COUNTRYCODE']=="671"){ echo "selected"; } ?>>Guam (+671)</option>
                                                        <option data-countryCode="GT" value="502" <?php if($userdata['MOBILE_COUNTRYCODE']=="502"){ echo "selected"; } ?>>Guatemala (+502)</option>
                                                        <option data-countryCode="GN" value="224" <?php if($userdata['MOBILE_COUNTRYCODE']=="224"){ echo "selected"; } ?>>Guinea (+224)</option>
                                                        <option data-countryCode="GW" value="245" <?php if($userdata['MOBILE_COUNTRYCODE']=="245"){ echo "selected"; } ?>>Guinea - Bissau (+245)</option>
                                                        <option data-countryCode="GY" value="592" <?php if($userdata['MOBILE_COUNTRYCODE']=="592"){ echo "selected"; } ?>>Guyana (+592)</option>
                                                        <option data-countryCode="HT" value="509" <?php if($userdata['MOBILE_COUNTRYCODE']=="509"){ echo "selected"; } ?>>Haiti (+509)</option>
                                                        <option data-countryCode="HN" value="504" <?php if($userdata['MOBILE_COUNTRYCODE']=="504"){ echo "selected"; } ?>>Honduras (+504)</option>
                                                        <option data-countryCode="HK" value="852" <?php if($userdata['MOBILE_COUNTRYCODE']=="852"){ echo "selected"; } ?>>Hong Kong (+852)</option>
                                                        <option data-countryCode="HU" value="36" <?php if($userdata['MOBILE_COUNTRYCODE']=="36"){ echo "selected"; } ?>>Hungary (+36)</option>
                                                        <option data-countryCode="IS" value="354" <?php if($userdata['MOBILE_COUNTRYCODE']=="354"){ echo "selected"; } ?>>Iceland (+354)</option>
                                                        <option data-countryCode="IN" value="91" <?php if($userdata['MOBILE_COUNTRYCODE']=="91"){ echo "selected"; } ?>>India (+91)</option>
                                                        <option data-countryCode="ID" value="62" <?php if($userdata['MOBILE_COUNTRYCODE']=="62"){ echo "selected"; } ?>>Indonesia (+62)</option>
                                                        <option data-countryCode="IR" value="98" <?php if($userdata['MOBILE_COUNTRYCODE']=="98"){ echo "selected"; } ?>>Iran (+98)</option>
                                                        <option data-countryCode="IQ" value="964" <?php if($userdata['MOBILE_COUNTRYCODE']=="964"){ echo "selected"; } ?>>Iraq (+964)</option>
                                                        <option data-countryCode="IE" value="353" <?php if($userdata['MOBILE_COUNTRYCODE']=="353"){ echo "selected"; } ?>>Ireland (+353)</option>
                                                        <option data-countryCode="IL" value="972" <?php if($userdata['MOBILE_COUNTRYCODE']=="972"){ echo "selected"; } ?>>Israel (+972)</option>
                                                        <option data-countryCode="IT" value="39" <?php if($userdata['MOBILE_COUNTRYCODE']=="39"){ echo "selected"; } ?>>Italy (+39)</option>
                                                        <option data-countryCode="JM" value="1876" <?php if($userdata['MOBILE_COUNTRYCODE']=="1876"){ echo "selected"; } ?>>Jamaica (+1876)</option>
                                                        <option data-countryCode="JP" value="81" <?php if($userdata['MOBILE_COUNTRYCODE']=="81"){ echo "selected"; } ?>>Japan (+81)</option>
                                                        <option data-countryCode="JO" value="962" <?php if($userdata['MOBILE_COUNTRYCODE']=="962"){ echo "selected"; } ?>>Jordan (+962)</option>
                                                        <option data-countryCode="KZ" value="7" <?php if($userdata['MOBILE_COUNTRYCODE']=="7"){ echo "selected"; } ?>>Kazakhstan (+7)</option>
                                                        <option data-countryCode="KE" value="254" <?php if($userdata['MOBILE_COUNTRYCODE']=="254"){ echo "selected"; } ?>>Kenya (+254)</option>
                                                        <option data-countryCode="KI" value="686" <?php if($userdata['MOBILE_COUNTRYCODE']=="686"){ echo "selected"; } ?>>Kiribati (+686)</option>
                                                        <option data-countryCode="KP" value="850" <?php if($userdata['MOBILE_COUNTRYCODE']=="850"){ echo "selected"; } ?>>Korea North (+850)</option>
                                                        <option data-countryCode="KR" value="82" <?php if($userdata['MOBILE_COUNTRYCODE']=="82"){ echo "selected"; } ?>>Korea South (+82)</option>
                                                        <option data-countryCode="KW" value="965" <?php if($userdata['MOBILE_COUNTRYCODE']=="965"){ echo "selected"; } ?>>Kuwait (+965)</option>
                                                        <option data-countryCode="KG" value="996" <?php if($userdata['MOBILE_COUNTRYCODE']=="996"){ echo "selected"; } ?>>Kyrgyzstan (+996)</option>
                                                        <option data-countryCode="LA" value="856" <?php if($userdata['MOBILE_COUNTRYCODE']=="856"){ echo "selected"; } ?>>Laos (+856)</option>
                                                        <option data-countryCode="LV" value="371" <?php if($userdata['MOBILE_COUNTRYCODE']=="371"){ echo "selected"; } ?>>Latvia (+371)</option>
                                                        <option data-countryCode="LB" value="961" <?php if($userdata['MOBILE_COUNTRYCODE']=="961"){ echo "selected"; } ?>>Lebanon (+961)</option>
                                                        <option data-countryCode="LS" value="266" <?php if($userdata['MOBILE_COUNTRYCODE']=="266"){ echo "selected"; } ?>>Lesotho (+266)</option>
                                                        <option data-countryCode="LR" value="231" <?php if($userdata['MOBILE_COUNTRYCODE']=="231"){ echo "selected"; } ?>>Liberia (+231)</option>
                                                        <option data-countryCode="LY" value="218" <?php if($userdata['MOBILE_COUNTRYCODE']=="218"){ echo "selected"; } ?>>Libya (+218)</option>
                                                        <option data-countryCode="LI" value="417" <?php if($userdata['MOBILE_COUNTRYCODE']=="417"){ echo "selected"; } ?>>Liechtenstein (+417)</option>
                                                        <option data-countryCode="LT" value="370" <?php if($userdata['MOBILE_COUNTRYCODE']=="370"){ echo "selected"; } ?>>Lithuania (+370)</option>
                                                        <option data-countryCode="LU" value="352" <?php if($userdata['MOBILE_COUNTRYCODE']=="352"){ echo "selected"; } ?>>Luxembourg (+352)</option>
                                                        <option data-countryCode="MO" value="853" <?php if($userdata['MOBILE_COUNTRYCODE']=="853"){ echo "selected"; } ?>>Macao (+853)</option>
                                                        <option data-countryCode="MK" value="389" <?php if($userdata['MOBILE_COUNTRYCODE']=="389"){ echo "selected"; } ?>>Macedonia (+389)</option>
                                                        <option data-countryCode="MG" value="261" <?php if($userdata['MOBILE_COUNTRYCODE']=="261"){ echo "selected"; } ?>>Madagascar (+261)</option>
                                                        <option data-countryCode="MW" value="265" <?php if($userdata['MOBILE_COUNTRYCODE']=="265"){ echo "selected"; } ?>>Malawi (+265)</option>
                                                        <option data-countryCode="MY" value="60" <?php if($userdata['MOBILE_COUNTRYCODE']=="60"){ echo "selected"; } ?>>Malaysia (+60)</option>
                                                        <option data-countryCode="MV" value="960" <?php if($userdata['MOBILE_COUNTRYCODE']=="960"){ echo "selected"; } ?>>Maldives (+960)</option>
                                                        <option data-countryCode="ML" value="223" <?php if($userdata['MOBILE_COUNTRYCODE']=="223"){ echo "selected"; } ?>>Mali (+223)</option>
                                                        <option data-countryCode="MT" value="356" <?php if($userdata['MOBILE_COUNTRYCODE']=="356"){ echo "selected"; } ?>>Malta (+356)</option>
                                                        <option data-countryCode="MH" value="692" <?php if($userdata['MOBILE_COUNTRYCODE']=="692"){ echo "selected"; } ?>>Marshall Islands (+692)</option>
                                                        <option data-countryCode="MQ" value="596" <?php if($userdata['MOBILE_COUNTRYCODE']=="596"){ echo "selected"; } ?>>Martinique (+596)</option>
                                                        <option data-countryCode="MR" value="222" <?php if($userdata['MOBILE_COUNTRYCODE']=="222"){ echo "selected"; } ?>>Mauritania (+222)</option>
                                                        <option data-countryCode="YT" value="269" <?php if($userdata['MOBILE_COUNTRYCODE']=="269"){ echo "selected"; } ?>>Mayotte (+269)</option>
                                                        <option data-countryCode="MX" value="52" <?php if($userdata['MOBILE_COUNTRYCODE']=="52"){ echo "selected"; } ?>>Mexico (+52)</option>
                                                        <option data-countryCode="FM" value="691" <?php if($userdata['MOBILE_COUNTRYCODE']=="691"){ echo "selected"; } ?>>Micronesia (+691)</option>
                                                        <option data-countryCode="MD" value="373" <?php if($userdata['MOBILE_COUNTRYCODE']=="373"){ echo "selected"; } ?>>Moldova (+373)</option>
                                                        <option data-countryCode="MC" value="377" <?php if($userdata['MOBILE_COUNTRYCODE']=="377"){ echo "selected"; } ?>>Monaco (+377)</option>
                                                        <option data-countryCode="MN" value="976" <?php if($userdata['MOBILE_COUNTRYCODE']=="976"){ echo "selected"; } ?>>Mongolia (+976)</option>
                                                        <option data-countryCode="MS" value="1664" <?php if($userdata['MOBILE_COUNTRYCODE']=="1664"){ echo "selected"; } ?>>Montserrat (+1664)</option>
                                                        <option data-countryCode="MA" value="212" <?php if($userdata['MOBILE_COUNTRYCODE']=="212"){ echo "selected"; } ?>>Morocco (+212)</option>
                                                        <option data-countryCode="MZ" value="258" <?php if($userdata['MOBILE_COUNTRYCODE']=="258"){ echo "selected"; } ?>>Mozambique (+258)</option>
                                                        <option data-countryCode="MN" value="95" <?php if($userdata['MOBILE_COUNTRYCODE']=="95"){ echo "selected"; } ?>>Myanmar (+95)</option>
                                                        <option data-countryCode="NA" value="264" <?php if($userdata['MOBILE_COUNTRYCODE']=="264"){ echo "selected"; } ?>>Namibia (+264)</option>
                                                        <option data-countryCode="NR" value="674" <?php if($userdata['MOBILE_COUNTRYCODE']=="674"){ echo "selected"; } ?>>Nauru (+674)</option>
                                                        <option data-countryCode="NP" value="977" <?php if($userdata['MOBILE_COUNTRYCODE']=="977"){ echo "selected"; } ?>>Nepal (+977)</option>
                                                        <option data-countryCode="NL" value="31" <?php if($userdata['MOBILE_COUNTRYCODE']=="31"){ echo "selected"; } ?>>Netherlands (+31)</option>
                                                        <option data-countryCode="NC" value="687" <?php if($userdata['MOBILE_COUNTRYCODE']=="687"){ echo "selected"; } ?>>New Caledonia (+687)</option>
                                                        <option data-countryCode="NZ" value="64" <?php if($userdata['MOBILE_COUNTRYCODE']=="64"){ echo "selected"; } ?>>New Zealand (+64)</option>
                                                        <option data-countryCode="NI" value="505" <?php if($userdata['MOBILE_COUNTRYCODE']=="505"){ echo "selected"; } ?>>Nicaragua (+505)</option>
                                                        <option data-countryCode="NE" value="227" <?php if($userdata['MOBILE_COUNTRYCODE']=="227"){ echo "selected"; } ?>>Niger (+227)</option>
                                                        <option data-countryCode="NG" value="234" <?php if($userdata['MOBILE_COUNTRYCODE']=="234"){ echo "selected"; } ?>>Nigeria (+234)</option>
                                                        <option data-countryCode="NU" value="683" <?php if($userdata['MOBILE_COUNTRYCODE']=="683"){ echo "selected"; } ?>>Niue (+683)</option>
                                                        <option data-countryCode="NF" value="672" <?php if($userdata['MOBILE_COUNTRYCODE']=="672"){ echo "selected"; } ?>>Norfolk Islands (+672)</option>
                                                        <option data-countryCode="NP" value="670" <?php if($userdata['MOBILE_COUNTRYCODE']=="670"){ echo "selected"; } ?>>Northern Marianas (+670)</option>
                                                        <option data-countryCode="NO" value="47" <?php if($userdata['MOBILE_COUNTRYCODE']=="47"){ echo "selected"; } ?>>Norway (+47)</option>
                                                        <option data-countryCode="OM" value="968" <?php if($userdata['MOBILE_COUNTRYCODE']=="968"){ echo "selected"; } ?>>Oman (+968)</option>
                                                        <option data-countryCode="PW" value="680" <?php if($userdata['MOBILE_COUNTRYCODE']=="680"){ echo "selected"; } ?>>Palau (+680)</option>
                                                        <option data-countryCode="PA" value="507" <?php if($userdata['MOBILE_COUNTRYCODE']=="507"){ echo "selected"; } ?>>Panama (+507)</option>
                                                        <option data-countryCode="PG" value="675" <?php if($userdata['MOBILE_COUNTRYCODE']=="675"){ echo "selected"; } ?>>Papua New Guinea (+675)</option>
                                                        <option data-countryCode="PY" value="595" <?php if($userdata['MOBILE_COUNTRYCODE']=="595"){ echo "selected"; } ?>>Paraguay (+595)</option>
                                                        <option data-countryCode="PE" value="51" <?php if($userdata['MOBILE_COUNTRYCODE']=="51"){ echo "selected"; } ?>>Peru (+51)</option>
                                                        <option data-countryCode="PH" value="63" <?php if($userdata['MOBILE_COUNTRYCODE']=="63"){ echo "selected"; } ?>>Philippines (+63)</option>
                                                        <option data-countryCode="PL" value="48" <?php if($userdata['MOBILE_COUNTRYCODE']=="48"){ echo "selected"; } ?>>Poland (+48)</option>
                                                        <option data-countryCode="PT" value="351" <?php if($userdata['MOBILE_COUNTRYCODE']=="351"){ echo "selected"; } ?>>Portugal (+351)</option>
                                                        <option data-countryCode="PR" value="1787" <?php if($userdata['MOBILE_COUNTRYCODE']=="1787"){ echo "selected"; } ?>>Puerto Rico (+1787)</option>
                                                        <option data-countryCode="QA" value="974" <?php if($userdata['MOBILE_COUNTRYCODE']=="974"){ echo "selected"; } ?>>Qatar (+974)</option>
                                                        <option data-countryCode="RE" value="262" <?php if($userdata['MOBILE_COUNTRYCODE']=="262"){ echo "selected"; } ?>>Reunion (+262)</option>
                                                        <option data-countryCode="RO" value="40" <?php if($userdata['MOBILE_COUNTRYCODE']=="40"){ echo "selected"; } ?>>Romania (+40)</option>
                                                        <option data-countryCode="RU" value="7" <?php if($userdata['MOBILE_COUNTRYCODE']=="7"){ echo "selected"; } ?>>Russia (+7)</option>
                                                        <option data-countryCode="RW" value="250" <?php if($userdata['MOBILE_COUNTRYCODE']=="250"){ echo "selected"; } ?>>Rwanda (+250)</option>
                                                        <option data-countryCode="SM" value="378" <?php if($userdata['MOBILE_COUNTRYCODE']=="378"){ echo "selected"; } ?>>San Marino (+378)</option>
                                                        <option data-countryCode="ST" value="239" <?php if($userdata['MOBILE_COUNTRYCODE']=="239"){ echo "selected"; } ?>>Sao Tome &amp; Principe (+239)</option>
                                                        <option data-countryCode="SA" value="966" <?php if($userdata['MOBILE_COUNTRYCODE']=="966"){ echo "selected"; } ?>>Saudi Arabia (+966)</option>
                                                        <option data-countryCode="SN" value="221" <?php if($userdata['MOBILE_COUNTRYCODE']=="221"){ echo "selected"; } ?>>Senegal (+221)</option>
                                                        <option data-countryCode="CS" value="381" <?php if($userdata['MOBILE_COUNTRYCODE']=="381"){ echo "selected"; } ?>>Serbia (+381)</option>
                                                        <option data-countryCode="SC" value="248" <?php if($userdata['MOBILE_COUNTRYCODE']=="248"){ echo "selected"; } ?>>Seychelles (+248)</option>
                                                        <option data-countryCode="SL" value="232" <?php if($userdata['MOBILE_COUNTRYCODE']=="232"){ echo "selected"; } ?>>Sierra Leone (+232)</option>
                                                        <option data-countryCode="SG" value="65" <?php if($userdata['MOBILE_COUNTRYCODE']=="65"){ echo "selected"; } ?>>Singapore (+65)</option>
                                                        <option data-countryCode="SK" value="421" <?php if($userdata['MOBILE_COUNTRYCODE']=="421"){ echo "selected"; } ?>>Slovak Republic (+421)</option>
                                                        <option data-countryCode="SI" value="386" <?php if($userdata['MOBILE_COUNTRYCODE']=="386"){ echo "selected"; } ?>>Slovenia (+386)</option>
                                                        <option data-countryCode="SB" value="677" <?php if($userdata['MOBILE_COUNTRYCODE']=="677"){ echo "selected"; } ?>>Solomon Islands (+677)</option>
                                                        <option data-countryCode="SO" value="252" <?php if($userdata['MOBILE_COUNTRYCODE']=="252"){ echo "selected"; } ?>>Somalia (+252)</option>
                                                        <option data-countryCode="ZA" value="27" <?php if($userdata['MOBILE_COUNTRYCODE']=="27"){ echo "selected"; } ?>>South Africa (+27)</option>
                                                        <option data-countryCode="ES" value="34" <?php if($userdata['MOBILE_COUNTRYCODE']=="34"){ echo "selected"; } ?>>Spain (+34)</option>
                                                        <option data-countryCode="LK" value="94" <?php if($userdata['MOBILE_COUNTRYCODE']=="94"){ echo "selected"; } ?>>Sri Lanka (+94)</option>
                                                        <option data-countryCode="SH" value="290" <?php if($userdata['MOBILE_COUNTRYCODE']=="290"){ echo "selected"; } ?>>St. Helena (+290)</option>
                                                        <option data-countryCode="KN" value="1869" <?php if($userdata['MOBILE_COUNTRYCODE']=="1869"){ echo "selected"; } ?>>St. Kitts (+1869)</option>
                                                        <option data-countryCode="SC" value="1758" <?php if($userdata['MOBILE_COUNTRYCODE']=="1758"){ echo "selected"; } ?>>St. Lucia (+1758)</option>
                                                        <option data-countryCode="SD" value="249" <?php if($userdata['MOBILE_COUNTRYCODE']=="249"){ echo "selected"; } ?>>Sudan (+249)</option>
                                                        <option data-countryCode="SR" value="597" <?php if($userdata['MOBILE_COUNTRYCODE']=="597"){ echo "selected"; } ?>>Suriname (+597)</option>
                                                        <option data-countryCode="SZ" value="268" <?php if($userdata['MOBILE_COUNTRYCODE']=="268"){ echo "selected"; } ?>>Swaziland (+268)</option>
                                                        <option data-countryCode="SE" value="46" <?php if($userdata['MOBILE_COUNTRYCODE']=="46"){ echo "selected"; } ?>>Sweden (+46)</option>
                                                        <option data-countryCode="CH" value="41" <?php if($userdata['MOBILE_COUNTRYCODE']=="41"){ echo "selected"; } ?>>Switzerland (+41)</option>
                                                        <option data-countryCode="SI" value="963" <?php if($userdata['MOBILE_COUNTRYCODE']=="963"){ echo "selected"; } ?>>Syria (+963)</option>
                                                        <option data-countryCode="TW" value="886" <?php if($userdata['MOBILE_COUNTRYCODE']=="886"){ echo "selected"; } ?>>Taiwan (+886)</option>
                                                        <option data-countryCode="TJ" value="7" <?php if($userdata['MOBILE_COUNTRYCODE']=="7"){ echo "selected"; } ?>>Tajikstan (+7)</option>
                                                        <option data-countryCode="TH" value="66" <?php if($userdata['MOBILE_COUNTRYCODE']=="66"){ echo "selected"; } ?>>Thailand (+66)</option>
                                                        <option data-countryCode="TG" value="228" <?php if($userdata['MOBILE_COUNTRYCODE']=="228"){ echo "selected"; } ?>>Togo (+228)</option>
                                                        <option data-countryCode="TO" value="676" <?php if($userdata['MOBILE_COUNTRYCODE']=="676"){ echo "selected"; } ?>>Tonga (+676)</option>
                                                        <option data-countryCode="TT" value="1868" <?php if($userdata['MOBILE_COUNTRYCODE']=="1868"){ echo "selected"; } ?>>Trinidad &amp; Tobago (+1868)</option>
                                                        <option data-countryCode="TN" value="216" <?php if($userdata['MOBILE_COUNTRYCODE']=="216"){ echo "selected"; } ?>>Tunisia (+216)</option>
                                                        <option data-countryCode="TR" value="90" <?php if($userdata['MOBILE_COUNTRYCODE']=="90"){ echo "selected"; } ?>>Turkey (+90)</option>
                                                        <option data-countryCode="TM" value="7" <?php if($userdata['MOBILE_COUNTRYCODE']=="7"){ echo "selected"; } ?>>Turkmenistan (+7)</option>
                                                        <option data-countryCode="TM" value="993" <?php if($userdata['MOBILE_COUNTRYCODE']=="993"){ echo "selected"; } ?>>Turkmenistan (+993)</option>
                                                        <option data-countryCode="TC" value="1649" <?php if($userdata['MOBILE_COUNTRYCODE']=="1649"){ echo "selected"; } ?>>Turks &amp; Caicos Islands (+1649)</option>
                                                        <option data-countryCode="TV" value="688" <?php if($userdata['MOBILE_COUNTRYCODE']=="688"){ echo "selected"; } ?>>Tuvalu (+688)</option>
                                                        <option data-countryCode="UG" value="256"  <?php if($userdata['MOBILE_COUNTRYCODE']=="256"){ echo "selected"; } ?>>Uganda (+256)</option>
                                                        <!-- <option data-countryCode="GB" value="44">UK (+44)</option> -->
                                                        <option data-countryCode="UA" value="380" <?php if($userdata['MOBILE_COUNTRYCODE']=="380"){ echo "selected"; } ?>>Ukraine (+380)</option>
                                                        <option data-countryCode="AE" value="971" <?php if($userdata['MOBILE_COUNTRYCODE']=="971"){ echo "selected"; } ?>>United Arab Emirates (+971)</option>
                                                        <option data-countryCode="UY" value="598" <?php if($userdata['MOBILE_COUNTRYCODE']=="598"){ echo "selected"; } ?>>Uruguay (+598)</option>
                                                        <!-- <option data-countryCode="US" value="1">USA (+1)</option> -->
                                                        <option data-countryCode="UZ" value="7" <?php if($userdata['MOBILE_COUNTRYCODE']=="7"){ echo "selected"; } ?>>Uzbekistan (+7)</option>
                                                        <option data-countryCode="VU" value="678" <?php if($userdata['MOBILE_COUNTRYCODE']=="678"){ echo "selected"; } ?>>Vanuatu (+678)</option>
                                                        <option data-countryCode="VA" value="379" <?php if($userdata['MOBILE_COUNTRYCODE']=="379"){ echo "selected"; } ?>>Vatican City (+379)</option>
                                                        <option data-countryCode="VE" value="58" <?php if($userdata['MOBILE_COUNTRYCODE']=="58"){ echo "selected"; } ?>>Venezuela (+58)</option>
                                                        <option data-countryCode="VN" value="84" <?php if($userdata['MOBILE_COUNTRYCODE']=="84"){ echo "selected"; } ?>>Vietnam (+84)</option>
                                                        <option data-countryCode="VG" value="84" <?php if($userdata['MOBILE_COUNTRYCODE']=="84"){ echo "selected"; } ?>>Virgin Islands - British (+1284)</option>
                                                        <option data-countryCode="VI" value="84" <?php if($userdata['MOBILE_COUNTRYCODE']=="84"){ echo "selected"; } ?>>Virgin Islands - US (+1340)</option>
                                                        <option data-countryCode="WF" value="681" <?php if($userdata['MOBILE_COUNTRYCODE']=="681"){ echo "selected"; } ?>>Wallis &amp; Futuna (+681)</option>
                                                        <option data-countryCode="YE" value="969" <?php if($userdata['MOBILE_COUNTRYCODE']=="969"){ echo "selected"; } ?>>Yemen (North)(+969)</option>
                                                        <option data-countryCode="YE" value="967" <?php if($userdata['MOBILE_COUNTRYCODE']=="967"){ echo "selected"; } ?>>Yemen (South)(+967)</option>
                                                        <option data-countryCode="ZM" value="260" <?php if($userdata['MOBILE_COUNTRYCODE']=="260"){ echo "selected"; } ?>>Zambia (+260)</option>
                                                        <option data-countryCode="ZW" value="263" <?php if($userdata['MOBILE_COUNTRYCODE']=="263"){ echo "selected"; } ?>>Zimbabwe (+263)</option>
                                                    </optgroup>
									</select>
                                </div>                
                                </div>
                                </div>
												<div class="col-md-6 col-sm-6 col-xs-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Mobile No *</label>
                                                        <div class="form-icon position-relative">
                                                           
                                                            <input name="mobileno" id="mobileno" maxlength="10" type="text" value="<?php echo $userdata['USER_MOBILE'];?>" class="form-control" placeholder="Mobile No :">
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
                                                	
                                                
												<div class="col-md-12 col-sm-12 col-xs-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Gender *</label>
                                                        <div class="form-icon position-relative">
                                                          <input type="radio" name="gstatus" value="1" <?php if($userdata['GENDER']==1){ ?> checked="checked"  <?php } ?>> Male &nbsp; &nbsp;
                                                            <input type="radio" name="gstatus" value="2" <?php if($userdata['GENDER']==2){ ?> checked="checked"  <?php } ?>> Female &nbsp; &nbsp;
                                                            <input type="radio" name="gstatus" value="3" <?php if($userdata['GENDER']==3){ ?> checked="checked"  <?php } ?>> Other
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
                                                </div>
                                                <div class="row">
                                                    <label class="form-label" style="margin: 0px;">Date of Birth *</label>
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">Date *</label>
                                                        <div class="form-icon position-relative">
                                                             <select class="form-control" id="dateof" name="dateof" placeholder="Date Of Birth">
                                                         	<option value="<?php echo $userdata['DATEOF'];?>"><?php echo $userdata['DATEOF'];?></option>
									<option value="01">1st</option><option value="02">2nd</option><option value="03">3rd</option><option value="04">4th</option><option value="05">5th</option><option value="06">6th</option><option value="07">7th</option><option value="08">8th</option><option value="09">9th</option><option value="10">10th</option><option value="11">11th</option><option value="12">12th</option><option value="13">13th</option><option value="14">14th</option><option value="15">15th</option><option value="16">16th</option><option value="17">17th</option><option value="18">18th</option><option value="19">19th</option><option value="20">20th</option><option value="21">21st</option><option value="22">22nd</option><option value="23">23rd</option><option value="24">24th</option><option value="25">25th</option><option value="26">26th</option><option value="27">27th</option><option value="28">28th</option><option value="29">29th</option><option value="30">30th</option><option value="31">31st</option>
									</select>
                                                  </div>      
                                                    </div> 
                                                </div><!--end col-->
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" >Month *</label>
                                                        <div class="form-icon position-relative">
                                                             <select class="form-control" id="monthof" name="monthof" placeholder="Date Of Birth">
                                                         	<option value="<?php echo $userdata['MONTHOF'];?>"><?php echo $userdata['MONTHOF'];?></option>
<option value="01">January</option><option value="02">February</option><option value="03">March</option><option value="04">April</option><option value="05">May</option><option value="06">June</option><option value="07">July</option><option value="08">August</option><option value="09">September</option><option value="10">October</option><option value="11">November</option><option value="12">December</option>									</select>
                                    	
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
                                                <div class="col-md-4 col-sm-6 col-xs-6">
                                                    <div class="mb-3">
                                                        <label class="form-label" >Year *</label>
                                                        <div class="form-icon position-relative">
                                                             <select class="form-control" id="yearof" name="yearof" placeholder="Date Of Birth">
                                                         	<option value="<?php echo $userdata['YEAROF'];?>"><?php echo $userdata['YEAROF'];?></option>
<option value="2022">2022</option><option value="2021">2021</option><option value="2020">2020</option><option value="2019">2019</option><option value="2018">2018</option><option value="2017">2017</option><option value="2016">2016</option><option value="2015">2015</option><option value="2014">2014</option><option value="2013">2013</option><option value="2012">2012</option><option value="2011">2011</option><option value="2010">2010</option><option value="2009">2009</option><option value="2008">2008</option><option value="2007">2007</option><option value="2006">2006</option><option value="2005">2005</option><option value="2004">2004</option><option value="2003">2003</option><option value="2002">2002</option><option value="2001">2001</option><option value="2000">2000</option><option value="1999">1999</option><option value="1998">1998</option><option value="1997">1997</option><option value="1996">1996</option><option value="1995">1995</option><option value="1994">1994</option><option value="1993">1993</option><option value="1992">1992</option><option value="1991">1991</option><option value="1990">1990</option><option value="1989">1989</option><option value="1988">1988</option><option value="1987">1987</option><option value="1986">1986</option><option value="1985">1985</option><option value="1984">1984</option><option value="1983">1983</option><option value="1982">1982</option><option value="1981">1981</option><option value="1980">1980</option><option value="1979">1979</option><option value="1978">1978</option><option value="1977">1977</option><option value="1976">1976</option><option value="1975">1975</option><option value="1974">1974</option><option value="1973">1973</option><option value="1972">1972</option><option value="1971">1971</option><option value="1970">1970</option><option value="1969">1969</option><option value="1968">1968</option><option value="1967">1967</option><option value="1966">1966</option><option value="1965">1965</option><option value="1964">1964</option><option value="1963">1963</option><option value="1962">1962</option><option value="1961">1961</option><option value="1960">1960</option><option value="1959">1959</option><option value="1958">1958</option><option value="1957">1957</option><option value="1956">1956</option><option value="1955">1955</option><option value="1954">1954</option><option value="1953">1953</option><option value="1952">1952</option><option value="1951">1951</option><option value="1950">1950</option><option value="1949">1949</option><option value="1948">1948</option><option value="1947">1947</option><option value="1946">1946</option><option value="1945">1945</option><option value="1944">1944</option><option value="1943">1943</option><option value="1942">1942</option><option value="1941">1941</option><option value="1940">1940</option><option value="1939">1939</option><option value="1938">1938</option><option value="1937">1937</option><option value="1936">1936</option><option value="1935">1935</option><option value="1934">1934</option><option value="1933">1933</option><option value="1932">1932</option><option value="1931">1931</option><option value="1930">1930</option><option value="1929">1929</option><option value="1928">1928</option><option value="1927">1927</option><option value="1926">1926</option><option value="1925">1925</option><option value="1924">1924</option><option value="1923">1923</option><option value="1922">1922</option><option value="1921">1921</option><option value="1920">1920</option><option value="1919">1919</option><option value="1918">1918</option><option value="1917">1917</option><option value="1916">1916</option><option value="1915">1915</option><option value="1914">1914</option><option value="1913">1913</option><option value="1912">1912</option><option value="1911">1911</option><option value="1910">1910</option><option value="1909">1909</option><option value="1908">1908</option><option value="1907">1907</option><option value="1906">1906</option><option value="1905">1905</option><option value="1904">1904</option><option value="1903">1903</option><option value="1902">1902</option><option value="1901">1901</option><                                    <label for="floatingPassword">Year</label>
                                </select>
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
                                                
                                               
                                                <div class="row">
                                                <div class="col-md-7 col-sm-12 col-xs-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Your Email *</label>
                                                        <div class="form-icon position-relative">
                                                             <input type="hidden" name="emilverifed" id="emilverifed" value="Yes">
                                                            <input name="mobileapp" id="mobileapp" type="email" class="form-control" onKeyUp="editMobileNumber()"  value="<?php echo $userdata['USER_EMAIL'];?>" placeholder="Your email :">
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
												<div class="col-md-5 col-sm-12 col-xs-12 verfmargin">
                                     <div id="deflatdut" style="display: none;"><div style="width: 100%;"><a  class="btn btn-primary munstylcr" style="font-weight: bold;padding: 12px 20px;border: 2px solid #fff !important;width: 100%;" onClick="mobileCheck()">VERIFY EMAIL </a></div></div>
									  <div id="changedut" style="display: none;"><div style="width: 100%;"><a  class="btn btn-primary munstylcr" style="font-weight: bold;padding: 12px 20px;border: 2px solid #fff !important;width: 100%;">SENT EMAIL</a></div></div>
									  <div id="verified" ><div style="width: 100%;"><a  class="btn btn-primary munstylcr" style="font-weight: bold;padding: 12px 20px;border: 2px solid #fff !important;width: 100%;">Verified &#10003;</a></div></div>
									  <div id="used" style="display: none;"><div style="width: 100%;"><a  class="btn btn-primary munstylcr" style="font-weight: bold;padding: 12px 20px;border: 2px solid #fff !important;width: 100%;">Already Verified &#10003;</a></div></div>
									  <div id="extend" style="display: none;"><div style="width: 100%;"><a  class="btn btn-primary munstylcr" style="font-weight: bold;padding: 12px 20px;border: 2px solid #fff !important;width: 100%;">Limit Exceded</a></div></div>
                                     </div>
									  <div id="otpid" style="display: none;">
                                     <div class="row" style="margin-bottom: 10px;">
                                     <div class="col-md-6 col-sm-6 col-xs-6">
                                          <input type="text" class="form-control" id="inotp1" name="inotp1" placeholder="0" maxlength="1" style="width: 50px;float: left;text-align: center;"/>
                                          <input type="text" class="form-control" id="inotp2" name="inotp2" placeholder="0" maxlength="1" style="width: 50px;float: left;text-align: center;" />
                                          <input type="text" class="form-control" id="inotp3" name="inotp3" placeholder="0" maxlength="1" style="width: 50px;float: left;text-align: center;" />
                                          <input type="text" class="form-control" id="inotp4" name="inotp4" placeholder="0" maxlength="1" style="width: 50px;float: left;text-align: center;"  />
                                          <input type="text" class="form-control" id="inotp5" name="inotp5" placeholder="0" maxlength="1" style="width: 50px;float: left;text-align: center;" />
                                          <input type="text" class="form-control" id="inotp6" name="inotp6" placeholder="0" maxlength="1" style="width: 50px;text-align: center;" />
                                         </div>
                                         <div class="col-md-3 col-sm-6 col-xs-6">
                                     <div ><a href="#" class="btn btn-primary munstylcr" style="font-weight: 600;padding: 7px 20px;border: 2px solid #fff !important;" onClick="javascript:mobileverfi1();">Submit</a></div>
                                     </div>
                                </div>
								</div>
								 <div class="col-md-12">
								     <label class="form-label">Home Address * <a data-bs-toggle="modal" data-bs-target="#tooltip7" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a></label>
								 
								 <div class="_3mZgT"><div class="Al5GE"><div class="_3Um38 _2oQ4_"><input type="text" class="_381fS _1oTLG _3BIgv" value="<?php echo $userdata['ADDRESSHIV']; ?>" name="pac-input" id="pac-input" autocomplete="off" tabindex="1" placeholder="Enter your location" maxlength="30" required><div class="_2EeI1 _26LFr"></div><label class="_1Cvlf _2tL9P" for="location"></label></div><div class="_1fiQt" id="getCurrentLocation"><span class="icon-location-crosshair _25lQg"></span><span class="LukWG"><img src="assets/images/icons8-location-off-24.png" alt="Students" style="height: 20px;width: 20px;float: left;">Locate Me</span> </div></div></div>
								 
					 <div class="card-footer" id="infoDisplay" style="display: none;">
                    <h4>Address : <span id="addresshiv"><?php echo $userdata['ADDRESSHIV']; ?></span></h4>
                    <h4>latitude : <span id="latitudehiv"><?php echo $userdata['LATITUDE']; ?></span></h4>
                    <h4>longitude : <span id="longitudehiv"><?php echo $userdata['LONGITUDE']; ?></span></h4>
                    <h4>Postal Code : <span id="pincodehiv"><?php echo $userdata['PINCODE']; ?></span></h4>
                  </div>
                  </div>
                  <input name="addresshiv1" id="addresshiv1" type="hidden" value="" class="form-control" >
					<input name="latitudehiv1" id="latitudehiv1" type="hidden" value="" class="form-control" >
				    <input name="longitudehiv1" id="longitudehiv1" type="hidden" value="" class="form-control" >
				    <input name="pincodehiv1" id="pincodehiv1" type="hidden" value="" class="form-control" >
                                                
                                                <div class="col-md-6 col-sm-12 col-xs-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Ideal Radius *  <?php if($_SESSION['admin_type']=="Tutor"){  ?>
														<a data-bs-toggle="modal" data-bs-target="#tooltip8" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a>
														<?php } else { ?>
														<a data-bs-toggle="modal" data-bs-target="#tooltip9" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a>
														<?php } ?></label>
														
                                                        
                                                          
                                                           <select name="radius" id="radius"  class="form-control" placeholder="Radius">
															<option value="">Select Ideal Radius</option>
																<option value="0.25" <?php if($userdata['RADIUS']=="0.25"){echo "selected";} ?>>Within 1\4 mile</option>
									                            <option value="0.5" <?php if($userdata['RADIUS']=="0.5"){echo "selected";} ?>>Within 1\2 mile</option>
									                              <option value="1" <?php if($userdata['RADIUS']=="1"){echo "selected";} ?>>Within 1 mile</option>
									                              <option value="3" <?php if($userdata['RADIUS']=="3"){echo "selected";} ?>>Within 3 mile</option>
									                               <option value="5" <?php if($userdata['RADIUS']=="5"){echo "selected";} ?>>Within 5 mile</option>
									                               <option value="10" <?php if($userdata['RADIUS']=="10"){echo "selected";} ?>>Within 10 mile</option>
									                               <option value="15" <?php if($userdata['RADIUS']=="15"){echo "selected";} ?>>Within 15 mile</option>
									                               <option value="20" <?php if($userdata['RADIUS']=="20"){echo "selected";} ?>>Within 20 mile</option>
																		
															</select>
															<?php if($userdata['RADIUS']!=""){?><p style="font-size: 13px;font-weight: 600;margin: 0px;">Selected : <?php echo $userdata['RADIUS']; ?> mile</p><?php } ?>
                                                        </div>
                                                    </div> 
                                                    <?php if($_SESSION['admin_type']=="Tutor"){  ?>
                                                    <div class="col-md-6 col-sm-12 col-xs-12">
                                                    <div class="mb-3">
                                                        <label class="form-label" style="margin-bottom: 12px;margin-top: 12px;">Intro Video</label>
                                                        <div class="form-icon position-relative">
                                                            <div class="form-icon position-relative">
                                                            <input type="file" name="thumbimg_file" id="input-file-now" class="form-control"  >
                                                        </div>
                                                        </div>
                                                    </div> 
                                                </div>
                                                <?php }?>
                                            
                                                </div><!--end col-->
												
												<div class="row ">
                                                 <div class="col-md-8">
                                                    <div class="mb-3">
                                                        <label class="form-label" style="padding-bottom: 4px;">Select Hobbies *</label>
                                                        <div class="form-icon position-relative">
														
                                                    <select class="selectpicker show-tick show-menu-arrow" data-live-search="true"  name="hobiesnewad" id="hobiesnewad"  class="form-control" placeholder="Select Hobbies">
															<!--<option value="">Select Hobbies </option>-->
									<?php 
									$statementtutr1 = $tutor_db->prepare("SELECT DISTINCT(MRHOBBY) FROM tutor_app_hobbies WHERE MRSTATUS=? ORDER By MRHOBBY ASC");
                                     $statementtutr1->execute([1]); 
                                    $tutorInterest1 = $statementtutr1->fetchAll(PDO::FETCH_ASSOC); 
                                    if ($tutorInterest1) {
                                    foreach ($tutorInterest1 as $tutrInterest1) { ?>
                                    <option value="<?php echo $tutrInterest1['MRHOBBY']; ?>"><?php echo ucfirst($tutrInterest1['MRHOBBY']); ?></option>
                                   	<?php } } ?>
															</select>
                                                        </div>
                                                    </div> 
                                                </div> 
                                
												<!--end col-->
												
												
												<div class="col-md-4">
												<div class="mb-3">
                                                        <label class="form-label hidemob">&nbsp;</label>
                                                        <div class="form-icon position-relative">
                                                     <a class="btn btn-primary" onClick="return HobbiesAdd()" style="padding: 7px 10px;width: 100%;">ADD</a>   
                                                        </div>
                                                    </div> 
                                                
                                                </div><!--end col-->
												<div id="geteresultH" style="margin-bottom: 20px;">
												<div class="col-md-12">
												<div style="display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; border-radius: 6px; box-shadow: 0 0 3px rgba(60, 72, 88, 0.15);">
                                <table cellpadding="0" cellspacing="0" style="width: 100%;font-size: 14px;">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">No.</th>
											<th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Hobbies</th>
                                            <th scope="col" style="text-align: end; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php 
									$stateedct1 = $tutor_db->prepare("SELECT * FROM TutorHive_userSectHobbies WHERE USER_ID = :USER_ID");
                                    $stateedct1->execute(array(':USER_ID' => $_SESSION['tutor_admin_id'])); 
									$dectionCount1 = $stateedct1->rowCount();
									$ttstateedct1 = $stateedct1->fetchAll(PDO::FETCH_ASSOC);
									$kk1=1;
									foreach ($ttstateedct1 as $getdata1){
									?>
                                        <tr>
                                            <th scope="row" style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $kk1; ?></th>
											 <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $getdata1['HOBBIESNEW']; ?></td>
                                            <td style="text-align: end; padding: 6px; border-top: 1px solid #dee2e6;">
											<a onClick="return DeleteHobbies(<?php echo $getdata1['HOBBI_ID']; ?>)" alt="Delete" title="Delete" class="btn btn-sm btn-primary" style="padding: 2px 6px;"><i class="mdi mdi-delete h6"></i></a>
											</td>
                                        </tr>
										<?php $kk1++;} ?>
                                       
                                    </tbody>
                                </table>
								<input name="hobbeiscunt" id="hobbeiscunt" type="hidden" value="<?php echo $dectionCount1; ?>" >
                            </div>	
												</div>
												</div>
                                            </div>
												
												
												 <?php if($_SESSION['admin_type']=="Tutor"){  ?>
                                               <div class="col-md-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Bio <a data-bs-toggle="modal" data-bs-target="#tooltip11" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a></label>
                                                        <div class="form-icon position-relative">   
                                                   <textarea name="ts_bio" id="ts_bio" rows="3" class="form-control" maxlength="280" > <?php echo $userdata['TEACH_STYLE_BIO'];?></textarea>  
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
												<?php } ?>
												
												  </div><!--end row-->
                                            <div class="row">
                                                <div class="col-sm-12" style="text-align:center;">
                                                    <input type="button" onClick="return validateForm1()" class="btn btn-primary" style="padding: 10px 14px; width:250px;" value="SAVE ">
                                                    <input type="submit" id="submit1" name="submit1" class="btn btn-primary" value="Save" style="display: none;">
                                                </div><!--end col-->
                                            </div><!--end row-->
												
                                                <div style="border-bottom:1px solid #c6c6c6; margin:20px;flex-shrink: 1;"></div>
					
									<div class="card-body">
                                        <h5 class="text-md-start text-center mb-0">Request Hobbies :</h5>
         
                                            <div class="row mt-2">
												<div class="col-md-5">
                                                    <div class="mb-3">
                                                        <div class="form-icon">
                                  <input name="request_hobbies" id="request_hobbies" type="text" value="" class="form-control" placeholder="Request Hobbies :">
                                     </div>
                                     
                                     </div> 
                                     
                                    </div><!--end col-->
									<div class="col-md-5"><a class="btn btn-primary" onClick="return newListhobbies()" style="padding: 7px 10px;">Request</a> </div>		
												
												<!--end col-->
                                            </div><!--end row-->
                                    </div>
												
                                          
                                        </form>
                                    </div>
                                </div>
								</div>
							 <div class="tab-pane fade" id="edction" role="tabpanel" aria-labelledby="edction-tab">
                                 <?php if($userdata['EDUACTIONSTATUS']=="1"){ ?>
								 <div class="row" style="margin: 10px 0px;">
								<div class="col-md-10">
								 <?php if($_GET['succ']=='educat'){?>
							     <p style="font-size: 18px;font-weight: 700;color: #03b303;"> <?php if($_SESSION['admin_type']=="Tutor"){ echo "Tuition Set Up"; }else {echo "Education details";}  ?> has been updated</p>
								 <?php } ?>
								 </div>
								<!--<div class="col-md-2" style="text-align:center;">
								<a class="btn btn-primary" onClick="return profilenext()">NEXT</a>
								</div>-->
								<div class="col-md-2" style="text-align:center" >
								 <?php if($_SESSION['admin_type']=="Tutor"){?>
								<a class="btn btn-primary" href="setavailability-tutor" style="padding: 10px 14px;">NEXT</a>
								<?php }else {?>
								<a class="btn btn-primary" style="float: right;margin-left: 5px;padding: 10px 14px;" id="dechomestu" onClick="return valhomep()">HOME</a>
								<?php } ?>
								 
								</div>
								</div>
							    <?php }else if($userdata['EDUACTIONSTATUS']=="0"){ ?>
							    <p style="font-size: 18px;font-weight: 700;color: #f90303;">Please fill in your information</p>
							    <?php } ?>
                                <div class="card border-0 rounded shadow">
                                    <div class="card-body">
                                        <h5 class="text-md-start text-center mb-0"> <?php if($_SESSION['admin_type']=="Tutor"){ echo "Tuition Set Up"; }else {echo "Your Education";}  ?> : <?php if($_SESSION['admin_type']=="Tutor"){?> <a data-bs-toggle="modal" data-bs-target="#tooltip3" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a> <?php } else { }?></h5>
										
										
          <form name="admindetails2" id="form-box2" action=""  enctype="multipart/form-data" method="post" style="margin-top: 15px;">
                                            <div class="row ">
                                                 <div class="col-md-<?php if($_SESSION['admin_type']=="Tutor"){echo "3";}else{echo "4";}?> ">
                                                    <div class="mb-3">
                                                        <label class="form-label" style="padding-bottom: 4px;">Subject Type *</label>
                                                        <div class="form-icon position-relative">
                                                     <select class="selectpicker show-tick show-menu-arrow" data-live-search="true" onChange="showUser2(this.value)"  name="subjectype" id="subjectype"  class="form-control" placeholder="Subject Type">
															<option value="Academic">Academic</option> 
															<option value="Non-Academic">Non-Academic</option>
															</select>
                                                        </div>
                                                    </div> 
                                                </div> 
                                
												<div class="col-md-<?php if($_SESSION['admin_type']=="Tutor"){echo "5";}else{echo "4";}?>">
                                                    <div class="mb-3" id="subdetsils">
                                                        <label class="form-label"><?php if($_SESSION['admin_type']=="Tutor"){?>Subject(s) To Teach <?php }else { ?>subject to learn<?php }?> * <a data-bs-toggle="modal" data-bs-target="#tooltip4" class="btn" style="padding:0px;"> <img src="assets/images/tooltip-2.svg" class="noteicond"></a></label>					
                                  <div class="form-icon position-relative" id="deflatesc">
                                   <select class="selectpicker show-tick show-menu-arrow" data-live-search="true" id="subject" name="subject" title="Subject">
                                    <option value="" >Subjects</option>
                                  </select>
									 </div>
									  <div class="form-icon position-relative" style="display:none" id="academ">
                                   <select class="selectpicker show-tick show-menu-arrow" data-live-search="true" id="acasubject" name="acasubject" title="Subject">
								    <option value="" >Subjects</option>
								   	<?php 
									$academ="Academic";
									$statementtutr = $tutor_db->prepare("SELECT MRSUBJECT,s_no FROM tutor_app_subjects WHERE MRSTATUS=? AND MRTYPE=? ORDER By MRSUBJECT ASC");
                                     $statementtutr->execute([1,$academ]); 
                                    $tutorInterest = $statementtutr->fetchAll(PDO::FETCH_ASSOC); 
                                    if ($tutorInterest) {
                                    foreach ($tutorInterest as $tutrInterest) { ?>
									
                                    <option value="<?php echo $tutrInterest['MRSUBJECT']; ?>" ><?php echo $tutrInterest['MRSUBJECT']; ?></option>
                                   	<?php } } ?>
                                  </select>
									 </div>
									  <div class="form-icon position-relative" style="display:none" id="nonacadem">
                                    <select class="selectpicker show-tick show-menu-arrow" data-live-search="true" id="nacsubject" name="nacsubject" title="Subject">
									 <option value="" >Subjects</option>
								   	<?php
									$nonacadem="Non-Academic"; 
									$statementtutr = $tutor_db->prepare("SELECT MRSUBJECT,s_no FROM tutor_app_subjects WHERE MRSTATUS=? AND MRTYPE=? ORDER By MRSUBJECT ASC");
                                     $statementtutr->execute([1,$nonacadem]); 
                                    $tutorInterest = $statementtutr->fetchAll(PDO::FETCH_ASSOC); 
                                    if ($tutorInterest) {
                                    foreach ($tutorInterest as $tutrInterest) { ?>
									
                                    <option value="<?php echo $tutrInterest['MRSUBJECT']; ?>" ><?php echo $tutrInterest['MRSUBJECT']; ?></option>
                                   	<?php } } ?>
                                  </select>
									 </div>
                                     </div> 
                                    </div><!--end col-->
												<div class="col-md-<?php if($_SESSION['admin_type']=="Tutor"){echo "4";}else{echo "4";}?>">
                                                    <div class="mb-3">
                                                        <label class="form-label" style="padding-bottom: 4px;"><?php if($_SESSION['admin_type']=="Tutor"){ echo "Level"; }else { echo "Education Level"; }?> *</label>
                                                        <div class="form-icon position-relative">
                                                     <select class="selectpicker show-tick show-menu-arrow" data-live-search="true"  name="education" id="education"  class="form-control" placeholder="Level">
															<!--<option value="">Select Education Level </option>-->
																			<?php 
									$statementtutr = $tutor_db->prepare("SELECT MREDUCATION,s_no FROM tutor_app_education WHERE MRSTATUS=? ORDER By ORDER_NUMBER ASC");
                                     $statementtutr->execute([1]); 
                                    $tutorInterest = $statementtutr->fetchAll(PDO::FETCH_ASSOC); 
                                    if ($tutorInterest) {
                                    foreach ($tutorInterest as $tutrInterest) { ?>
									<option value="<?php echo $tutrInterest['MREDUCATION']; ?>"><?php echo $tutrInterest['MREDUCATION']; ?></option> 
										<?php } } ?>
															</select>
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
												<?php if($_SESSION['admin_type']=="Tutor"){?>
												<div class="col-md-6 col-lg-6 col-xl-3">
                                                    <div class="mb-3">
                                                        <label class="form-label nk2" style="padding-bottom: 4px;">Lesson Method *</label>
                                                        <div class="form-icon position-relative">
                                                     <select class="selectpicker show-tick show-menu-arrow" data-live-search="true"  name="lessoncate" id="lessoncate"  class="form-control" placeholder="Category">
															<!--<option value="">Select Category </option>-->
															<option value="One to One">One to One</option> 
															<option value="Group">Group</option>
															</select>
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
												<div class="col-md-6 col-lg-6 col-xl-3">
                                                    <div class="mb-3">
                                                        <label class="form-label" style="padding-bottom: 4px;">Lesson Type *</label>
                                                        <div class="form-icon position-relative">
                                                     <select class="selectpicker show-tick show-menu-arrow" data-live-search="true" name="typelesson" id="typelesson"  class="form-control" placeholder="Type">
															<!--<option value="">Select Lesson Type </option>-->
															<option value="In-person">In-person</option> 
															<option value="Online">Online</option>
															</select>
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
												<div class="col-md-6 col-lg-6 col-xl-4">
                                                    <div class="mb-3">
                                                        <label class="form-label nk1" style="margin-bottom:10px;">Price/Hr per student *</label>
                                                        <div class="form-icon position-relative">
                                                      <input name="pricelesson"  id="pricelesson" type="text" onKeyDown="return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )" maxlength="5" value="" class="form-control" placeholder="Price Of Lesson :" style="background-color: #f8f9fa;border-radius:0px;line-height:0px;">
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
												<?php } else { ?>
												<input name="lessoncate" id="lessoncate" type="hidden" value="No" >
												<input name="typelesson" id="typelesson" type="hidden" value="No" >
												<input name="pricelesson" id="pricelesson" type="hidden" value="No" >
												<?php } ?>
												<div class="col-md-<?php if($_SESSION['admin_type']=="Tutor"){echo "4";}else{echo "12";}?> col-lg-<?php if($_SESSION['admin_type']=="Tutor"){echo "4";}else{echo "12";}?> col-xl-<?php if($_SESSION['admin_type']=="Tutor"){echo "2";}else{echo "12";}?>" style="text-align:center;">
												<div class="mb-3">
                                                       <?php if($_SESSION['admin_type']=="Tutor"){?> <label class="form-label hidemob">&nbsp;</label><?php } ?>
                                                        <div class="form-icon position-relative">
                                                     <a class="btn btn-primary ph" onClick="return Educationadd()" style="padding: 5px 7px;">ADD</a>   
                                                        </div>
                                                    </div> 
                                                
                                                </div><!--end col-->
												<div id="geteresult" style="margin-bottom: 20px;">
												<div class="col-md-12">
												<div style="display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; border-radius: 6px; box-shadow: 0 0 3px rgba(60, 72, 88, 0.15);">
                                <table cellpadding="0" cellspacing="0" style="width: 100%;font-size: 14px;">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">No.</th>
											<th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Subject Type</th>
                                            <th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Subjects</th>
											<th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Level</th>
											<?php if($_SESSION['admin_type']=="Tutor"){?>
											<th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Lesson Type</th>
											<th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Lesson Location</th>
											<th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Price/Hr per student</th>
											<?php } ?>
                                            <th scope="col" style="text-align: end; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php 
									$stateedct = $tutor_db->prepare("SELECT * FROM TutorHive_educatioNs WHERE USER_ID = :USER_ID order by SUBJECTS ASC");
                                    $stateedct->execute(array(':USER_ID' => $_SESSION['tutor_admin_id'])); 
									$dectionCount = $stateedct->rowCount();
									$ttstateedct = $stateedct->fetchAll(PDO::FETCH_ASSOC);
									$kk=1;
									foreach ($ttstateedct as $getdata){
									?>
                                        <tr>
                                            <th scope="row" style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $kk; ?></th>
											 <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $getdata['TYPE_SUBJECT']; ?></td>
                                            <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $getdata['SUBJECTS']; ?></td>
											 <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $getdata['ED_LEVEL']; ?></td>
											 <?php if($_SESSION['admin_type']=="Tutor"){?>
											  <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $getdata['CAT_LESSON']; ?></td>
											   <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $getdata['TYPE_LESSON']; ?></td>
											    <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"> £ <?php echo $getdata['PRICE_LE']; ?></td>
												<?php } ?>
                                            <td style="text-align: end; padding: 6px; border-top: 1px solid #dee2e6;">
											<a onClick="return Deleteeduct(<?php echo $getdata['EAUTO_ID']; ?>)" alt="Delete" title="Delete" class="btn btn-sm btn-primary" style="padding: 2px 6px;"><i class="mdi mdi-delete h6"></i></a>
											</td>
                                        </tr>
										<?php $kk++;} ?>
                                       
                                    </tbody>
                                </table>
								<input name="toteducount" id="toteducount" type="hidden" value="<?php echo $dectionCount; ?>" >
                            </div>	
												</div>
												</div>
												
												<div style="border-bottom:1px solid #c6c6c6; margin:20px;flex-shrink: 1;"></div>
                                                 
												<?php if($_SESSION['admin_type']=="Tutor"){?>
                                                <div class="col-md-6 col-sm-12 col-xs-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Teaching Style * <a data-bs-toggle="modal" data-bs-target="#tooltip5" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a></label>
                                                        <div class="form-icon position-relative">
                                                          <select class="selectpicker show-tick show-menu-arrow" data-live-search="true" multiple  id="teach_style" name="teach_style" title="Teaching Style">
                                                              
								   	<?php 
									$statementtutr = $tutor_db->prepare("SELECT TEACHING_STYLE FROM tutor_app_teaching WHERE STATUS=?");
                                     $statementtutr->execute([1]); 
                                    $tutorInterest = $statementtutr->fetchAll(PDO::FETCH_ASSOC); 
                                    if ($tutorInterest) {
                                    foreach ($tutorInterest as $tutrInterest) { ?>
                                    <option value="<?php echo $tutrInterest['TEACHING_STYLE']; ?>" <?php if($tutrInterest['TEACHING_STYLE']==$userdata['TEACH_STYLE']){ echo "selected";} ?>><?php echo $tutrInterest['TEACHING_STYLE']; ?></option>
                                   	<?php } } ?>
                                  </select>
								   <input name="teach_style1" id="teach_style1" type="hidden" value="<?php echo $userdata['TEACH_STYLE']; ?>" class="form-control" style="display: none;">
								   <input name="teach_style2" id="teach_style2" type="hidden" value="" class="form-control" style="display: none;">
                                   <input name="learn_style" id="learn_style" type="hidden" value="No" class="form-control" style="display: none;">
								   <input name="learn_style1" id="learn_style1" type="hidden" value="No" class="form-control" style="display: none;">
								   <input name="learn_style2" id="learn_style2" type="hidden" value="No" class="form-control" style="display: none;">
                                   <?php if($userdata['TEACH_STYLE']!=""){?><p style="font-size: 13px;font-weight: 600;margin: 0px;">Selected : <?php echo $userdata['TEACH_STYLE']; ?></p><?php } ?>
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
                                                <?php } else { ?>
                                                 <div class="col-md-6 col-sm-12 col-xs-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Learning Style * <a data-bs-toggle="modal" data-bs-target="#tooltip6" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a></label>
														
                                                        <div class="form-icon position-relative">
                                                          <select class="selectpicker show-tick show-menu-arrow" data-live-search="true" multiple  id="learn_style" name="learn_style" title="Learning Style">
                                                             
								   	<?php 
									$statementtutr = $tutor_db->prepare("SELECT LEARNING_STYLE FROM tutor_app_learning WHERE STATUS=?");
                                     $statementtutr->execute([1]); 
                                    $tutorInterest = $statementtutr->fetchAll(PDO::FETCH_ASSOC); 
                                    if ($tutorInterest) {
                                    foreach ($tutorInterest as $tutrInterest) { ?>
                                    <option value="<?php echo $tutrInterest['LEARNING_STYLE']; ?>" <?php if($tutrInterest['LEARNING_STYLE']==$userdata['LEARN_STYLE']){ echo "selected";} ?>><?php echo $tutrInterest['LEARNING_STYLE']; ?></option>
                                   	<?php } } ?>
                                  </select>
								   <input name="learn_style1" id="learn_style1" type="hidden" value="<?php echo $userdata['LEARN_STYLE']; ?>" class="form-control" style="display: none;">
								   <input name="learn_style2" id="learn_style2" type="hidden" value="" class="form-control" style="display: none;">
                                   <?php if($userdata['LEARN_STYLE']!=""){?><p style="font-size: 13px;font-weight: 600;margin: 0px;">Selected : <?php echo $userdata['LEARN_STYLE']; ?></p><?php } ?>
                                  
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
                                                 <input name="teach_style" id="teach_style" type="hidden" value="No" class="form-control" style="display: none;">
												  <input name="teach_style1" id="teach_style1" type="hidden" value="No" class="form-control" style="display: none;">
								                 <input name="teach_style2" id="teach_style2" type="hidden" value="No" class="form-control" style="display: none;">
                                                <?php } ?>
                                               
                                            </div><!--end row-->
                                            <div class="row">
                                                <div class="col-sm-12" style="text-align:center;">
                                                    <input type="button" onClick="return validateForm2()" style="padding: 10px 14px; width:250px;" class="btn btn-primary" value="SAVE">
                                                    <input type="submit" id="submit2" name="submit2" class="btn btn-primary" value="Save" style="display: none;">
                                                </div><!--end col-->
                                            </div><!--end row-->
                                        </form>
                                    </div>
									
									<div style="border-bottom:1px solid #c6c6c6; margin:20px;flex-shrink: 1;"></div>
					
									<div class="card-body">
                                        <h5 class="text-md-start text-center mb-0">Request subjects and level :</h5>
         
                                            <div class="row ">
												<div class="col-md-5">
                                                    <div class="mb-3">
                                                        <label class="form-label">Request Subject </label>
                                                        <div class="form-icon position-relative">
                                  <input name="request_subject" id="request_subject" type="text" value="" class="form-control" placeholder="Request Subject :">
                                     </div>
                                     </div> 
                                    </div><!--end col-->
												<div class="col-md-5">
                                                    <div class="mb-3">
                                                        <label class="form-label"> Education Level *</label>
                                                        <div class="form-icon position-relative">
														 <select class="selectpicker show-tick show-menu-arrow" data-live-search="true"  name="request_level" id="request_level"  class="form-control" placeholder="Education Level" onChange="showUser3(this.value)">
															<!--<option value="">Select Education Level </option>-->
																			<?php 
									$statementtutr = $tutor_db->prepare("SELECT MREDUCATION,s_no FROM tutor_app_education WHERE MRSTATUS=? ORDER By ORDER_NUMBER ASC");
                                     $statementtutr->execute([1]); 
                                    $tutorInterest = $statementtutr->fetchAll(PDO::FETCH_ASSOC); 
                                    if ($tutorInterest) {
                                    foreach ($tutorInterest as $tutrInterest) { ?>
									<option value="<?php echo $tutrInterest['MREDUCATION']; ?>"><?php echo $tutrInterest['MREDUCATION']; ?></option> 
										<?php }?>
										<option value="New">Other</option> 
										<?php } ?>
															</select>
														
														
                                               <!--<input name="request_level" id="request_level" type="text" value="" class="form-control" placeholder="Request Education Level :">      -->
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
												<div class="col-md-5" style="display:none;" id="neweducation">
                                                    <div class="mb-3">
                                                        <label class="form-label">Request Education Level </label>
                                                        <div class="form-icon position-relative">
                                  <input name="request_delevel" id="request_delevel" type="text" value="" class="form-control" placeholder="Request Education Level :">
                                     </div>
                                     </div> 
                                    </div>
												<div class="col-md-1">
												<div class="mb-3">
                                                        <label class="form-label" hidemob>&nbsp;</label>
                                                        <div class="form-icon position-relative">
                                                     <a class="btn btn-primary" onClick="return Requestsubjle()" style="padding: 7px 10px;">Request</a>   
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
                                            </div><!--end row-->
                                    </div>	
                                    
                                </div>
								</div>
							 
                                  <?php if($_SESSION['admin_type']=="Tutor"){?>   
								  <div class="tab-pane fade" id="inbox" role="tabpanel" aria-labelledby="inbox-tab">
                                <?php  if($userdata['DOCSTATUS']=="1"){ ?>
								<div class="row" style="margin: 10px 0px;">
								<div class="col-md-10">
								 <?php if($_GET['succ']=='doc'){?>
							    <p style="font-size: 18px;font-weight: 700;color: #03b303;">Documents have uploaded successfully</p>
								 <?php } ?>
								</div>
								 <div class="col-md-2" style="text-align:center;">
								<a class="btn btn-primary" id="paynextidtut" style="padding: 10px 14px;" onClick="return paymentnext()">NEXT</a>
								</div>
								</div>
							    <?php }else if($userdata['DOCSTATUS']=="0"){ ?>
							    <p style="font-size: 18px;font-weight: 700;color: #f90303;;">Please upload your relevant documents </p>
							    <?php } ?>
                                <div class="card border-0 rounded shadow">
                                    <div class="card-body">
                                        <h5 class="text-md-start text-center mb-0"> <?php echo $_SESSION['admin_type']; ?> Documents Upload : <a data-bs-toggle="modal" data-bs-target="#tooltip2" class="btn m-1" style="padding:0px;"> <img src="assets/images/tooltip-2.svg"  style="height: 30px;width: 30px;"></a></h5>
										
                                         <?php 
                                       $stmt1 = $tutor_db->prepare("SELECT labels_content,rand_id FROM tutor_app_labels WHERE labels_type=:labels_type");
                                       $stmt1->execute(['labels_type' => 'Signup Upload Document 1']); 
                                       $user1 = $stmt1->fetch();
                                       ?>
									     <form name="admindetails" id="form-box45" action=""  enctype="multipart/form-data" method="post" >
                                            <div class="row mt-4">
                                                <div class="col-md-5">
                                                    <div class="mb-3">
                                                       
                                                        <label class="form-label"><?php echo $user1['labels_content']; ?> *</label>
                                                        <div class="form-icon position-relative">
                                                             
                                                            <select name="doctype1" id="doctype1"  class="form-control" placeholder="Documents Type" >
															<option value="">Select Type </option>
																<?php 
									$statementtutr1 = $tutor_db->prepare("SELECT document_type FROM tutor_app_documents WHERE status=?");
                                     $statementtutr1->execute([1]); 
                                    $tutorInterest1 = $statementtutr1->fetchAll(PDO::FETCH_ASSOC); 
                                    if ($tutorInterest1) {
                                    foreach ($tutorInterest1 as $tutrInterest1) { ?>
                                    	<option value="<?php echo $tutrInterest1['document_type']; ?>"><?php echo $tutrInterest1['document_type']; ?></option>
                                   	<?php } } ?>
														
														
															</select>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
                                                <div class="col-md-5">
                                                    <div class="mb-3">
                                                        <label class="form-label hidemob">&nbsp;</label>
                                                        <div class="form-icon position-relative">
                                                            <input name="docfile7" id="docfile7" type="file" class="form-control"  >
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
												<div class="col-md-2">
												<div class="mb-3">
                                                        <label class="form-label hidemob">&nbsp;</label>
                                                        <div class="form-icon position-relative">
														 <a class="btn btn-primary" onClick="return Docmentadd()" style="padding: 7px 10px;width: 100%;">ADD</a> 
                                                        </div>
                                                    </div> 
                                                </div>
												
                                            </div><!--end row-->
                                          	
<div id="geteresult1" style="margin-bottom: 20px;">
												<div class="col-md-12">
												<div style="display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; border-radius: 6px; box-shadow: 0 0 3px rgba(60, 72, 88, 0.15);">
                                <table cellpadding="0" cellspacing="0" style="width: 100%;font-size: 14px;">
                                    <thead class="bg-light">
                                        <tr>
                                            <th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">No.</th>
											<th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Document Type</th>
                                            <th scope="col" style="text-align: left; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Documents</th>
                                            <th scope="col" style="text-align: end; vertical-align: bottom; border-top: 1px solid #dee2e6; padding: 6px;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
									
									<?php 
									$stateedct = $tutor_db->prepare("SELECT * FROM TutorHive_tutorDocment WHERE USER_ID = :USER_ID ORDER BY TYPE_DOCMENT ASC");
                                    $stateedct->execute(array(':USER_ID' => $_SESSION['tutor_admin_id'])); 
									$dectionCount = $stateedct->rowCount();
									$ttstateedct = $stateedct->fetchAll(PDO::FETCH_ASSOC);
									$kk=1;
									foreach ($ttstateedct as $getdata){
									?>
                                        <tr>
                                            <th scope="row" style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $kk; ?></th>
											 <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><?php echo $getdata['TYPE_DOCMENT']; ?></td>
                                            <td style="text-align: left; padding: 6px; border-top: 1px solid #dee2e6;"><a href="<?php echo $getdata['FILE_DOCMENT']; ?>" target="_blank" class="btn btn-primary" style="font-size: 12px;font-weight: 600;padding: 2px 4px;margin-top: 5px;">View Document</a></td>
                                            <td style="text-align: end; padding: 6px; border-top: 1px solid #dee2e6;">
											<a onClick="return Deletedocment(<?php echo $getdata['EAUTO_ID']; ?>)" alt="Delete" title="Delete" class="btn btn-sm btn-primary" style="padding: 2px 6px;"><i class="mdi mdi-delete h6"></i></a>
											</td>
                                        </tr>
										<?php $kk++;} ?>
                                       
                                    </tbody>
                                </table>
								<input name="totaldocount" id="totaldocount" type="hidden" value="<?php echo $dectionCount; ?>" >
                            </div>	
												</div>
												</div>

  <div class="row">
                                                <div class="col-sm-12" style="text-align: center;">
                                                    <input type="button" onClick="return validateForm()" style="padding: 10px 14px; width:250px;" class="btn btn-primary" value="SAVE">
                                                    <input type="submit" id="submit" name="submit" class="btn btn-primary" value="Save" style="display: none;">
                                                </div><!--end col-->
                                            </div><!--end row-->
										</form>
                                    </div>
                                </div>
								</div> 
								  
								<div class="tab-pane fade rounded p-4 shadow" id="spam" role="tabpanel" aria-labelledby="spam-tab">
								    <div class="row" style="margin: 10px 0px;">
								<div class="col-md-8">
								    <?php if($_SESSION['admin_type']=="Tutor"){  
                                 if($userdata['TUTORDOC_STATUS']=="0"){ ?>
							     <p style="font-size: 18px;font-weight: 700;color: #f90303;">Initial registration is complete. Your account is under review for the the tuition marketplace. You will be notified via email once approved. However, you can still reap the benefits of TutorHive by using the rest of the platform.</p>
							     <?php } } ?>
								  <?php if($_GET['succ']=='paymt'){?>
							     <p style="font-size: 18px;font-weight: 700;color: #03b303;">Payment Details Updated Successfully </p>
								 <?php } ?>
								  </div>
								<div class="col-md-4">
								 <?php if($_SESSION['admin_type']=="Tutor"){  
                                 if($userdata['DOCSTATUS']=="1"){ ?>
								<a class="btn btn-primary" style="float: right;padding: 10px 14px;" onClick="return valhomep()">HOME</a>
							<?php } }else {?>
								<a class="btn btn-primary" style="float: right;padding: 10px 14px;" onClick="return valhomep()">HOME</a>
							<?php 	}?>
								</div>
								</div>
                                <div class="card border-0 rounded shadow">
                                    <div class="card-body">
                                        <h5 class="text-md-start text-center mb-0"> Payment Method :</h5>
                                        <form name="paymentdetail" id="form-box1" action=""  enctype="multipart/form-data" method="post" >
                                            <div class="row" style="margin: 15px 0px;">
                                                <div class="col-md-16">
                                                    <div class="mb-3">
                                                        <label class="form-label">Account Name *</label>
                                                        <div class="form-icon position-relative">
                                                           
                                                            <input name="acounrname" id="acounrname"  type="text" class="form-control" placeholder="Name" value="<?php echo $userdata['CARDHOLDER']; ?>">
                                                        </div>
                                                    </div> 
                                                </div>
                                                <!--end col-->
                                                <div class="col-md-16">
                                                    <div class="mb-3">
                                                        <label class="form-label">Sort Code *</label>
                                                        <div class="form-icon position-relative">
                                                           
                                                            <input name="sortcode" id="sortcode" onKeyDown="return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )" maxlength="6" type="text" class="form-control" placeholder="323232" value="<?php echo $userdata['EXPDATE']; ?>">
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
												<div class="col-md-16">
                                                    <div class="mb-3">
                                                        <label class="form-label">Account No *</label>
                                                        <div class="form-icon position-relative">
                                                            
                                                            <input name="number" id="accountno" onKeyDown="return ( event.ctrlKey || event.altKey 
                    || (47<event.keyCode && event.keyCode<58 && event.shiftKey==false) 
                    || (95<event.keyCode && event.keyCode<106)
                    || (event.keyCode==8) || (event.keyCode==9) 
                    || (event.keyCode>34 && event.keyCode<40) 
                    || (event.keyCode==46) )" maxlength="10" type="text" class="form-control" placeholder="12121212" value="<?php echo $userdata['CARDNO']; ?>">
                                                        </div>
                                                    </div>
                                                </div>
                                               <!-- <div class="col-md-6">
                                                    <div class="mb-3">
                                                        <label class="form-label">IBAN Number</label>
                                                        <div class="form-icon position-relative">
                                                           
                                                            <input name="ibannumber" id="ibannumber" maxlength="20" type="text" class="form-control" placeholder="" value="<?php echo $userdata['CVC']; ?>">
                                                        </div>
                                                    </div> 
                                                </div><!--end col-->
                                                <!--end col-->
                                            </div><!--end row-->
                                            <div class="row">
                                                <div class="col-sm-12" style="text-align:center;">
                                                    
													 <input type="button" onClick="return validatepayd()" style="padding: 10px 14px; width:250px;" class="btn btn-primary" value="SAVE ">
                                                    <input type="submit" id="submit4" name="submit4" class="btn btn-primary" value="Save" style="display: none;">
                                                </div><!--end col-->
                                            </div><!--end row-->
                                       </form>
                                    </div>
                                </div>
								</div>
								<?php } ?>
								
								</div>
                            </div>
                        </div><!--end row-->
                    </div>
                </div><!--end container-->

                <!-- Footer Start -->
                <footer class="shadow py-3">
                    <div class="container-fluid">
                        <div class="row align-items-center">
                            <div class="col">
                                <div class="text-sm-start text-center mx-md-2">
                                    <p class="mb-0 text-center">Copyright &copy;
									<script>document.write(new Date().getFullYear())</script> TutorHive. All Rights Reserved </p>
                                </div>
                            </div><!--end col-->
                        </div><!--end row-->
                    </div><!--end container-->
                </footer><!--end footer-->
                <!-- End -->
            </main>
            <!--End page-content" -->
        </div>
        
        	<a class="button" id="ClickModal3" data-bs-toggle="modal" data-bs-target="#wishlist" style="display:none">Let me Pop up</a>
	<a data-bs-toggle="modal" id="ClickModal4" data-bs-target="#LoginForm" class="btn btn-primary m-1" style="display:none" > Click Here</a>
	<button type="button" id="ClickModal5" class="btn btn-secondary" data-dismiss="modal" style="display:none">Close</button>
        	<div class="modal fade" id="LoginForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true" style="display: none;">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                
                                                <div class="modal-body">
                                                    <div class="bg-white p-3 rounded box-shadow">
                                                        <div class="row">
                                                        <div class="col-md-3 col-sm-4 col-xs-4">&nbsp;</div>
                                                        <div class="col-md-6 col-sm-4 col-xs-4">
                                                        <div class="loader"></div> 
                                                        </div>
                                                        </div>
														<p style="text-align: center;padding: 15px;font-weight: 600;">Uploading... Please wait!</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                </div>
                                            </div>
                                        </div>
										
										<div class="modal fade" id="wishlist" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered popwithdstyle">
                                            <div class="modal-content rounded shadow border-0">
                                                 <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="closserrrr" style="float: right;"><i class="uil uil-times fs-4 text-dark"></i></button>
                                                <div class="modal-body py-5" style="background-color: #ffd85d;">
                                                    <div class="text-center">
                                       
				
				
				    <p style="font-size: 22px;font-weight: 600;">Upload Your Profile Pic here</p>
					<div class="image_area" id="hidetapafc">
						<form method="post">
							<label for="upload_image" >
							    
  <?php if($userdata['PROFILE_PIC']!=""){?>
  <svg class="imagechang" viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg" >
                                                                      <defs>
                                                                       <pattern id="img<?php echo $userdata['USER_ID'] ?>5" patternUnits="userSpaceOnUse" width="100" height="100">
                                                              <image xlink:href="<?php echo $userdata['PROFILE_PIC'] ?>" id="uploaded_image"  x="-25" width="150" height="100" />
                                                                        </pattern>
                                                                      </defs>
                                                                      <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img<?php echo $userdata['USER_ID'] ?>5)" stroke-linejoin="round" stroke="#000" stroke-width="3"/>
                                                                    </svg>
 
 <?php }else {?>
 <svg viewBox="0 0 100 100" version="1.1" xmlns="http://www.w3.org/2000/svg"  style="width:300px;height:300px;">
                                                                      <defs>
                                                                       <pattern id="img<?php echo $userdata['USER_ID'] ?>5" patternUnits="userSpaceOnUse" width="100" height="100">
                                                                      <image xlink:href="assets/images/profileicon.png" id="uploaded_image"  x="-25" width="150" height="100" />
                                                                        </pattern>
                                                                      </defs>
                                                                      <polygon points="50 1 95 25 95 75 50 99 5 75 5 25" fill="url(#img<?php echo $userdata['USER_ID'] ?>5)" stroke-linejoin="round" stroke="#000" stroke-width="3"/>
                                                                    </svg>
 <?php } ?>
 
							    
							<!--	<img src="<?php echo $userdata['PROFILE_PIC'];?>" id="uploaded_image" style="border-radius: 50%;" />-->
								<div class="overlay">
									<div class="text">Click to Change Profile Image</div>
								</div>
								<input type="file" name="image" class="image" id="upload_image" style="display:none" />
							</label>
						</form>
						 <p id="picsuccess" style="font-size: 20px;font-weight: 600;color: green; display: none;">Successfully uploaded your profile pic</p>
					
					</div>
			   
    					
	
                                         
                                                    <div class="mt-4">
                                                             <div class="form-floating mb-2" id="closeid" style="display: none;">
                                  <button class="btn btn-primary " data-bs-dismiss="modal" id="close-modal">Done</button>
                                </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
										
										<div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
			  	<div class="modal-dialog modal-lg" role="document" style="width: 100%;max-width:600px!important;">
			    	<div class="modal-content" style="width: 100%;">
			      		<div class="modal-header">
			        		<h5 class="modal-title">Crop Image Before Upload</h5>
			        		<button type="button" class="close" data-bs-dismiss="modal" id="incloseeeee" aria-label="Close">
			          			<span aria-hidden="true">×</span>
			        		</button>
			      		</div>
			      		<div class="modal-body">
			        		<div class="img-container" >
			            		<div class="row">
			                		
			                    		<img src="" id="sample_image" />
			                		<div class="col-md-4">
			                    		<div class="preview"></div>
			                		</div>
			            		</div>
			        		</div>
			      		</div>
			      		<div class="modal-footer">
			      			<button type="button" id="crop" class="btn btn-primary">Crop</button>
			        		<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" id="close-modal">Cancel</button>
			      		</div>
			    	</div>
			  	</div>
			</div>
										
        
         <div class="modal fade" id="changepass" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered popwithdstyle1">
                                            <div class="modal-content rounded shadow border-0">
                                                 <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal" style="float: right;"><i class="uil uil-times fs-4 text-dark"></i></button>
                                                <div class="modal-body py-5" style="background-color: #ffd85d;">
                                                    <div class="text-center">
													<p style="font-weight: 700;color: red;display:none;" id="psaaerror">Invalid Old Password ...! Please try again</p>
													<p style="font-weight: 700;color: green; display:none;" id="psaasuccess">Your Password updated successfully</p>
													</div>
                                         <div class="row">
				<div class="col-md-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Old Password</label>
                                                        <div class="form-icon position-relative">
                                                           
                                                            <input name="oldpassword" id="oldpassword" type="password" value="" class="form-control" placeholder="Old Password">
															<span id="passeyeold" class="field-icon" style="display: none;"><a href="#" onClick="javascript:hidepass2();" ><img src="assets/images/icons8-eye-50.png" alt="Students" style="height: 40px;width: 40px;"></a></span>
									<span id="passhideold" class="field-icon"><a href="#" onClick="javascript:hidepass2();" ><img src="assets/images/4944531.png" alt="Students" style="height: 35px;width: 35px;"></a></span>
									
                                                        </div>
                                                    </div>
                                                </div>
												<div class="col-md-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">New Password</label>
                                                        <div class="form-icon position-relative">
                                                           
                                                            <input name="password" id="password" type="password" value="" class="form-control" placeholder="New Password">
															<span id="passeye" class="field-icon" style="display: none;"><a href="#" onClick="javascript:hidepass1();" ><img src="assets/images/icons8-eye-50.png" alt="Students" style="height: 40px;width: 40px;"></a></span>
									<span id="passhide" class="field-icon"><a href="#" onClick="javascript:hidepass1();" ><img src="assets/images/4944531.png" alt="Students" style="height: 35px;width: 35px;"></a></span>
										<p id="message" style="display: none; margin: 0px;"><span id="capital" class="invalid">uppercase</span> <span id="number" class="invalid">number</span> <span id="length" class="invalid">Minimum 8</span></p>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
												<div class="col-md-12">
                                                    <div class="mb-3">
                                                        <label class="form-label">Confirm Password</label>
                                                        <div class="form-icon position-relative">
                                                            <input name="confassword" id="confassword" type="password" value="" class="form-control" placeholder="Confirm New Password">
															<span id="conpasseye" class="field-icon" style="display: none;"><a href="#" onClick="javascript:hidepass();" ><img src="assets/images/icons8-eye-50.png" alt="Students" style="height: 40px;width: 40px;"></a></span>
									<span id="conpasshide" class="field-icon"><a href="#" onClick="javascript:hidepass();" ><img src="assets/images/4944531.png" alt="Students" style="height: 35px;width: 35px;"></a></span>
									                                	<p id="message1" style="display: none; margin: 0px;"><span id="match" class="invalid">Matched</span></p>
                                                        </div>
                                                    </div>
                                                </div><!--end col-->
    					
		</div>
                                         
                                                    <div class="mt-4">
                                                             <div class="form-floating mb-2" style="text-align: center;">
                                  <span id="butchanp1" style="display:none;">
                                      <button class="btn btn-primary " data-bs-dismiss="modal" type="button" id="close-modal" style="border: 1px solid #000;font-weight: 900; ">Close</button>
                                      </span>
								    <span id="butchanp">
								        <button class="btn btn-primary" onClick="return chnagepaSSw()" type="button" style="border: 1px solid #000;font-weight: 900;">Change Password</button>
                                </span>
                                </div>
                                                            
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
        
        <!-- page-wrapper -->

        <!-- Offcanvas Start -->
        
        <!-- Offcanvas End -->
        
        <!-- javascript -->
        <!-- JAVASCRIPT -->
      <?php include('common/footerlinks.php');?>
	  <div class="modal fade" id="tooltip1" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">To continue using all of TutorHive’s features, we need you to fill out all your details . This will take between 5-10 minutes to complete so please be patient</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip2" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">We need to verify your credentials to make sure we take all the necessary steps to safeguard our students. Please have all the related documents at hand. This includes ID, proof of address, qualifications and any other related material</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip3" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">Please fill out the subjects you would like to teach with the Level, Lesson Method, Lesson Type and Price. You will have to individually input each subject with the various fields. Please input chronologically by selecting every level for the subject and then choosing, 1 to 1: In- Person, 1 to 1: Online, Group: In-person & Group: Online - according to your lesson plan.</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip4" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">If the subject you are looking for is not shown, please use the ‘Request Subject and Level’ fields.</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip5" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">Our algorithm for best match considers the teaching style of tutors to the learning style of students. Please select from the list. Kinesthetic - use body movement to interact, Auditory - Teaching through sound and listening, Visual - Using pictures and images for teaching Read & Write - traditional textbook teaching with note taking</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip6" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">Our algorithm for best match considers the learning style of students to the learning style of students. Please select from the list:<br><br>
1.	Kinesthetic - use body movement to interact.<br>
2.	Auditory - Learning through sound and listening.<br>
3.	Visual - Using pictures and images for
learning.<br>
4.	Read & Write - examples reading notes, handouts and textbooks.
</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip7" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">Please start by typing in the beginning of your home address and click one of the google suggestions (door number isn’t necessary). Do not try manually entering or correcting a set address as this will hinder your search functionality.</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip8" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">Please select the radius from your address you are available to teach.</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip9" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">This will help you find a tutor that is close to you with your preferred radius.</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip10" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">This is to connect you to the right student with the same hobbies and interests through our Hive Matching Algorithm.</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
									<div class="modal fade" id="tooltip11" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                            <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header">
												<p class="text-muted mb-0">Describe a bit about yourself and your character so that students can see.</p>                                 
                                                    <button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" id="close-modal"><i class="uil uil-times fs-4 " style="color:#FF0000;"></i></button>
													       
                                                </div>
                                            </div>
                                        </div>
                                    </div>
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
     
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/js/bootstrap-select.min.js" integrity="sha512-FHZVRMUW9FsXobt+ONiix6Z0tIkxvQfxtCSirkKc5Sb4TKHmqq1dZa8DphF0XqKb3ldLu/wgMa8mT6uXiLlRlw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
		 <?php if($_GET['succ']=='educat'){?>
			            <script>
						$(document).ready(function(){
						 <?php if($_SESSION['admin_type']=="Tutor"){ ?>
			            document.getElementById("inbox-tab").click();
						<?php } else { ?>
						  document.getElementById("dechomestu").click();
						<?php } ?>
						});
			            </script>
			  <?php } if($_GET['succ']=='profile'){?>
			   <script>
						$(document).ready(function(){
			            document.getElementById("edcredi").click();
						});
			            </script>
			  <?php } if($_GET['succ']=='paymt'){?>
			   <script>
						$(document).ready(function(){
			            document.getElementById("spam-tab").click();
						});
			            </script>
			   <?php } if($_GET['succ']=='doc'){?>
			   <script>
						$(document).ready(function(){
			            document.getElementById("paynextidtut").click();
						});
			            </script>
			  
			  <?php } ?>
			  
			   <script>
	  function showUser2(val){
  // alert(val);
	if(val=="Academic"){
	document.getElementById('nacsubject').value = "";
	
 document.getElementById("deflatesc").style.display = "none";
 document.getElementById("academ").style.display = "block";
 document.getElementById("nonacadem").style.display = "none";
}else if(val=="Non-Academic") {
document.getElementById('acasubject').value = "";
 document.getElementById("deflatesc").style.display = "none";
 document.getElementById("academ").style.display = "none";
 document.getElementById("nonacadem").style.display = "block"; 
}else {
document.getElementById("deflatesc").style.display = "block";
 document.getElementById("academ").style.display = "none";
 document.getElementById("nonacadem").style.display = "none"; 
}
}
 function showUser3(val){
 if(val=="New"){
 document.getElementById("neweducation").style.display = "block";
 }else {
 document.getElementById("neweducation").style.display = "none";
 }
}
	  </script>
			  
			  <script>
			  $(document).ready(function() {
  $(function() {
    var creditly = Creditly.initialize(
      ".expiration-month-and-year",
      ".credit-card-number",
      ".security-code",
      ".card-type"
    );
    $(".payment__confirm").click(function(e) {
      e.preventDefault();
      var output = creditly.validate();
$ele = $(".expiration-month-and-year");
	  var today = new Date();
      if (output) {
        // Your validated credit card output
        console.log(output);
		if(output.expiration_year < today.getFullYear()){
			$ele.next().show().text("Card is expired.");
		}
		else{
			$ele.next().hide();
		}
      }
    });
  });
});
var Creditly = (function() {
  var getInputValue = function(e, selector) {
    var inputValue = $.trim($(selector).val());
    inputValue = inputValue + String.fromCharCode(e.which);
    return getNumber(inputValue);
  };

  var getNumber = function(string) {
    return string.replace(/[^\d]/g, "");
  };

  var reachedMaximumLength = function(e, maximumLength, selector) {
    return getInputValue(e, selector).length > maximumLength;
  };

  // Backspace, delete, tab, escape, enter, ., Ctrl+a, Ctrl+c, Ctrl+v, home, end, left, right
  var isEscapedKeyStroke = function(e) {
    return ( $.inArray(e.which,[46,8,9,0,27,13,190]) !== -1 ||
      (e.which == 65 && e.ctrlKey === true) || 
      (e.which == 67 && e.ctrlKey === true) || 
      (e.which == 86 && e.ctrlKey === true) || 
      (e.which >= 35 && e.which <= 39));
  };

  var isNumberEvent = function(e) {
    return (/^\d+$/.test(String.fromCharCode(e.which)));
  };

  var onlyAllowNumeric = function(e, maximumLength, selector) {
    e.preventDefault();
    // Ensure that it is a number and stop the keypress
    if (reachedMaximumLength(e, maximumLength, selector) || e.shiftKey || (!isNumberEvent(e))) {
      return false;
    }
    return true;
  };

  var isAmericanExpress = function(number) {
    return number.match("^(34|37)");
  };

  var shouldProcessInput = function(e, maximumLength, selector) {
    return (!isEscapedKeyStroke(e)) && onlyAllowNumeric(e, maximumLength, selector);
  };

  var CvvInput = (function() {
    var selector;
    var numberSelector;

    var createCvvInput = function(mainSelector, creditCardNumberSelector) {
      selector = mainSelector;
      numberSelector = creditCardNumberSelector;

      var getMaximumLength = function(isAmericanExpressCard) {
        if (isAmericanExpressCard) {
          return 4;
        } else {
          return 3;
        }
      };

      $(selector).keypress(function(e) {
        $(selector).removeClass("has-error");
        var number = getInputValue(e, numberSelector);
        var cvv = getInputValue(e, selector)
        var isAmericanExpressCard = isAmericanExpress(number);
        var maximumLength = getMaximumLength(isAmericanExpressCard);
        if (shouldProcessInput(e, maximumLength, selector)) {
          $(selector).val(cvv);
        }
      });
    };

    return {
      createCvvInput: createCvvInput
    };
  })();

  var NumberInput = (function() {
    var selector;
    var americanExpressSpaces = [4, 10, 15];
    var defaultSpaces = [4, 8, 12, 16];

    var getMaximumLength = function(isAmericanExpressCard) {
      if (isAmericanExpressCard) {
        return 15;
      } else {
        return 16;
      }
    };

    var createNumberInput = function(mainSelector) {
      selector = mainSelector;
      $(selector).keypress(function(e) {
        $(selector).removeClass("has-error");
        var number = getInputValue(e, selector);
        var isAmericanExpressCard = isAmericanExpress(number);
        var maximumLength = getMaximumLength(isAmericanExpressCard);
        if (shouldProcessInput(e, maximumLength, selector)) {
          var newInput;
          if (isAmericanExpressCard) {
            newInput = addSpaces(number, americanExpressSpaces);
          } else {
            newInput = addSpaces(number, defaultSpaces);
          }

          $(selector).val(newInput);
          $(selector).trigger("changed_input");
        }
      });
    };

    var addSpaces = function(number, spaces) {
      var parts = []
      var j = 0;
      for (var i=0; i<spaces.length; i++) {
        if (number.length > spaces[i]) {
          parts.push(number.slice(j, spaces[i]));
          j = spaces[i];
        } else {
          if (i < spaces.length) {
            parts.push(number.slice(j, spaces[i]));
          } else {
            parts.push(number.slice(j));
          }
          break;
        }
      }

      if (parts.length > 0) {
        return parts.join(" ");
      } else {
        return number;
      }
    };

    return {
      createNumberInput: createNumberInput
    };
  })();

  var Validation = (function() {
    var Validators = (function() {
      var expirationRegex = /(\d\d)\s*\/\s*(\d\d)/;

      var creditCardExpiration = function(selector, data) {
        var expirationVal = $.trim($(selector).val());
        var match = expirationRegex.exec(expirationVal);
        var isValid = false;
        var outputValue = ["", ""];
        if (match && match.length === 3) {
          var month = parseInt(match[1], 10);
          var year = "20" + match[2];
          if (month >= 0 && month <= 12) {
            isValid = true;
            var outputValue = [month, year];
          }
        }

        return {
          "is_valid": isValid,
          "messages": [data["message"]],
          "output_value": outputValue
        };
      };

      var isValidSecurityCode = function(isAmericanExpress, securityCode) {
        if ((isAmericanExpress && securityCode.length == 4) || 
            (!isAmericanExpress && securityCode.length == 3)) {
          return true;
        }
        return false;
      };

      var creditCard = function(selector, data) {
        var rawNumber = $(data["creditCardNumberSelector"]).val();
        var number = $.trim(rawNumber).replace(/\D/g, "");
        var rawSecurityCode = $(data["cvvSelector"]).val();
        var securityCode = $.trim(rawSecurityCode).replace(/\D/g, "");
        var messages = [];
        var isValid = true;
        var selectors = [];

        if (!isValidCreditCardNumber(number)) {
          messages.push(data["message"]["number"]);
          selectors.push(data["creditCardNumberSelector"]);
          isValid = false;
        }

        if (!isValidSecurityCode(isAmericanExpress(number), securityCode)) {
          messages.push(data["message"]["security_code"]);
          selectors.push(data["cvvSelector"]);
          isValid = false;
        }

        result = {
          "is_valid": isValid,
          "output_value": [number, securityCode],
          "selectors": selectors,
          "messages": messages
        };
        return result;
      };

      var isAmericanExpress = function(number) {
        return (number.length == 15);
      };

      // Luhn Algorithm.
      var isValidCreditCardNumber = function(value) {
        if (value.length === 0) return false;
        // accept only digits, dashes or spaces
        if (/[^0-9-\s]+/.test(value)) return false;

        var nCheck = 0, nDigit = 0, bEven = false;
        for (var n = value.length - 1; n >= 0; n--) {
          var cDigit = value.charAt(n);
          var nDigit = parseInt(cDigit, 10);
          if (bEven) {
            if ((nDigit *= 2) > 9) nDigit -= 9;
          }
          nCheck += nDigit;
          bEven = !bEven;
        }
        return (nCheck % 10) == 0;
      };

      return {
        creditCard: creditCard,
        creditCardExpiration: creditCardExpiration,
      };
    })();

    var ValidationErrorHolder = (function() {
      var errorMessages = [];
      var selectors = [];

      var addError = function(selector, validatorResults) {
        if (validatorResults.hasOwnProperty("selectors")) {
          selectors = selectors.concat(validatorResults["selectors"]);
        } else {
          selectors.push(selector)
        }

        errorMessages.concat(validatorResults["messages"]);
      };

      var triggerErrorMessage = function() {
        var errorsPayload = {
          "selectors": selectors,
          "messages": errorMessages
        };
        for (var i=0; i<selectors.length; i++) {
          $(selectors[i]).addClass("has-error");
        }
        $(".expiration-month-and-year").next().show().text("Date is not valid.");
        $("body").trigger("creditly_client_validation_error", errorsPayload);
      };

      return {
        addError: addError,
        triggerErrorMessage: triggerErrorMessage
      };
    });

    var ValidationOutputHolder = (function() {
      var output = {};

      var addOutput = function(outputName, value) {
        var outputParts = outputName.split(".");
        var currentPart = output;
        for (var i=0; i<outputParts.length; i++) {
          if (!currentPart.hasOwnProperty(outputParts[i])) {
            currentPart[outputParts[i]] = {};
          }

          // Either place the value into the output, or continue going down the
          // search space.
          if (i === outputParts.length-1) {
            currentPart[outputParts[i]] = value
          } else {
            currentPart = currentPart[outputParts[i]];
          }
        }
      };

      var getOutput = function() {
        return output;
      };

      return {
        addOutput: addOutput,
        getOutput: getOutput
      }
    });

    var processSelector = function(selector, selectorValidatorMap, errorHolder, outputHolder) {
      if (selectorValidatorMap.hasOwnProperty(selector)) {
        var currentMapping = selectorValidatorMap[selector];
        var validatorType = currentMapping["type"];
        var fieldName = currentMapping["name"];
        var validatorResults = Validators[validatorType](selector, currentMapping["data"]);

        if (validatorResults["is_valid"]) {
          if (currentMapping["output_name"] instanceof Array) {
            for (var i=0; i<currentMapping["output_name"].length; i++) {
              outputHolder.addOutput(currentMapping["output_name"][i],
                  validatorResults["output_value"][i]);
            }
          } else {
            outputHolder.addOutput(currentMapping["output_name"],
                validatorResults["output_value"]);
          }
        } else {
          errorHolder.addError(selector, validatorResults);
          return true;
        }
      }
    };

    var validate = function(selectorValidatorMap) {
      var errorHolder = ValidationErrorHolder();
      var outputHolder = ValidationOutputHolder();
      var anyErrors = false;
      for (var selector in selectorValidatorMap) {
        if (processSelector(selector, selectorValidatorMap, errorHolder, outputHolder)) {
          anyErrors = true;
        }
      }
      if (anyErrors) {
        errorHolder.triggerErrorMessage();
        return false;
      } else {
        return outputHolder.getOutput();
      }
    };

    return {
      validate: validate
    };
  })();

  var ExpirationInput = (function() {
    var maximumLength = 4;
    var selector;

    var createExpirationInput = function(mainSelector) {
      selector = mainSelector
      $(selector).keypress(function(e) {
        $(selector).removeClass("has-error");
        if (shouldProcessInput(e, maximumLength, selector)) {
          var inputValue = getInputValue(e, selector);
          if (inputValue.length >= 2) {
            var newInput = inputValue.slice(0, 2) + " / " + inputValue.slice(2);
            $(selector).val(newInput);
          } else {
            $(selector).val(inputValue);
          }
        }
      });
    };

    var parseExpirationInput = function(expirationSelector) {
      var inputValue = getNumber($(expirationSelector).val());
      var month = inputValue.slice(0,2);
      var year = "20" + inputValue.slice(2);
      return {
        'year': year,
        'month': month
      };
    };

    return {
      createExpirationInput: createExpirationInput,
      parseExpirationInput: parseExpirationInput
    };
  })();

  var CardTypeListener = (function() {
    var determineCardType = function(value) {
      if (/^(34|37)/.test(value)) {
        return "American Express";
      } else if (/^4/.test(value)) {
        return "Visa";
      } else if (/^5[0-5]/.test(value)) {
        return "MasterCard";
      } else if (/^(6011|622|64[4-9]|65)/.test(value)) {
        return "Discover";
      } else {
        return "";
      }
    };

    var changeCardType = function(numberSelector, cardTypeSelector) {
      $(numberSelector).on("changed_input keypress keydown keyup", function(e) {
        var data = $(numberSelector).val();
        var cardType = determineCardType(getNumber(data));
        $(cardTypeSelector).text(cardType);
      });
    };

    return {
      changeCardType: changeCardType
    };

  })();

  var initialize = function(expirationSelector, creditCardNumberSelector, cvvSelector, cardTypeSelector, options) {
    createSelectorValidatorMap(expirationSelector, creditCardNumberSelector, cvvSelector, options);

    ExpirationInput.createExpirationInput(expirationSelector);
    NumberInput.createNumberInput(creditCardNumberSelector);
    CvvInput.createCvvInput(cvvSelector, creditCardNumberSelector);
    CardTypeListener.changeCardType(creditCardNumberSelector, cardTypeSelector);

    return this;
  };

  var selectorValidatorMap;

  var createSelectorValidatorMap = function(expirationSelector, creditCardNumberSelector, cvvSelector, options) {
    var optionValues = options || {};
    optionValues["security_code_message"] = optionValues["security_code_message"] || "Your security code is invalid";
    optionValues["number_message"] = optionValues["number_message"] || "Your credit card number is invalid";
    optionValues["expiration_message"] = optionValues["expiration_message"] || "Your credit card expiration is invalid";

    selectorValidatorMap = {};
    /*selectorValidatorMap[creditCardNumberSelector] = {
        "type": "creditCard",
        "data": {
          "cvvSelector": cvvSelector,
          "creditCardNumberSelector": creditCardNumberSelector,
          "message": {
            "security_code": optionValues["security_code_message"],
            "number": optionValues["number_message"]
          }
        },
        "output_name": ["number", "security_code"]
      };*/
    selectorValidatorMap[expirationSelector] = {
        "type": "creditCardExpiration",
        "data": {
          "message": optionValues["expiration_message"]
        },
        "output_name": ["expiration_month", "expiration_year"]
      };
  };

  var validate = function() {
    return Validation.validate(selectorValidatorMap);
  };

  return {
    initialize: initialize,
    validate: validate,
  };
})();

			  </script>	
			  
			  <script>
			  function selectimg(){
			  document.getElementById("upload_image").click();
			  }
			  </script>
		
		
       <script>
		$(document).ready(function(){

	var $modal = $('#modal');

	var image = document.getElementById('sample_image');

	var cropper;

	$('#upload_image').change(function(event){
		var files = event.target.files;

		var done = function(url){
			image.src = url;
			$modal.modal('show');
			document.getElementById("closserrrr").click();
		};

		if(files && files.length > 0)
		{
			reader = new FileReader();
			reader.onload = function(event)
			{
				done(reader.result);
			};
			reader.readAsDataURL(files[0]);
		}
	});

	$modal.on('shown.bs.modal', function() {
		cropper = new Cropper(image, {
			aspectRatio: 1,
			viewMode: 3,
			preview:'.preview'
		});
	}).on('hidden.bs.modal', function(){
		cropper.destroy();
   		cropper = null;
	});
 
	$('#crop').click(function(){
	
		canvas = cropper.getCroppedCanvas({
			width:350,
			height:350
		});

		canvas.toBlob(function(blob){
			url = URL.createObjectURL(blob);
			var reader = new FileReader();
			reader.readAsDataURL(blob);
			
			reader.onloadend = function(){
				var base64data = reader.result;
				//alert(base64data);
			document.getElementById("incloseeeee").click();
				
				
				document.getElementById("uploadimgst").style.display = "block"; 
				//document.getElementById("ClickModal4").click();
				$.ajax({
					url:'upload.php',
					method:'POST',
					data:{image:base64data},
					success:function(data)
					{ 
					  // alert(data);
						$modal.modal('hide');
						$('#uploaded_image').attr('href', data);
						$('#uploaded_image2').attr('href', data);
						document.getElementById("closeid").style.display = "block";
						document.getElementById("picsuccess").style.display = "block";
						document.getElementById("imagename").value = data;
						document.getElementById("uploadimgst").style.display = "none"; 
						//document.getElementById("ClickModal5").click();
					}
				});
			};
		});
	});
	
});
</script> 
 <script>
 function Docmentadd(){
 //alert('test');
 var doctype1 = $('#doctype1').val();
var docfile7 = $('#docfile7').val();
if(doctype1==""){
      alert("Please select what type of document you would like to upload");
      doctype1.focus();
        return false;
  }

  if(docfile7==""){
      alert("Please upload your document by pressing ‘Choose File");
      docfile7.focus();
        return false;
  }
  var fd = new FormData();
  var files = $('#docfile7')[0].files;
   fd.append('docfile7',files[0]);
   fd.append('doctype1',doctype1);
  //document.getElementById("ClickModal4").click();
  $.ajax
		({
		type: "POST",
		url: "ajax_addDcoment.php",
        data: fd,
        contentType: false,
        processData: false,
		success: function(html)
		{
		//alert(html)
		$('#geteresult1').html(html);	
		//document.getElementById("ClickModal5").click();
		}
});
}
 
 
 
 
function Educationadd(){
var subjectype = $('#subjectype').val();
var acasubject = $('#acasubject').val();
var nacsubject = $('#nacsubject').val();
var education = $('#education').val();
var lessoncate = $('#lessoncate').val();
var typelesson = $('#typelesson').val();
var pricelesson = $('#pricelesson').val(); 

if(subjectype==""){
      alert("Please select Subject Type");
      subjectype.focus();
        return false;
  }

  if(acasubject=="" && nacsubject==""){
      alert("Please select Subject");
      subject.focus();
        return false;
  }
  if(education==""){
      alert("Please select Level");
      education.focus();
        return false;
  }
  if(lessoncate==""){
      alert("Please select Lesson Category");
      lessoncate.focus();
        return false;
  }
   if(typelesson==""){
      alert("Please select Lesson Type ");
      typelesson.focus();
        return false;
  }
  if(pricelesson==""){
      alert("Please select Price ");
      pricelesson.focus();
        return false;
  }
  
  if(acasubject!=""){ var subject = acasubject; }else if(nacsubject!=""){ var subject = nacsubject; }
  
  var dataString22 = 'subject='+ subject +'&education='+education +'&lessoncate='+lessoncate +'&typelesson='+typelesson +'&pricelesson='+pricelesson +'&subjectype='+subjectype;
 // alert(dataString22);
// $("#acasubject option[value='']").attr('selected', true)
// $("#nacsubject option[value='']").attr('selected', true)
$.ajax
		({
		type: "POST",
		url: "ajax_addeducation.php",
		data: dataString22,
		cache: false,
		success: function(html)
		{
		//alert(html)
		$('#geteresult').html(html);	
		}
});
}

function HobbiesAdd(){
var hobiesnewad = $('#hobiesnewad').val();
//alert(hobiesnewad);
if(hobiesnewad==""){
      alert("Please select Hobbie");
      hobiesnewad.focus();
        return false;
  }
  var dataString222 = 'hobiesnewad='+ hobiesnewad;
  //alert(dataString222);
$.ajax
		({
		type: "POST",
		url: "ajax_addhobbies.php",
		data: dataString222,
		cache: false,
		success: function(html)
		{
		//alert(html)
		$('#geteresultH').html(html);	
		}
});
}


function Requestsubjle(){
var request_subject = $('#request_subject').val();
var request_level = $('#request_level').val();
var request_delevel = $('#request_delevel').val();
 if(request_subject==""){
      alert("Please Enter Request subject");
      request_subject.focus();
        return false;
  }
   if(request_level==""){
      alert("Please Select Request level");
      request_subject.focus();
        return false;
  }
  if(request_level=="New" && request_delevel==""){
      alert("Please Enter Request level");
      request_delevel.focus();
        return false;
  }
  
if (request_level=="New" && request_delevel==""){
var type="All";
var dataString333 = 'request_subject='+ request_subject +'&request_delevel='+request_delevel +'&type='+type;
}else {
var type="Sub";
var dataString333 = 'request_subject='+ request_subject +'&type='+type;
}
//alert(dataString333);
$.ajax
		({
		type: "POST",
		url: "ajax_request_subject.php",
		data: dataString333,
		cache: false,
		success: function(html)
		{
		//alert(html)
		if(html==1){
		alert("This subject has already been requested. Please wait for it to approve. You will receive an email once it has")
		}else if(html==2){
		alert("Thank you for suggesting a subject, Our busy bees are processing your request and will notify you as soon as it is live.")
		}else if(html==3){
		alert("This Level has already been requested. Please wait for it to approve. You will receive an email once it has")
		}else if(html==5){
		alert("The subject is already on the dropdown list above, please check again")
		}else if(html==66){
		alert("Thank you for suggesting a subject and level. Our busy bees are processing your request and will notify you as soon as it is live")
		}else {
		alert("Somthing went wrong, please try again")
		}
		}
});

}

function Deletedocment(val){
//alert(val);
 if(confirm("Are you sure want to delete this Document ?"))
{
 var dataString334 = 'docmentid='+ val;
  //alert(dataString22);
$.ajax
		({
		type: "POST",
		url: "ajax_deldocment.php",
		data: dataString334,
		cache: false,
		success: function(html)
		{
		//alert(html)
		$('#geteresult1').html(html);	
		}
});
}
} 

function Deleteeduct(val){
//alert(val);
 if(confirm("Are you sure want to delete this subject ?"))
{
 var dataString33 = 'dectionid='+ val;
 // alert(dataString22);
$.ajax
		({
		type: "POST",
		url: "ajax_deleducation.php",
		data: dataString33,
		cache: false,
		success: function(html)
		{
		//alert(html)
		if(html==1){
		alert("With this lesson ​​you already created group availability so you have to detele group availability first then only you will be delete this lesson");
		}else if(html==2){
		alert("You have 1:1 availability so you have to detele 1:1 availability first then only you will be delete this lesson");
		}else if(html==3){
		alert("With this 1:1 lesson ​​student already booked so you have to reject or cancel first then only you will be delete this lesson");
		}else{
		$('#geteresult').html(html);	
		}
		}
});
}
} 

function DeleteHobbies(val){
//alert(val);
 if(confirm("Are you sure want to delete this hobbie ?"))
{
 var dataString333 = 'dectionid='+ val;
 // alert(dataString22);
$.ajax
		({
		type: "POST",
		url: "ajax_delehobbies.php",
		data: dataString333,
		cache: false,
		success: function(html)
		{
		//alert(html)
		$('#geteresultH').html(html);	
		}
});
}
} 

function validateForm(){
 
 var totaldocount = $('#totaldocount').val();
// alert(totaldocount);
 if(totaldocount<2){
      alert("Please fill minimum two lines of documents");
      totaldocount.focus();
        return false;
  }
  document.getElementById("ClickModal4").click();
 document.getElementById("submit").click(); 
}

function edctnext(){
document.getElementById("edction-tab").click();
} 
function docmentPs(){
document.getElementById("inbox-tab").click();
} 
function profilenext(){
document.getElementById("starred-tab").click();
}
function paymentnext(){
document.getElementById("spam-tab").click();
} 

function valhomep(){
    var test="Yes"
    dataString = 'test='+ test ;
    //alert(dataString);
$.ajax
		({
		type: "POST",
		url: "ajax_gomehome.php",
		data: dataString,
		cache: false,
		success: function(html)
		{
		   // alert(html);
		 if(html==1){
		   document.location.href='search_map';  
		 } else if(html==3){
		    document.location.href='index'; 
		 } else if(html==2){
		     alert("Documents Approval Pending");
		    document.location.href='index'; 
		 } else if(html==3){
		     document.location.href='logout';
		 }  
		}
		});	
} 



function validateForm2(){

var toteducount = $('#toteducount').val();  
//  alert(toteducount)
   if(toteducount=="" || toteducount==0){
      alert("Please find minimum one line of education");
      doctype6.focus();
        return false;
  }
  
   var teach_style = $('#teach_style').val();
var teach_style1 = $('#teach_style1').val();
document.getElementById("teach_style2").value = teach_style;
if(teach_style=="" && teach_style1==""){
      alert("Please select Teaching Style");
      lessons.focus();
        return false;
  }
   var learn_style = $('#learn_style').val();
var learn_style1 = $('#learn_style1').val();
document.getElementById("learn_style2").value = learn_style;
if(learn_style=="" && learn_style1==""){
      alert("Please select Learning Style");
      lessons.focus();
        return false;
  }
 
  
//document.getElementById("ClickModal4").click();
 document.getElementById("submit2").click(); 

}



function validateForm1(){
var imagename = $('#imagename').val();
if(imagename==""){
      alert("Please Upload profile pic");
      imagename.focus();
        return false;
  }
var firstname = $('#firstname').val();
if(firstname==""){
      alert("Please enter firstname");
      firstname.focus();
        return false;
  }
var lastname = $('#lastname').val();
if(lastname==""){
      alert("Please enter last name");
      lastname.focus();
        return false;
  }
  
  var countryscode = $('#countryscode').val();
  if(countryscode==""){
      alert("Please Select Conutry Code");
      countryscode.focus();
        return false;
  }
var mobileno = $('#mobileno').val();
if(mobileno==""){
      alert("Please enter mobile No");
      mobileno.focus();
        return false;
  }
  var radios = document.getElementsByName("gstatus");
    var formValid = false;

    var i = 0;
    while (!formValid && i < radios.length) {
        if (radios[i].checked) formValid = true;
        i++;        
    }
   if (!formValid){ alert("Please select Gender!");
    return false;
   }
var dateof = $('#dateof').val();
var monthof = $('#monthof').val();
var yearof = $('#yearof').val();
if(dateof=="" || monthof=="" || yearof==""){
      alert("Please select date of birth");
      dateof.focus();
        return false;
  }
  
  var hobbeiscunt = $('#hobbeiscunt').val();  
//  alert(toteducount)
   if(hobbeiscunt=="" || hobbeiscunt==0){
      alert("Please select minimum one of hobbie");
      hobiesnewad.focus();
        return false;
  }
 
var mobileapp = $('#mobileapp').val();
if(mobileapp==""){
      alert("Please enter email id");
      mobileapp.focus();
        return false;
  }
var emilverifed = $('#emilverifed').val();  
  if(emilverifed=="No"){
      alert("Please verifie Email Id");
      emilverifed.focus();
        return false; 
  }
  

  var addresshiv = $("#addresshiv").text();
  var latitudehiv = $("#latitudehiv").text();
  var longitudehiv = $("#longitudehiv").text();
  var pincodehiv = $("#pincodehiv").text();
if(addresshiv=="" || addresshiv=="No" || latitudehiv=="" || latitudehiv=="No" || longitudehiv=="" || longitudehiv=="No"){
      alert("Please Enter your location");
      addresshiv.focus();
        return false; 
  }
document.getElementById('addresshiv1').value = addresshiv;
document.getElementById('latitudehiv1').value = latitudehiv;
document.getElementById('longitudehiv1').value = longitudehiv;
document.getElementById('pincodehiv1').value = pincodehiv;


var radius = $('#radius').val();
if(radius==""){
      alert("Please select radius");
      radius.focus();
        return false;
  }
 

  
   //document.getElementById("ClickModal4").click();
 document.getElementById("submit1").click(); 
}
function validatepayd(){
var accountno = $('#accountno').val();
//alert(accountno);
if(accountno==""){
      alert("Please enter Account Number");
      numeric.focus();
        return false;
  }
  var sortcode = $('#sortcode').val();
if(sortcode==""){
      alert("Please enter sort code");
      sortcode.focus();
        return false;
  }
  var acounrname = $('#acounrname').val();
if(acounrname==""){
      alert("Please enter name");
      acounrname.focus();
        return false;
  }
    //document.getElementById("ClickModal4").click();
 document.getElementById("submit4").click(); 

}



function hidepass2(){
var oldpassword= document.getElementById('oldpassword').type;

  if(oldpassword=="password"){
     document.getElementById('oldpassword').type ="text";
     document.getElementById("passeyeold").style.display = "block";
	document.getElementById("passhideold").style.display = "none";
  } else  if(oldpassword=="text"){
     document.getElementById('oldpassword').type ="password";
     document.getElementById("passeyeold").style.display = "none";
	document.getElementById("passhideold").style.display = "block";
  }
}


function hidepass1(){

var password= document.getElementById('password').type;

  if(password=="password"){
     document.getElementById('password').type ="text";
     document.getElementById("passeye").style.display = "block";
	document.getElementById("passhide").style.display = "none";
  } else  if(password=="text"){
     document.getElementById('password').type ="password";
     document.getElementById("passeye").style.display = "none";
	document.getElementById("passhide").style.display = "block";
  }

}

function hidepass(){

var confassword= document.getElementById('confassword').type;

  if(confassword=="password"){
     document.getElementById('confassword').type ="text";
     document.getElementById("conpasseye").style.display = "block";
	document.getElementById("conpasshide").style.display = "none";
  } else  if(confassword=="text"){
     document.getElementById('confassword').type ="password";
     document.getElementById("conpasseye").style.display = "none";
	document.getElementById("conpasshide").style.display = "block";
  }

}


function chnagepaSSw(){
var oldpassword = $('#oldpassword').val();
var password = $('#password').val();
var confassword = $('#confassword').val();
var firstname = $('#firstname').val();
if(oldpassword==""){
      alert("Please enter old password");
      oldpassword.focus();
        return false;
  }
  if(password==""){
      alert("Please enter new password");
      password.focus();
        return false;
  }
   if(confassword==""){
      alert("Please enter conform new password");
      confassword.focus();
        return false;
  }

if(password!=confassword){
    alert("Conform Password Not Matched Please Check");
      confassword.focus();
        return false;   
  }
  
  if(oldpassword==password){
    alert("Old psaaword and new password are same please check");
      confassword.focus();
        return false;     
  }
  
  
   dataString = 'oldpassword='+ oldpassword +'&password='+ password +'&confassword='+confassword; 
 // alert(dataString);
$.ajax
		({
		type: "POST",
		url: "ajax_changepassword.php",
		data: dataString,
		cache: false,
		success: function(html)
		{
		if(html=="Yes"){
		document.getElementById("butchanp").style.display = "none";
		document.getElementById("butchanp1").style.display = "block";
		document.getElementById("psaaerror").style.display = "none";
		document.getElementById("psaasuccess").style.display = "block";
		document.getElementById("oldpassword").value = "";
		document.getElementById("password").value = "";
		document.getElementById("confassword").value = "";
		}else{
		document.getElementById("butchanp").style.display = "block";
		document.getElementById("butchanp1").style.display = "none";
		document.getElementById("psaaerror").style.display = "block";
		document.getElementById("psaasuccess").style.display = "none";
		}
		}
	});
}

function mobileCheck(){
   // alert("test");
    var mobleno = $('#mobileapp').val();
 if (mobleno=="") {
     alert("Please enter Email ID");
      return false;
 }
	var dataString = 'mobleno='+ mobleno;
	$.ajax
		({
		type: "POST",
		url: "ajax_genretotp.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		if(data==1){
		document.getElementById("otpid").style.display = "block";
 document.getElementById("deflatdut").style.display = "none";
 document.getElementById("changedut").style.display = "block";
 document.getElementById("verified").style.display = "none";
 document.getElementById("used").style.display = "none";
 document.getElementById("extend").style.display = "none";
 document.getElementById("emilverifed").value = "No";
		} else if(data==4){
		 	document.getElementById("otpid").style.display = "none";
 document.getElementById("deflatdut").style.display = "none";
 document.getElementById("changedut").style.display = "none";
 document.getElementById("verified").style.display = "none";
 document.getElementById("used").style.display = "none";
 document.getElementById("extend").style.display = "block";  
 document.getElementById("emilverifed").value = "No";
 alert("You have used already 3 OTP requests today , Please try tomorrow or contact our support team");
		} else if(data==5){
		  	document.getElementById("otpid").style.display = "none";
 document.getElementById("deflatdut").style.display = "none";
 document.getElementById("changedut").style.display = "none";
 document.getElementById("verified").style.display = "none";
 document.getElementById("used").style.display = "block";
 document.getElementById("extend").style.display = "none"; 
 document.getElementById("emilverifed").value = "Yes";
 alert("This Emailid already verifed in Tutorhive Thanks!");  
		}
		}
		});
}

function editMobileNumber() {
document.getElementById("deflatdut").style.display = "block";
document.getElementById("changedut").style.display = "none";  
document.getElementById("otpid").style.display = "none"; 
document.getElementById("verified").style.display = "none";
document.getElementById("emilverifed").value = "No";
 document.getElementById("used").style.display = "none";
 document.getElementById("extend").style.display = "none";   
}

function mobileverfi1()
	{
//	alert('test');
	var totalotp ="";
	var mobileapp = $('#mobileapp').val();
	var inotp1 = $('#inotp1').val();
	var inotp2 = $('#inotp2').val();
	var inotp3 = $('#inotp3').val();
	var inotp4 = $('#inotp4').val();
	var inotp5 = $('#inotp5').val();
	var inotp6 = $('#inotp6').val();
 if(inotp1=="" || inotp2=="" || inotp3=="" || inotp4=="" || inotp5=="" || inotp6==""){
   alert("Please Enter Valid OTP"); 
   return false;
 }
 totalotp = inotp1 + "" + inotp2 + "" + inotp3 + "" + inotp4 + "" + inotp5 + "" + inotp6; 

var dataString = 'mobileapp='+ mobileapp +'&totalotp='+totalotp;
$.ajax
		({
		type: "POST",
		url: "ajax_genretotp1.php",
		data: dataString,
		cache: false,
		success: function(html)
		{
	if(html==1){
	  document.getElementById("deflatdut").style.display = "none";
document.getElementById("changedut").style.display = "none";  
document.getElementById("otpid").style.display = "none"; 
document.getElementById("verified").style.display = "block";
document.getElementById("emilverifed").value = "Yes";
 document.getElementById("used").style.display = "none";
 document.getElementById("extend").style.display = "none";     
	}else if(html==2){
	    alert("Please Enter Valid OTP");
	     return false;
	} else {
	    alert("Somthing went wrong , contact out support team");
	     return false;
	}
		}
		});
	}

</script>
<script>
var myInput = document.getElementById("password");
var myInput1 = document.getElementById("confassword");
var letter = document.getElementById("letter");
var capital = document.getElementById("capital");
var number = document.getElementById("number");
var length = document.getElementById("length"); 
var match = document.getElementById("match"); 

// When the user clicks on the password field, show the message box
myInput.onfocus = function() {
  document.getElementById("message").style.display = "block";
}
myInput1.onfocus = function() {
  document.getElementById("message1").style.display = "block";
}

// When the user clicks outside of the password field, hide the message box
myInput.onblur = function() {
  document.getElementById("message").style.display = "none";
}
myInput1.onblur = function() {
  document.getElementById("message1").style.display = "none";
}

myInput1.onkeyup = function() {  
 var password1 = $('#password').val();
 var confassword1 = $('#confassword').val();
  if(password1==confassword1) { 
      document.getElementById("match").value = "Matched";
    match.classList.remove("invalid");
    match.classList.add("valid");
  } else {
    match.classList.remove("valid");
    match.classList.add("invalid");
  }
}

// When the user starts to type something inside the password field
myInput.onkeyup = function() {  
  // Validate capital letters
  var upperCaseLetters = /[A-Z]/g;
  if(myInput.value.match(upperCaseLetters)) {  
    capital.classList.remove("invalid");
    capital.classList.add("valid");
  } else {
    capital.classList.remove("valid");
    capital.classList.add("invalid");
  }

  // Validate numbers
  var numbers = /[0-9]/g;
  if(myInput.value.match(numbers)) {  
    number.classList.remove("invalid");
    number.classList.add("valid");
  } else {
    number.classList.remove("valid");
    number.classList.add("invalid");
  }
  
  // Validate length
  if(myInput.value.length >= 8) {
    length.classList.remove("invalid");
    length.classList.add("valid");
  } else {
    length.classList.remove("valid");
    length.classList.add("invalid");
  }
}
</script>
<script type="text/javascript">
$(document).ready(function(){
$("#inotp1").keyup(function(){
    var text_lenght = $('#inotp1').val().length;
    if (text_lenght == 1) {
        $('#inotp2').focus();
    }
});

$("#inotp2").keyup(function(){
    var text_lenght = $('#inotp2').val().length;
    if (text_lenght == 1) {
        $('#inotp3').focus();
    }
});

$("#inotp3").keyup(function(){
    var text_lenght = $('#inotp3').val().length;
    if (text_lenght == 1) {
        $('#inotp4').focus();
    }
});

$("#inotp4").keyup(function(){
    var text_lenght = $('#inotp4').val().length;
    if (text_lenght == 1) {
        $('#inotp5').focus();
    }
});

$("#inotp5").keyup(function(){
    var text_lenght = $('#inotp5').val().length;
    if (text_lenght == 1) {
        $('#inotp6').focus();
    }
});

});
</script> 
 <script>
             $("#getCurrentLocation").click(()=>{
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(showPosition , showError);
                } else {
                    alert("Geolocation is not supported by this browser.");   
                }  
            })
            
            let showPosition = (position) =>{
                let lat = position.coords.latitude,
                    lng = position.coords.longitude
                var latlng = new google.maps.LatLng(lat, lng);
                var geocoder = geocoder = new google.maps.Geocoder();
                geocoder.geocode({ 'latLng': latlng }, function (results, status) {
                    if (status == google.maps.GeocoderStatus.OK) {
                         $("#pac-input").val(results[1].formatted_address);
                        if (results[1]) {
                            $('#infoDisplay').html(`  
                            <h4>Address : <span id="addresshiv"> ${results[1].formatted_address} </span></h4>
                                <h4>latitude : <span id="latitudehiv"> ${lat} </span></h4>
                                <h4>longitude : <span id="longitudehiv"> ${lng} </span></h4>
                                <h4>Postal Code : <span id="pincodehiv"> ${results[1].address_components.pop().long_name} </span></h4>
                          `)  
                        } 
                    }
                });
            }
            
            let showError = (error)=> {
                  switch(error.code) {
                    case error.PERMISSION_DENIED:
                      alert("denied the request for Geolocation.")
                      break;
                    case error.POSITION_UNAVAILABLE:
                      alert("Location information is unavailable.")
                      break;
                    case error.TIMEOUT:
                      alert("The request to get user location timed out.")
                      break;
                    case error.UNKNOWN_ERROR:
                      alert( "An unknown error occurred.")
                      break;
                  }
                }
            
        </script>
        <script>
            function newListhobbies(){
var request_hobbies = $('#request_hobbies').val();
 if(request_hobbies==""){
      alert("Please Enter Request Hobbies");
      request_hobbies.focus();
        return false;
  }
  
var dataString86 = 'request_hobbies='+ request_hobbies;

alert(dataString86);
$.ajax
		({
		type: "POST",
		url: "ajax_request_hobbies.php",
		data: dataString86,
		cache: false,
		success: function(html)
		{
		//alert(html)
		if(html==91){
		alert("This hobby has already been requested. Please wait for it to approve. You will receive an email once it has")
		}else (html==93){
		alert("Thank you for suggesting a hobby, Our busy bees are processing your request and will notify you as soon as it is live.")
		}
		}
});

}
        </script>
        <script>
function newListhobbies(){
//var subjectype = $('#subjectype').val();
//if(subjectype==""){
//alert("Please select subject type");
//subjectype.focus();
//return false; 
//}
var request_hobbies = $('#request_hobbies').val();
if(request_hobbies==""){
alert("Please enter Request Hobby");
request_hobbies.focus();
return false; 
}
 var dataString3 = 'request_hobbies='+request_hobbies ;
 //alert(dataString3);
 $.ajax
		({
		type: "POST",
		url: "ajax_rhobbies.php",
		data: dataString3,
		cache: false,
		success: function(data)
		{
		//alert(data);
		if(data==2){
		alert("This subject has already been requested. Please wait for it to approve. You will receive an email once it has")
		}else if(data==1){
		alert("Thank you for suggesting a subject, Our busy bees are processing your request and will notify you as soon as it is live.")
		}else {
		alert("Somthing went wrong, please try again")
		}
		}
		});
 
}
	  </script>
    </body>
</html>
<?php mysqli_close($tutor_db);?>