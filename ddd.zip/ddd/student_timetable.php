<?php
    error_reporting(0);
    ob_start();
    ini_set('session.gc_maxlifetime', '28800');
    session_start();
    if( !isset($_SESSION['username_name']) || $_SESSION['verifhive']== "No" || $_SESSION['admin_type'] !== "Student")
     {
       header("Location: login");
     }
     $userId = $_SESSION['tutor_admin_id'];
    
    include_once("common/connection.php");
    $tutor_time = date('H:i');  
	$tutor_date122 = date('Y-m');
	
$data34 = [
    'STUDENTNOTSTATUS' => 1,
	'TH_SENDER' => $userId,
	'TUTORNOTSTATUS' => 1,
	'TH_RECEIVER'=>0,
];
$sqlupdate134 = "UPDATE tutor_hive_sendbuzz SET STUDENTNOTSTATUS=:STUDENTNOTSTATUS WHERE TUTORNOTSTATUS=:TUTORNOTSTATUS AND TH_SENDER=:TH_SENDER AND STUDENTNOTSTATUS=:TH_RECEIVER";
$stmtuodate134= $tutor_db->prepare($sqlupdate134);
$stmtuodate134->execute($data34);	
	
	
//$tutor_date1w="2023-02-08";	
//$tutor_timew="11:30";
	
	
  
    /*----------------------------------------------*/
    if(isset($_POST['mybookingthis'])){ 
	$pagination_fetch111 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 AND TH_BUZZ_DATE>='$tutor_date1' AND TH_BUZZ_MONTHS>='$tutor_date122' ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");
	$totalMonths1 = $pagination_fetch111->fetch();				
	
	$pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 AND TH_BUZZ_DATE>='$tutor_date1' ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetchAll(PDO::FETCH_ASSOC);
     if($_GET['page']=="booked" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
   } else if ($totalMonths1['TH_BUZZ_MONTHS']!=""){
 $selMonth =$totalMonths1['TH_BUZZ_MONTHS'];
  }else {
  $selMonth =$totalMonths[0]['TH_BUZZ_MONTHS'];
  }
	
	 $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.TH_BUZZ_ID,
                                        a.TH_ISPRICE_PAY,
										a.TH_BOOKED_STATUS,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_RECEIVER,
										a.TH_AGENDA,
										a.GROUP_ID,
										a.SB_SSID,
										a.MEETING_LINK
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_RECEIVER = b.USER_ID
                                    WHERE
                                        a.TH_SENDER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth' AND a.TH_STATUS = 1 AND a.TH_TUTOR_CANCEL_STATUS!=1 AND a.TH_TUTOR_COMPLETED_STATUS!=1 AND a.TH_STUDENT_CANCEL_STATUS!=1 AND a.TH_STUDENT_COMPLETED_STATUS!=1 AND a.TH_REJECT_STATUS!=1 AND a.UNPAID_CANCELLED!=1 AND a.TH_BUZZ_DATE>='$tutor_date1' ORDER BY a.TH_BUZZ_DATE,a.TH_BUZZ_START_TIME ASC");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
        
    ?>
    
        <div class="mapCard">
            <div class="row py-2 ">
			 <div class="col-12 col-md-12 py-2 studentDetails">
			 <div class="d-flex justify-content">
                                        <?php
                                            if((int)$total_rows>0) {
                                            $col=9;
                                           
                                            foreach($totalMonths as $tm) {
                                        ?>
                                           <a href="?page=booked&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primaryss fonsig"<?php }else { ?> class="btn btn-soft-primarynn fonsig" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
			 <div class="">
                                        <table class="table table-bordered border-primary text-center mb-0">
                                            <thead>
                                                <tr>
                                                  <!--<th>S.No</th>-->
                                                  <th>Tutor Name</th>
                                                  <th>Subject</th>
												  <th>Class Date & Time</th>
                                                  <th>Amount</th>
												  <th>Status</th>
												   <th>Class Link</th>
												   <th>Agenda</th>
                                                  <th>Action</th>
                                                </tr>
                                              </thead>
                                              <tbody>
                                 <?php 
								 $i=1;
								 foreach ($fetchBokkingData as $fdb) { 
								 ?>
                                                <tr>
                                                  <!--<td><?php echo $i; ?></td>-->
                                                  <td><?php echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME']; ?></td>
												  <?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
										  $getgroupd = $tutor_db->prepare("SELECT TH_SENDER FROM `tutor_hive_sendbuzz` WHERE `TH_RECEIVER`=? AND `TH_BUZZ_DATE`=? AND `TH_BUZZ_START_TIME`=? AND `TH_BUZZ_END_TIME`=? AND `TH_BUZZ_SUBJECT`=? AND `TH_BUZZ_LESSION_TYPE`=? AND `TH_BUZZ_LEVEL`=? AND `TH_TUTOR_METHOD`=? AND TH_STUDENT_CANCEL_STATUS=? AND TH_TUTOR_CANCEL_STATUS=? AND TH_REJECT_STATUS=?");
                                            $getgroupd->execute([$fdb['TH_RECEIVER'],$fdb['TH_BUZZ_DATE'],$fdb['TH_BUZZ_START_TIME'],$fdb['TH_BUZZ_END_TIME'],$fdb['TH_BUZZ_SUBJECT'],$fdb['TH_BUZZ_LESSION_TYPE'],$fdb['TH_BUZZ_LEVEL'],$fdb['TH_TUTOR_METHOD'],0,0,0]);
											$countofnog = $getgroupd->rowCount();
											?>
												   <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?>  <?php echo $countofnog; ?>/6<br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } else {?>
												  <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?> <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>(<?php echo $fdb['TH_TUTOR_METHOD'];?>) <?php } ?><br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } ?>
                                                  <td><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?><br><?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></td>
												   <td><?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>FREE <?php }else{ if($fdb['TH_BOOKED_STATUS']==1){?><?php if($fdb['PAYMENT_STATUS']==1){?> <span style="color: #15b815;font-weight: 700;">Paid</span> <?php } else {
												    if ($fdb['TH_BUZZ_DATE'] == $tutor_date1 && $tutor_time >= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -1 hours"))){?>
								<a href="#"  class="btn btn-soft-primary ms-2" style="padding: 2px 14px;opacity: 0.3;cursor: no-drop;">Pay Now</a> 
								<?php }else { ?>
								<a href="#" onClick="paymentClass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;">Pay Now</a>
								<?php } ?>
								
								<?php }?> <?php } else { ?><span style="color: #ffd85d;font-weight: 700;">Pending</span><?php } ?><br> <?php if($fdb['TH_TOTAL_PRICE']!=""){?>£<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".","");} else {?> £ 0.00<?php }} ?></td>
												 <td><?php if($fdb['PAYMENT_STATUS']==1){ echo "Confirmed";} else if($fdb['TH_BOOKED_STATUS']==1){echo "Accepted";}else {echo "Pending"; }?></td>
												  <td>  
												  <?php if($fdb['PAYMENT_STATUS']==1){
												  if($fdb['TH_TUTOR_METHOD']=="Online" || $fdb['TH_TUTOR_METHOD']=="Intro Call"){ ?>
												   <?php if($tutor_date1=$fdb['TH_BUZZ_DATE'] && $tutor_time>="08:00" && $fdb['TH_BUZZ_END_TIME']>$tutor_time){?>
									 <?php if ($fdb['TH_BUZZ_DATE'] == $tutor_date1 && $tutor_time >= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -1 hours"))){ ?>
												   <a href="<?php echo $fdb['MEETING_LINK']; ?>" target="_blank"  alt="Join Now" title="Join Now" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;">Join Now</a> 
												    <?php }else {?>
												    <a href="<?php echo $fdb['MEETING_LINK']; ?>" target="_blank"  alt="Meeting Link" title="Meeting Link" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;">Meeting Link</a> 
												  <?php }}}else { echo "In-person";}
												  } ?>
												  </td>
												   <td> <?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-soft-primary ms-2" >Agenda</a><?php } else { echo "No Agenda";} ?></td>
												  <td class="h4 text-center">
												 <?php if ($fdb['TH_BUZZ_DATE']> $tutor_date1){?>
											<a href="#" onClick="delclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Cancel" title="Cancel" class="text-danger"><img src="assets/images/icons-cancel.svg" class="intimetabl" /></a>	 
								 <?php }else if($fdb['TH_BUZZ_DATE']== $tutor_date1 && $tutor_time <= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -2 hours"))){  ?>
						<a href="#" onClick="delclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Cancel" title="Cancel" class="text-danger"><img src="assets/images/icons-cancel.svg" class="intimetabl" /></a>
						<?php } ?>
						<?php // if($fdb['PAYMENT_STATUS']==1 && $fdb['TH_BOOKED_STATUS']==1){
						     $gid = $fdb['GROUP_ID'];
						     $chatCount = $tutor_db->query("SELECT COUNT(`GROUP_ID`) as chatcount FROM `buzz_chat_internal` WHERE `GROUP_ID`='$gid'")->fetch(PDO::FETCH_ASSOC);
						        
						?>
					    <a style="position:relative;" href="#" onClick="chatShow('<?php echo $fdb['TH_BUZZ_ID'] ?>')" class="text-success">
					        <img src="assets/images/chatd.png"  alt="Chat" title="Chat" class="intimetabl" />
					        <span style="font-size: 12px;padding: 1px 5px;border-radius: 50%;background: #000;position: absolute;right: 0;"><?php echo $chatCount['chatcount'] ?></span>
					    </a>
						<?php // } ?>
						<a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="More Details" title="More Details" class="text-success"><img src="assets/images/search-more.png" class="intimetabl" /></a>
												  </td>
												 
												 
                                                </tr>
                                    <?php $i++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
			</div>
            </div>
        </div>
       
    <?php exit; }else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Booked lessons</h4>
          </div>
    <?php }
    
    exit;
        
    }
 
    if(isset($_POST['bookingsCanceled'])){ 
       
	    $pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND (TH_TUTOR_CANCEL_STATUS = 1 OR TH_STUDENT_CANCEL_STATUS=1 OR UNPAID_CANCELLED=1) ORDER BY TH_BUZZ_DATE DESC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetch();
     if($_GET['page']=="canceled" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
  }else {
  $selMonth =$totalMonths['TH_BUZZ_MONTHS'];
  }
       
	   
        $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
                                        a.TH_ISPRICE_PAY,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_BUZZ_ID,
										a.TH_TUTOR_CANCEL_STATUS,
										a.TH_STUDENT_CANCEL_STATUS,
										a.TH_AGENDA,
										a.SB_SSID,
										a.UNPAID_CANCELLED
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_RECEIVER = b.USER_ID
                                    WHERE
                                        a.TH_SENDER =".$_SESSION['tutor_admin_id']." AND (a.`TH_TUTOR_CANCEL_STATUS` = 1 OR a.TH_STUDENT_CANCEL_STATUS=1 OR a.UNPAID_CANCELLED=1) ORDER BY a.TH_BUZZ_DATE ASC");
        $bokingsCount = $prepMyquery->rowCount();
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
    ?>
    
        <div class="mapCard">
            <div class="row py-2 ">
			 <div class="col-12 col-md-12 py-2 studentDetails">
			 <div class="d-flex justify-content">
                                        <?php
                                            if((int)$total_rows>0) {
											 $pagination_fetch1 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND (TH_TUTOR_CANCEL_STATUS = 1 OR TH_STUDENT_CANCEL_STATUS=1 OR UNPAID_CANCELLED=1) ORDER BY TH_BUZZ_DATE ASC");
											 $totalMonths1 = $pagination_fetch1->fetchAll(PDO::FETCH_ASSOC);
                                            $col=9;
                                           
                                            foreach($totalMonths as $tm) {
                                        ?>
                                            <a href="?page=canceled&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primaryss fonsig "<?php }else { ?> class="btn btn-soft-primarynn fonsig" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
			 <div class="">
                                        <table class="table table-bordered border-primary text-center mb-0">
                                            <thead>
                                                <tr>
                                                   <!--<th>S.No</th>-->
                                                  <th>Tutor Name</th>
                                                  <th>Subject</th>
												  <th>Class Date & Time</th>
                                                  <th>Amount</th>
												  <th>Status</th>
												  <th>Cancelled By</th>
												  <th>Agenda</th>
												  <th>Action</th>
												  
                                                </tr>
                                              </thead>
                                              <tbody>
                                 <?php 
								 $i=1;
								 foreach ($fetchBokkingData as $fdb) { 
								 ?>
                                                <tr>
												<!--<td><?php echo $i; ?></td>-->
                                                 <td><?php echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME']; ?></td>
												  <?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
										  $getgroupd = $tutor_db->prepare("SELECT TH_SENDER FROM `tutor_hive_sendbuzz` WHERE `TH_RECEIVER`=? AND `TH_BUZZ_DATE`=? AND `TH_BUZZ_START_TIME`=? AND `TH_BUZZ_END_TIME`=? AND `TH_BUZZ_SUBJECT`=? AND `TH_BUZZ_LESSION_TYPE`=? AND `TH_BUZZ_LEVEL`=? AND `TH_TUTOR_METHOD`=? AND TH_STUDENT_CANCEL_STATUS=? AND TH_TUTOR_CANCEL_STATUS=? AND TH_REJECT_STATUS=?");
                                            $getgroupd->execute([$fdb['TH_RECEIVER'],$fdb['TH_BUZZ_DATE'],$fdb['TH_BUZZ_START_TIME'],$fdb['TH_BUZZ_END_TIME'],$fdb['TH_BUZZ_SUBJECT'],$fdb['TH_BUZZ_LESSION_TYPE'],$fdb['TH_BUZZ_LEVEL'],$fdb['TH_TUTOR_METHOD'],0,0,0]);
											$countofnog = $getgroupd->rowCount();
											?>
												   <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?>  <?php echo $countofnog; ?>/6<br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } else {?>
												  <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?> <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>(<?php echo $fdb['TH_TUTOR_METHOD'];?>) <?php } ?><br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } ?>
                                                  <td><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?><br><?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></td>
												  <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>
												   <td> FREE </td>
												   <?php } else { ?>
												   <td><?php if($fdb['PAYMENT_STATUS']==1){ ?> <span style="color: #15b815;font-weight: 700;">Paid</span> <?php } else { ?><span style="color: #ffd85d;font-weight: 700;">Unpaid</span><?php }?><br>£<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".","") ?></td>
												   <?php } ?>
												  <td>Cancelled</td>
												  <td><?php if($fdb['TH_TUTOR_CANCEL_STATUS']==1){ echo "TUTOR";} else if($fdb['TH_STUDENT_CANCEL_STATUS']==1) { echo "STUDENT"; }else if($fdb['UNPAID_CANCELLED']==1) { echo "Un-Paid"; }?></td>
												  <td> <?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-soft-primary ms-2" >Agenda</a><?php } else { echo "No Agenda";} ?></td>
												  <td><a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="More Details" title="More Details" class="text-success"><img src="assets/images/search-more.png" class="intimetabl" /></a></td>
												   
                                                </tr>
                                    <?php $i++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
			</div>
            </div>
        </div>
<?php exit; } else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Cancelled lessons</h4>
          </div>
    <?php }
        exit;
    }

    if(isset($_POST['lessioncompleted'])){
	
	 $pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND (TH_TUTOR_COMPLETED_STATUS = 1 OR TH_STUDENT_COMPLETED_STATUS=1) ORDER BY TH_BUZZ_DATE DESC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetch();
     if($_GET['page']=="completed" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
  }else {
  $selMonth =$totalMonths['TH_BUZZ_MONTHS'];
  }
	
        $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
                                        a.TH_ISPRICE_PAY,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_BUZZ_ID,
										a.TH_AGENDA,
										a.SB_SSID,
										a.TUTOR_RATING,
										a.TUTOR_REVIEW,
										a.TH_STUDENT_PDF,
										a.PDF_PASSWORD
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_RECEIVER = b.USER_ID
                                    WHERE
                                        a.TH_SENDER =".$_SESSION['tutor_admin_id']."  AND (a.`TH_TUTOR_COMPLETED_STATUS` = 1 OR a.TH_STUDENT_COMPLETED_STATUS=1) ORDER BY a.TH_BUZZ_DATE ASC ");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
       
    ?>
    
        <div class="mapCard">
            <div class="row py-2 ">
			 <div class="col-12 col-md-12 py-2 studentDetails">
			 <div class="d-flex justify-content">
                                        <?php
                                            if((int)$total_rows>0) {
											 $pagination_fetch1 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND (TH_TUTOR_COMPLETED_STATUS = 1 OR TH_STUDENT_COMPLETED_STATUS=1) ORDER BY TH_BUZZ_DATE ASC");
											 $totalMonths1 = $pagination_fetch1->fetchAll(PDO::FETCH_ASSOC);
                                            $col=9;
                                           
                                            foreach($totalMonths1 as $tm) {
                                        ?>
                                            <a href="?page=completed&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primaryss fonsig"<?php }else { ?> class="btn btn-soft-primarynn fonsig" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
			 <div class="">
                                        <table class="table table-bordered border-primary text-center mb-0">
                                            <thead>
                                                <tr>
                                                 <!-- <th>S.No</th>-->
                                                  <th>Tutor Name</th>
                                                  <th>Subject</th>
												  <th>Class Date & Time</th>
                                                  <th>Amount</th>
												  <th>Status</th>
												   <th>Agenda</th>
												   <th>Review</th>
												   <th>Recording Link</th>
												  <th>Action</th>
												 
                                                </tr>
                                              </thead>
                                              <tbody>
                                 <?php 
								 $i=1;
								 foreach ($fetchBokkingData as $fdb) { 
								 ?>
                                                <tr>
                                                  <!-- <td><?php echo $i; ?></td>-->
                                                  <td><?php echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME']; ?></td>
												  <?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
										  $getgroupd = $tutor_db->prepare("SELECT TH_SENDER FROM `tutor_hive_sendbuzz` WHERE `TH_RECEIVER`=? AND `TH_BUZZ_DATE`=? AND `TH_BUZZ_START_TIME`=? AND `TH_BUZZ_END_TIME`=? AND `TH_BUZZ_SUBJECT`=? AND `TH_BUZZ_LESSION_TYPE`=? AND `TH_BUZZ_LEVEL`=? AND `TH_TUTOR_METHOD`=? AND TH_STUDENT_CANCEL_STATUS=? AND TH_TUTOR_CANCEL_STATUS=? AND TH_REJECT_STATUS=?");
                                            $getgroupd->execute([$fdb['TH_RECEIVER'],$fdb['TH_BUZZ_DATE'],$fdb['TH_BUZZ_START_TIME'],$fdb['TH_BUZZ_END_TIME'],$fdb['TH_BUZZ_SUBJECT'],$fdb['TH_BUZZ_LESSION_TYPE'],$fdb['TH_BUZZ_LEVEL'],$fdb['TH_TUTOR_METHOD'],0,0,0]);
											$countofnog = $getgroupd->rowCount();
											?>
												   <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?>  <?php echo $countofnog; ?>/6<br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } else {?>
												  <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?> <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>(<?php echo $fdb['TH_TUTOR_METHOD'];?>) <?php } ?><br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } ?>
                                                  <td><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?><br><?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></td>
												   <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>
												   <td> FREE </td>
												   <?php } else { ?>
												   <td><?php if($fdb['PAYMENT_STATUS']==1){ ?> <span style="color: #15b815;font-weight: 700;">Paid</span> <?php } else { ?><span style="color: #ffd85d;font-weight: 700;">Unpaid</span><?php }?><br>£<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".","") ?></td>
												   <?php } ?>
												  <td>Completed</td>
												   <td> <?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-soft-primary ms-2" >Agenda</a><?php } else { echo "No Agenda";} ?></td>
												  <td>
												 <?php if($fdb['TUTOR_RATING']!="" && $fdb['TUTOR_REVIEW']!=""){?> 
												  <a href="#" class="btn btn-soft-primary ms-2" style="opacity: 0.2;">Rating</a>
												  <?php }else { ?>
												  <a href="#" onClick="Reviewbuss(<?php echo $fdb['TH_BUZZ_ID'] ?>)" class="btn btn-soft-primary ms-2">Rating</a>
												  <?php } ?>
												  
												  </td>
												  <td><?php if($fdb['TH_STUDENT_PDF']!=""){?><a href="<?php echo $fdb['TH_STUDENT_PDF']; ?>?pwd=<?php echo $fdb['PDF_PASSWORD']; ?>" target="_blank"  class="btn btn-soft-primary ms-2" >Video Link</a><?php } ?></td>
												  <td><a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="More Details" title="More Details" class="text-success"><img src="assets/images/search-more.png" class="intimetabl" /></a></td>
												  
                                                </tr>
                                    <?php $i++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
			</div>
            </div>
        </div>
       
    <?php exit;} else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Completed lessons</h4>
          </div>
    <?php }
        exit;
    }
	
	
    if(isset($_POST['reportedLession'])){
	$pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND UNPAID_CANCELLED!=1 AND (TH_BUZZ_DATE<'$tutor_date1' OR TH_REJECT_STATUS=1) ORDER BY TH_BUZZ_DATE DESC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetch();
     if($_GET['page']=="reported" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
  }else {
  $selMonth =$totalMonths['TH_BUZZ_MONTHS'];
  }
	
	 $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.TH_BUZZ_ID,
                                        a.TH_ISPRICE_PAY,
										a.TH_BOOKED_STATUS,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_REJECT_STATUS,
										a.SB_SSID,
										a.TH_AGENDA
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_RECEIVER = b.USER_ID
                                    WHERE
                                        a.TH_SENDER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth' AND a.TH_STATUS = 1 AND a.TH_TUTOR_CANCEL_STATUS!=1 AND a.TH_TUTOR_COMPLETED_STATUS!=1 AND a.TH_STUDENT_CANCEL_STATUS!=1 AND a.TH_STUDENT_COMPLETED_STATUS!=1 AND a.UNPAID_CANCELLED!=1 AND (a.TH_BUZZ_DATE<'$tutor_date1' OR a.TH_REJECT_STATUS=1) ORDER BY a.TH_BUZZ_DATE ASC");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
        
    ?>
    
        <div class="mapCard">
            <div class="row py-2 ">
			 <div class="col-12 col-md-12 py-2 studentDetails">
			 <div class="d-flex justify-content">
                                        <?php
                                            if((int)$total_rows>0) {
											$pagination_fetch1 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND UNPAID_CANCELLED!=1 AND (TH_BUZZ_DATE<'$tutor_date1' OR TH_REJECT_STATUS=1) ORDER BY TH_BUZZ_DATE ASC");
											$totalMonths1 = $pagination_fetch1->fetchAll(PDO::FETCH_ASSOC);
                                            $col=9;
                                           
                                            foreach($totalMonths1 as $tm) {
                                        ?>
                                           <a href="?page=reported&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primaryss fonsig"<?php }else { ?> class="btn btn-soft-primarynn fonsig" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
			 <div class="">
                                        <table class="table table-bordered border-primary text-center mb-0">
                                            <thead>
                                                <tr>
                                                 <!-- <th>S.No</th>-->
                                                  <th>Tutor Name</th>
                                                  <th>Subject</th>
												  <th>Class Date & Time</th>
                                                  <th>Amount</th>
												  <th>Status</th>
												   <th>Agenda</th>
                                                  <th>Action</th>
												 
                                                </tr>
                                              </thead>
                                              <tbody>
                                 <?php 
								 $i=1;
								 foreach ($fetchBokkingData as $fdb) { 
								 ?>
                                                <tr>
                                                 <!-- <td><?php echo $i; ?></td>-->
                                                  <td><?php echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME']; ?></td>
												  <?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
										  $getgroupd = $tutor_db->prepare("SELECT TH_SENDER FROM `tutor_hive_sendbuzz` WHERE `TH_RECEIVER`=? AND `TH_BUZZ_DATE`=? AND `TH_BUZZ_START_TIME`=? AND `TH_BUZZ_END_TIME`=? AND `TH_BUZZ_SUBJECT`=? AND `TH_BUZZ_LESSION_TYPE`=? AND `TH_BUZZ_LEVEL`=? AND `TH_TUTOR_METHOD`=? AND TH_STUDENT_CANCEL_STATUS=? AND TH_TUTOR_CANCEL_STATUS=? AND TH_REJECT_STATUS=?");
                                            $getgroupd->execute([$fdb['TH_RECEIVER'],$fdb['TH_BUZZ_DATE'],$fdb['TH_BUZZ_START_TIME'],$fdb['TH_BUZZ_END_TIME'],$fdb['TH_BUZZ_SUBJECT'],$fdb['TH_BUZZ_LESSION_TYPE'],$fdb['TH_BUZZ_LEVEL'],$fdb['TH_TUTOR_METHOD'],0,0,0]);
											$countofnog = $getgroupd->rowCount();
											?>
												   <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?>  <?php echo $countofnog; ?>/6<br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } else {?>
												  <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?> <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>(<?php echo $fdb['TH_TUTOR_METHOD'];?>) <?php } ?><br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } ?>
                                                  <td><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?><br><?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></td>
												   <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>
												   <td> FREE </td>
												   <?php } else { ?>
												   <td><?php if($fdb['PAYMENT_STATUS']==1){ ?> <span style="color: #15b815;font-weight: 700;">Paid</span> <?php } else { ?><span style="color: #ffd85d;font-weight: 700;">Unpaid</span><?php }?><br>£<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".","") ?></td>
												   <?php } ?>
												 <td><?php if($fdb['TH_REJECT_STATUS']==1){ echo "Rejected";} else if($fdb['PAYMENT_STATUS']==1){ echo "Confirmed";} else if($fdb['TH_BOOKED_STATUS']==1){echo "Accepted";}else {echo "Pending"; }?></td>
												  <td> <?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-soft-primary ms-2" >Agenda</a><?php } else { echo "No Agenda";} ?></td>
												  <td class="h4 text-center">
                                					<!--	<a href="#" onClick="delclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Cancel" title="Cancel" class="text-danger"><img src="assets/images/icons-cancel.svg" class="intimetabl" /></a>-->
                                						<a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="More Details" title="More Details" class="text-success"><img src="assets/images/search-more.png" class="intimetabl" /></a>
												  </td>
												  
												  
                                                </tr>
                                    <?php $i++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
			</div>
            </div>
        </div>
       
    <?php exit; }else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Rejected  lessons</h4>
          </div>
    <?php }
        exit;
    }
    
 
?>
<!doctype html>
<html lang="en" dir="ltr">

    <head>
        <meta charset="utf-8" />
        <title>TutorHive - Student Timetable </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta name="description" content="Premium Bootstrap 5 Landing Page Template" />
        <meta name="keywords" content="Saas, Software, multi-uses, HTML, Clean, Modern" />
        <meta name="author" content="Shreethemes" />
        <meta name="email" content="support@shreethemes.in" />
        <meta name="website" content="https://shreethemes.in" />
        <meta name="Version" content="v4.2.0" />
        <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
        <?php include('common/headerlinks.php');?>
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
        <link rel="stylesheet" href="./assets/OwlCarousel/dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="./assets/OwlCarousel/dist/assets/owl.theme.default.min.css">
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <style>
           .buzzSet .avil{background:#ffd85d;color:#000;padding:10px;border-radius:10px;font-weight:900;border:2px solid #000;border-left:20px solid}.buzzSet .form-check .form-check-input{border:2px solid #0e0e0e}.buzzSet .avil h5{font-size:16px;display:flex;margin:0;align-items:center}.buzzSet .avil h5 span.mdi.mdi-teach{font-size:30px;margin-right:10px}.buzzSet .form-control{background:#ffd85d!important;border:2px solid #000;font-weight:900}.buzzSet .form-control:focus{border-color:#fff}.buzzSet{padding:20px}.userpop{position:relative}.closeBtnBuzz{background:0 0;font-size:25px;position:absolute;right:15px;color:#ffd85d;top:16px;font-weight:bolder;border:none}.closeBtn{background:0 0;font-size:25px;position:absolute;right:-10px;top:-10px;font-weight:bolder;border:none}.backBtnBuzz{background:0 0;font-size:25px;position:absolute;left:15px;color:#ffd85d;top:16px;font-weight:bolder;border:none}#finalBuzz .backBtnBuzz,#finalBuzz .closeBtnBuzz{color:#000}.modal-content{border-radius:30px;border:10px solid #ffd85d!important;box-shadow:0 0 30px 10px #484743}.profile-header{background:#ffd85d;padding:30px 10px;border-radius:10px 10px 0 0}.flatpickr-calendar.arrowTop:after,.flatpickr-calendar.arrowTop:before{border-bottom-color:#ffd85d}.bg-theme,.flatpickr-day selected,.flatpickr-time .flatpickr-am-pm,.flatpickr-time .flatpickr-time-separator,.flatpickr-time input{background-color:#ffd85d!important}.flatpickr-day.endRange,.flatpickr-day.endRange.inRange,.flatpickr-day.endRange.nextMonthDay,.flatpickr-day.endRange.prevMonthDay,.flatpickr-day.endRange:focus,.flatpickr-day.endRange:hover,.flatpickr-day.selected,.flatpickr-day.selected.inRange,.flatpickr-day.selected.nextMonthDay,.flatpickr-day.selected.prevMonthDay,.flatpickr-day.selected:focus,.flatpickr-day.selected:hover,.flatpickr-day.startRange,.flatpickr-day.startRange.inRange,.flatpickr-day.startRange.nextMonthDay,.flatpickr-day.startRange.prevMonthDay,.flatpickr-day.startRange:focus,.flatpickr-day.startRange:hover{background:#000;-webkit-box-shadow:none;box-shadow:none;color:#ffd85d;border-color:#000}.flatpickr-day.inRange,.flatpickr-day.nextMonthDay.inRange,.flatpickr-day.nextMonthDay.today.inRange,.flatpickr-day.nextMonthDay:focus,.flatpickr-day.nextMonthDay:hover,.flatpickr-day.prevMonthDay.inRange,.flatpickr-day.prevMonthDay.today.inRange,.flatpickr-day.prevMonthDay:focus,.flatpickr-day.prevMonthDay:hover,.flatpickr-day.today.inRange,.flatpickr-day.today:focus,.flatpickr-day.today:hover,.flatpickr-day:focus,.flatpickr-day:hover,flatpickr-day.today:hover{border-color:#000;background:#000;color:#ffd85d}.flatpickr-day.endRange,.flatpickr-day.endRange.inRange,.flatpickr-day.endRange.nextMonthDay,.flatpickr-day.endRange.prevMonthDay,.flatpickr-day.endRange:focus,.flatpickr-day.endRange:hover,.flatpickr-day.selected.inRange,.flatpickr-day.selected.nextMonthDay,.flatpickr-day.selected.prevMonthDay,.flatpickr-day.selected:focus,.flatpickr-day.selected:hover,.flatpickr-day.startRange,.flatpickr-day.startRange.inRange,.flatpickr-day.startRange.nextMonthDay,.flatpickr-day.startRange.prevMonthDay,.flatpickr-day.startRange:focus,.flatpickr-day.startRange:hover{background:#000!important;-webkit-box-shadow:none;box-shadow:none;color:#ffd85d;font-weight:900;border-color:#000}.flatpickr-calendar{background:#ffd85d}.flatpickr-day,.flatpickr-time .flatpickr-am-pm,.flatpickr-time input.flatpickr-minute,.flatpickr-time input.flatpickr-second,span.flatpickr-weekday{font-weight:900;color:#000}.border-theme{border-color:#ffd85d!important}.color-theme{color:#ffd85d!important}.profile-image{position:relative;display:flex;justify-content:center;min-height:100px}.profile-image>img{width:100px;height:100px;border-radius:50px!important;background:#ffd85d;box-shadow:0 0 5px #262521;padding:4px;position:absolute;top:-25px}.user-disc ul>span::marker{color:#ffd85d}.user-disc .bg-warning,.user-info .bg-warning{background-color:#ffd85d!important}#map{width:100%;height:650px}.userpop h5{margin:5px 0 0 0;font-size:16px}.mapCard{overflow:hidden;background:#ffd85d;border-radius:5px;padding:0 20px;text-align:center;margin-bottom:10px;}.gm-style .gm-style-iw-c{font-weight:900}.map-user-thumb{width:100px;height:100px;border-radius:50px!important;background:#ffd85d;box-shadow:0 0 5px #262521;padding:4px}@media (max-width:500px){.gm-style .gm-style-iw-c{width:100%}}.imgmun{height:30px;width:40px}.fltrthid{float:right}@media (max-width:767px){body{font-size:14px}.col-sm-6{width:50%}.col-xs-6{width:50%}.p-4{padding:5px!important}.col-sm-12{width:100%}.col-xs-12{width:100%}.mt-4{margin-top:.5rem!important}.imgmun{height:25px;width:30px}.ms-2{margin-left:0!important}.fltrthid{float:left}.munpad{padding-bottom:7px}.breadcrumb .breadcrumb-item{font-size:14px}}#mapCanvas{width:100%;height:650px}.hexa,.hexa div{margin:0 auto;transform-origin:50% 50%;overflow:hidden;width:115px;height:103px}.hex2>img{width:100%;height:100%}.hexa{transform:rotate(150deg)}.hex1{transform:rotate(-60deg)}.hex2{transform:rotate(-60deg)}#style-3::-webkit-scrollbar-track{border-radius:10px;-webkit-box-shadow:inset 0 0 3px rgba(0,0,0,.3);background-color:#f5f5f5}#style-3::-webkit-scrollbar{border-radius:10px;width:3px;height:8px;background-color:#f5f5f5}#style-3::-webkit-scrollbar-thumb{border-radius:10px;background-color:#ffd85d}::-webkit-scrollbar-track{border-radius:10px}::-webkit-scrollbar{border-radius:10px;width:10px;background-color:#f5f5f5}::-webkit-scrollbar-thumb{border-radius:10px;background-color:#ffd85d}.owl-nav{position:relative;bottom:150px;display:flex;justify-content:space-between;font-size:50px}@media (max-width:500px){.owl-nav{bottom:195px}}
        
        .select2 .select2-container .select2-container--default .select2-container--focus{width:-webkit-fill-available!important}.select2-container--default .select2-results__option--highlighted[aria-selected]{background-color:#ffd85d}.select2-container .select2-selection--single{height:42.5px!important;border-radius: 0px;}.select2-container--default .select2-selection--single .select2-selection__rendered{line-height:42.5px}.select2-container--default .select2-selection--single .select2-selection__arrow{height:42.5px}
        .select2-container--default .select2-selection--single , .select2-container--default .select2-search--dropdown .select2-search__field , .select2-dropdown{
            border-color:#ffd85d;
        }
        
        
        .timetable .timetable-header{
            min-height: 100px;
            background-color: #ffd85d;
            color: #000;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 3px 3px 0 0;
            margin-bottom: 10px;
        }
        .timetable .timetable-header > h3 {
            color:inherit;
            font-size:2rem;
            text-align:center;
        }
        
        .timetable .navigation > .nav {
            position: absolute;
            top: -25px;
            left: 1%;
            right: 1%;
            background-color: #ffe981;
            border-radius: 50px;
            box-shadow: 0px 1px 5px #c2c2c2;
            padding: 9px 0px;
            font-size: 16px;
        }
        
        .timetable .navigation .nav-pills .nav-link.active{
            background: #ffffff;
            color: #ffd85d!important;
            border-radius: 50px;
        }
        
       .timetable .navigation .nav-pills .nav-link {
           font-weight:bolder;
       }
        .page-wrapper .page-content .layout-specing{
            padding-top:70px !important;
        }
        
        .studentDetails {
            text-align:left;
            text-indent:0px;
        }
        @media (max-width: 767px) {
            .studentDetails {
                text-indent:0px;
            }
        }
		
			.form-control:disabled {
    background-color: #ffffff;
}
.btn-soft-primary {
    background-color: rgb(0 0 0)!important;
    border: 1px solid rgb(0 0 0)!important;
    color: #ffffff!important;
   
}
.btn-soft-primaryss {
    background-color: #000;
    border: 1px solid #000!important;
    color: #ffffff!important;
   
}
.btn-soft-primarynn {
    background-color: #fce7a6;
    border: 1px solid #fce7a6!important;
    color: #000!important;
   
}
.btn-soft-primary:hover {
    background-color: #ffd85d!important;
    border-color: #ffd85d!important;
    color: #000!important;
}

.rating { 
border: none;
float: left;
}
.rating > input { display: none; } 
.rating > label:before { 
margin: 0 5px;
font-size: 1.25em;
font-family: FontAwesome;
display: none;
content: "\f005";
}
.rating > .half:before { 
content: "\f089";
position: absolute;
}
.rating > label { 
color: #ddd; 
float: right; 
}
.rating > input:checked ~ label, 
.rating:not(:checked) > label:hover,  
.rating:not(:checked) > label:hover ~ label { color: #ffd85d;  }
.rating > input:checked + label:hover, 
.rating > input:checked ~ label:hover,
.rating > label:hover ~ input:checked ~ label, 
.rating > input:checked ~ label:hover ~ label { color: #ffd85d;  } 
  .rating1 { 
border: none;
float: left;
}
.rating1 > input { display: none; } 
.rating1 > label:before { 
margin: 0 5px;
font-size: 1.25em;
font-family: FontAwesome;
display: inline-block;
content: "\f005";
}
.rating1 > .half:before { 
content: "\f089";
position: absolute;
}
.rating1 > label { 
color: #ddd; 
float: right; 
}
.rating1 > input:checked ~ label  { color: #ffd85d;  }
.rating1 > label:hover ~ input:checked ~ label, 
.rating1 > input:checked ~ label:hover ~ label { color: #ffd85d;  }
.pb-10{
    padding-bottom: 12px !important;
}
.btn {
    padding: 2px 14px;
   
}
.intimetabl{
width:30px;
height:30px;
}

.fonsig{
font-size:20px;
}

@media (max-width: 767px) {
p {
   font-size: 12px;
}
.h6, h6 {
    font-size: 14px;
}
.h5, h5 {
    font-size: 16px;
}
.mt-4 {
    margin-top: 0.7rem!important;
}
.form-control {
    font-size: 12px;
    line-height: 18px;
}
.p-4 {
    padding: 1.0rem!important;
}
.p-3 {
    padding: 0.3rem!important;
}
th, td {
font-size:9px;
}
.btn-group-sm>.btn, .btn.btn-sm {
    padding: 2px 6px;
    font-size: 8px;
}
.preferdays label span {
    padding: 4px 8px;
    background: #ffd85d;
    color: #000;
    font-size: 12px;
    cursor: pointer;
    border-radius: 5px;
}
.timetable .timetable-header > h3 {
    font-size: 20px;
}
.timetable .navigation .nav-pills .nav-link.active {
    font-size: 15px;
}
.timetable .navigation .nav-pills .nav-link {
    font-size: 15px;
}
.mt-5 {
    margin-top: 1.5rem!important;
}
.table>:not(caption)>*>* {
    padding: 2px;
	}
	.mapCard {
   padding: 0px 0px;  
}
.py-2 {
     padding-top: 0rem!important; 
    padding-bottom: .5rem!important;
}
.btn {
    padding: 2px 4px;
    font-size: 10px;
}
.intimetabl{
width:12px;
height:12px;
}
.fonsig{
font-size:16px;
}
}
        </style>
		

    </head>

    <body>

        <div class="page-wrapper toggled">
             <?php include('common/leftmenu.php');?>

            <main class="page-content bg-light">
                 <?php  include('common/header.php');?>
                <div>
                    <div class="layout-specing">
                        <div class="row justify-content-center align-items-center">
                            <div class="col col-md-12 ">
                                <div class="card">
                                    <div class="card-body card-body pt-0 px-0">
                                        <div class="timetable">
                                            <div class="timetable-header">
                                                 <h3 id="timetable-title">Booked</h3>
                                            </div>
                                            <div class="navigation position-relative">
                                                <ul class="nav nav-pills justify-content-center">
                                                   <!-- <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('avil-tab','avil','Set Availability')" id="avil-tab" data-bs-toggle="tab" data-bs-target="#avil" type="button" role="tab" >Availability</button>
                                                    </li>-->
                                                    <li class="nav-item">
                                                        <button class="nav-link active" onClick="tabclick('Booked')" id="booked-tab" data-bs-toggle="tab" data-bs-target="#booked" type="button" role="tab">Booked</button>
                                                    </li>
                                                    <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('Cancelled')" id="cancelled-tab" data-bs-toggle="tab" data-bs-target="#cancelled" type="button" role="tab">Cancelled</button>
                                                    </li>
                                                    <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('Completed')" id="completed-tab" data-bs-toggle="tab" data-bs-target="#completed" type="button" role="tab">Completed</button>
                                                    </li>
                                                    <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('Rejected')" id="reported-tab" data-bs-toggle="tab" data-bs-target="#reported" type="button" role="tab">Rejected</button>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="tab-content mt-5 p-2" id="myTabContent">
                                              <div class="tab-pane fade active show" id="booked" role="tabpanel" aria-labelledby="booked-tab">
                                                   <!-- <div>
                                                        <div class="mb-3">
                                                            <label for="searchBokkingDate" class="form-label">Search Date</label>
                                                            <input type="text" class="form-control searchdate flatpickr flatpickr-input" id="searchBokkingDate" placeholder="Select Date">
                                                        </div>
                                                        <div class="d-flex justify-content-center">
                                                            <button class="btn btn-primary w-50 py-2" id="bookingSearch">Search</button>
                                                        </div>
                                                    </div>
                                                    <div id="BookingsDisp" class="my-3"></div>-->
											 <button class="btn btn-primary w-50 py-2" style="display:none;" id="bookingSearch">Search</button>
													  <div id="BookingsDisp" class="my-3">
													  <?php 
													  $pagination_fetch111 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 AND TH_BUZZ_DATE>='$tutor_date1' AND TH_BUZZ_MONTHS>='$tutor_date122' ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");
													  $totalMonths1 = $pagination_fetch111->fetch();	
													  
	$pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_SENDER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 AND TH_BUZZ_DATE>='$tutor_date1' ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetchAll(PDO::FETCH_ASSOC);
     if($_GET['page']=="booked" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
   } else if ($totalMonths1['TH_BUZZ_MONTHS']!=""){
 $selMonth =$totalMonths1['TH_BUZZ_MONTHS'];
  }else {
  $selMonth =$totalMonths[0]['TH_BUZZ_MONTHS'];
  }
	
	 $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.TH_BUZZ_ID,
                                        a.TH_ISPRICE_PAY,
										a.TH_BOOKED_STATUS,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_RECEIVER,
										a.TH_AGENDA,
										a.GROUP_ID,
										a.SB_SSID,
										a.MEETING_LINK
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_RECEIVER = b.USER_ID
                                    WHERE
                                        a.TH_SENDER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth' AND a.TH_STATUS = 1 AND a.TH_TUTOR_CANCEL_STATUS!=1 AND a.TH_TUTOR_COMPLETED_STATUS!=1 AND a.TH_STUDENT_CANCEL_STATUS!=1 AND a.TH_STUDENT_COMPLETED_STATUS!=1 AND a.TH_REJECT_STATUS!=1 AND a.UNPAID_CANCELLED!=1 AND a.TH_BUZZ_DATE>='$tutor_date1' ORDER BY a.TH_BUZZ_DATE,a.TH_BUZZ_START_TIME ASC");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
        
    ?>
    
        <div class="mapCard">
            <div class="row py-2 ">
			 <div class="col-12 col-md-12 py-2 studentDetails">
			 <div class="d-flex justify-content">
                                        <?php
                                            if((int)$total_rows>0) {
                                            $col=9;
                                           
                                            foreach($totalMonths as $tm) {
                                        ?>
                                            <a href="?page=booked&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primaryss fonsig"<?php }else { ?> class="btn btn-soft-primarynn fonsig" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
			 <div class="">
                                        <table class="table table-bordered border-primary text-center mb-0">
                                            <thead>
                                                <tr>
                                                <!-- <th>S.No</th>-->
                                                  <th>Tutor Name</th>
                                                  <th>Subject</th>
												  <th>Class Date & Time</th>
                                                  <th>Amount</th>
												  <th>Status</th>
												   <th>Class Link</th>
												   <th>Agenda</th>
                                                  <th>Action</th>
                                                </tr>
                                              </thead>
                                              <tbody>
                                 <?php 
								 $i=1;
								 foreach ($fetchBokkingData as $fdb) { 
								 ?>
                                                <tr>
                                                <!-- <td><?php echo $i; ?></td>-->
                                                  <td><?php echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME']; ?></td>
												  <?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
										  $getgroupd = $tutor_db->prepare("SELECT TH_SENDER FROM `tutor_hive_sendbuzz` WHERE `TH_RECEIVER`=? AND `TH_BUZZ_DATE`=? AND `TH_BUZZ_START_TIME`=? AND `TH_BUZZ_END_TIME`=? AND `TH_BUZZ_SUBJECT`=? AND `TH_BUZZ_LESSION_TYPE`=? AND `TH_BUZZ_LEVEL`=? AND `TH_TUTOR_METHOD`=? AND TH_STUDENT_CANCEL_STATUS=? AND TH_TUTOR_CANCEL_STATUS=? AND TH_REJECT_STATUS=?");
                                            $getgroupd->execute([$fdb['TH_RECEIVER'],$fdb['TH_BUZZ_DATE'],$fdb['TH_BUZZ_START_TIME'],$fdb['TH_BUZZ_END_TIME'],$fdb['TH_BUZZ_SUBJECT'],$fdb['TH_BUZZ_LESSION_TYPE'],$fdb['TH_BUZZ_LEVEL'],$fdb['TH_TUTOR_METHOD'],0,0,0]);
											$countofnog = $getgroupd->rowCount();
											?>
												   <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?>  <?php echo $countofnog; ?>/6<br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } else {?>
												  <td><?php echo $fdb['TH_BUZZ_LESSION_TYPE'];?> <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?>(<?php echo $fdb['TH_TUTOR_METHOD'];?>) <?php } ?><br><?php echo $fdb['TH_BUZZ_SUBJECT']?></td>
												   <?php } ?>
                                                  <td><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?><br><?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></td>
												   <td><?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){?> FREE <?php }else{  if($fdb['TH_BOOKED_STATUS']==1){?><?php if($fdb['PAYMENT_STATUS']==1){?> <span style="color: #15b815;font-weight: 700;">Paid</span> <?php } else { 
												   if ($fdb['TH_BUZZ_DATE'] == $tutor_date1 && $tutor_time >= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -1 hours"))){?>
								<a href="#" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;opacity: 0.3;cursor: no-drop;">Pay Now</a> 
								<?php }else { ?>
								<a href="#" onClick="paymentClass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;">Pay Now</a>
								<?php } ?>
							 <?php }?> <?php } else { ?><span style="color: #ffd85d;font-weight: 700;">Pending</span><?php } ?><br><?php if($fdb['TH_TOTAL_PRICE']!=""){?>£<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".","");} else {?> £ 0.00<?php }} ?></td>
												 <td><?php if($fdb['PAYMENT_STATUS']==1){ echo "Confirmed";} else if($fdb['TH_BOOKED_STATUS']==1){echo "Accepted";}else {echo "Pending"; }?></td>
												  <td>  
												  <?php if($fdb['PAYMENT_STATUS']==1){
												  if($fdb['TH_TUTOR_METHOD']=="Online" || $fdb['TH_TUTOR_METHOD']=="Intro Call"){  ?>
												   <?php if($tutor_date1==$fdb['TH_BUZZ_DATE'] && $tutor_time>="08:00" && $fdb['TH_BUZZ_END_TIME']>$tutor_time){?>
									 <?php if ($fdb['TH_BUZZ_DATE'] == $tutor_date1 && $tutor_time >= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -1 hours"))){ ?>
												   <a href="<?php echo $fdb['MEETING_LINK']; ?>" target="_blank"  alt="Join Now" title="Join Now" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;">Join Now</a> 
												    <?php }else {?>
												    <a href="<?php echo $fdb['MEETING_LINK']; ?>" target="_blank"  alt="Meeting Link" title="Meeting Link" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;">Meeting Link</a> 
												  <?php }}}else { echo "In-person";}
												  } ?>
												  </td>
												   <td> <?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-soft-primary ms-2" >Agenda</a><?php } else { echo "No Agenda";} ?></td>
												  <td class="h4 text-center">
											  <?php if ($fdb['TH_BUZZ_DATE']> $tutor_date1){?>
											<a href="#" onClick="delclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Cancel" title="Cancel" class="text-danger"><img src="assets/images/icons-cancel.svg" class="intimetabl" /></a>	 
								 <?php }else if($fdb['TH_BUZZ_DATE']== $tutor_date1 && $tutor_time <= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -2 hours"))){  ?>
						<a href="#" onClick="delclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Cancel" title="Cancel" class="text-danger"><img src="assets/images/icons-cancel.svg" class="intimetabl"  /></a>
						<?php } ?>
						<?php //if($fdb['PAYMENT_STATUS']==1 && $fdb['TH_BOOKED_STATUS']==1){
						       $gid = $fdb['GROUP_ID'];
						       $chatCount = $tutor_db->query("SELECT COUNT(`GROUP_ID`) as chatcount FROM `buzz_chat_internal` WHERE `GROUP_ID`='$gid'")->fetch(PDO::FETCH_ASSOC);
						        
						?>
						<a style="position:relative;" href="#" onClick="chatShow('<?php echo $fdb['TH_BUZZ_ID'] ?>')" class="text-success">
						    <img src="assets/images/chatd.png" class="intimetabl"  alt="Chat" title="Chat"  />
						    <span style="font-size: 12px;padding: 1px 5px;border-radius: 50%;background: #000;position: absolute;right: 0;"><?php echo $chatCount['chatcount'] ?></span>
						</a>
						<?php // } ?>
						<a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="More Details" title="More Details" class="text-success"><img src="assets/images/search-more.png" class="intimetabl"  /></a>
												  </td>
												 
												 
                                                </tr>
                                    <?php $i++;} ?>
                                            </tbody>
                                        </table>
                                    </div>
			</div>
            </div>
        </div>
       
    <?php } else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Booked lessons</h4>
          </div>
    <?php } ?>
													  
													  </div>
                                              </div>
                                              <div class="tab-pane fade" id="cancelled" role="tabpanel" aria-labelledby="cancelled-tab">
                                                  <!-- <div>
                                                        <div class="mb-3">
                                                            <label for="searchCancelDate" class="form-label">Search Date</label>
                                                            <input type="text" class="form-control searchdate flatpickr flatpickr-input" id="searchCancelDate" placeholder="Select  Date">
                                                        </div>
                                                        <div class="d-flex justify-content-center">
                                                            <button class="btn btn-primary w-50 py-2" id="cancelSearch">Search</button>
                                                        </div>
                                                    </div>
                                                    <div id="CancelDisp" class="my-3"></div>-->
													 <button class="btn btn-primary w-50 py-2" style="display:none;" id="cancelSearch">Search</button>
													  <div id="CancelDisp" class="my-3"></div>
													
													
													
                                              </div>
                                              <div class="tab-pane fade" id="completed" role="tabpanel" aria-labelledby="completed-tab">
                                                  <!--<div>
                                                        <div class="mb-3">
                                                            <label for="searchCompletedDate" class="form-label">Search Date</label>
                                                            <input type="text" class="form-control searchdate flatpickr flatpickr-input" id="searchCompletedDate" placeholder="Select  Date">
                                                        </div>
                                                        <div class="d-flex justify-content-center">
                                                            <button class="btn btn-primary w-50 py-2" id="compltedSearch">Search</button>
                                                        </div>
                                                    </div>
                                                    <div id="completedDisp" class="my-3"></div>-->
														 <button class="btn btn-primary w-50 py-2" style="display:none;" id="compltedSearch">Search</button>
													  <div id="completedDisp" class="my-3"></div>
													
													
                                              </div>
                                              <div class="tab-pane fade" id="reported" role="tabpanel" aria-labelledby="reported-tab">
                                                  <!--  <div>
                                                        <div class="mb-3">
                                                            <label for="reportedSearchDate" class="form-label">Search Date</label>
                                                            <input type="text" class="form-control searchdate flatpickr flatpickr-input" id="reportedSearchDate" placeholder="Select  Date">
                                                        </div>
                                                        <div class="d-flex justify-content-center">
                                                            <button class="btn btn-primary w-50 py-2" id="reportedSearch">Search</button>
                                                        </div>
                                                    </div>
                                                    <div id="reportedDesp" class="my-3"></div>-->
													<button class="btn btn-primary w-50 py-2" style="display:none;" id="reportedSearch">Search</button>
													  <div id="reportedDesp" class="my-3"></div>
          </div>
                                              </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
               <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#LoginForm" id="ClickModal" class="btn btn-primary m-1" style="display:none"> Click Here</a>
			   <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#acceptForm" id="ClickModal1" class="btn btn-primary m-1" style="display:none"> Click Here</a>
			    <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#ajandaForm" id="ClickModal2" class="btn btn-primary m-1" style="display:none"> Click Here</a>
				 <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#popupurl" id="ClickModal3" class="btn btn-primary m-1" style="display:none"> Click Here</a>
				  <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#reviwForm" id="ClickModal4" class="btn btn-primary m-1" style="display:none"> Click Here</a>
                <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#lessalert" id="ClickModal5" class="btn btn-primary m-1" style="display:none"> Click Here</a>
                <!-- loaderModal -->
               <div class="modal " id="waitLoader" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="display: none;">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-body text-center color-theme">
                        <h4>Loading <i class="mdi mdi-spin mdi-loading"></i></h4>
                      </div>
                    </div>
                  </div>
                </div>
                
                <!--Content Modal-->
                <div class="modal " id="contentModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" style="max-width:650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6 class="modal-title fw-bold">Buzz Chat <br> <small class="text-black-50 fw-normal fs-6 ">( Note : Allowed only 50 conversations )</small> </h6>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><span class="mdi mdi-close-thick"></span></button>
                            
                        </div>
                        <div class="modal-body color-theme" id="contentDiv">
                            <h5>Loading your chat , please wait <i class="mdi mdi-spin mdi-loading"></i></h5>
                        </div>
                    </div>
                  </div>
                </div>
                
               <footer class="shadow  d-flex align-items-center justify-content-center">
                    <div class="container">
                        <div class="row ">
                            <div class="col-12 ">
                                <p class="mb-0 text-center">Copyright © 2022 TutorHive. All Rights Reserved</p>
                            </div>
                        </div>
                    </div>
                </footer>
            </main>
        </div>
		
       <div class="modal fade" id="LoginForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                         <div id="Ajaxidapi"></div>  
                                        </div>
                                    </div>
									
										<div class="modal fade" id="acceptForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                          <div id="Ajaxidapi1"></div> 
                                        </div>
                                    </div>
									<div class="modal fade" id="ajandaForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                          <div id="Ajaxidapi2" style="width:70%"></div> 
                                        </div>
                                    </div>
									
									<div class="modal fade" id="popupurl" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                          <div id="Ajaxidapi3"></div> 
                                        </div>
                                    </div>
									
									<div class="modal fade" id="reviwForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                         <div id="Ajaxidapi4"></div>  
                                        </div>
                                    </div>
									
									
									<div class="modal fade" id="lessalert" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                        <div class="modal-content rounded shadow border-0">
                                                <div class="modal-header border-bottom" style="display: -webkit-box;-webkit-box-align: start;">
												 <?php 
												 $id=1;
                                                 $stmtrr = $tutor_db->prepare("SELECT * FROM alt_timetable_labels WHERE s_no=?");
                                                 $stmtrr->execute([$id]); 
                                                 $userrr = $stmtrr->fetch();
			                                      ?>
												  
                                                    <h5 class="modal-title" id="LoginForm-title"><?php if($_GET['alt']=='Yes'){ echo $userrr['ONETOONE_LABLE']; }else if($_GET['alt']=='Succ'){echo $userrr['GROUP_LABEL'] ;}?></h5>
													<button type="button" class="btn btn-icon btn-close" data-bs-dismiss="modal" style="margin-left: -15px;margin-bottom: 5px;" id="close-modal"><i class="uil uil-times fs-4 text-dark"></i></button>
                                                    
                                                </div>
                                               <!--end col-->
                                                <div class="modal-footer" style="display: block; text-align:center;">
                                                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="close-modal">Okay</button>
                                                </div>
                                            </div> 
                                        </div>
                                    </div>
									
									
		 <?php include('common/footerlinks.php');?>
		 <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
		 <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
		 <script src="./assets/OwlCarousel/dist/owl.carousel.min.js"></script>
		 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
		 
		  <?php if($_GET['page']=='canceled'){?>
			            <script>
						$(document).ready(function(){
			            document.getElementById("cancelled-tab").click();
						});
			            </script>
			  <?php } if($_GET['page']=='completed'){?>
			   <script>
						$(document).ready(function(){
			            document.getElementById("completed-tab").click();
						});
			            </script>
			 <?php } if($_GET['alt']=='Yes' || $_GET['alt']=='Succ'){?>
			   <script>
						$(document).ready(function(){
			            document.getElementById("ClickModal5").click();
						});
			            </script>
						<?php } if($_GET['page']=='reported'){?>
			   <script>
						$(document).ready(function(){
			            document.getElementById("reported-tab").click();
						});
			            </script>
			  <?php }  ?>	
	
       <script>
function tabclick(val){
if(val=="Booked"){
document.getElementById("timetable-title").innerHTML= val;
document.getElementById("bookingSearch").click();
}else if(val=="Cancelled"){
document.getElementById("timetable-title").innerHTML= val;
document.getElementById("cancelSearch").click();
}else if(val=="Completed"){
document.getElementById("timetable-title").innerHTML= val;
document.getElementById("compltedSearch").click();
}else if(val=="Rejected"){
document.getElementById("timetable-title").innerHTML= val ;
document.getElementById("reportedSearch").click();
}
}

function paymentClass(val){
  //  alert(val);
var dataString = 'paymentid='+ val;
//alert(dataString)
$.ajax
		({
		type: "POST",
		url: "ajax_paymentclass.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal1").click();
		document.getElementById("Ajaxidapi1").innerHTML = data;
		}
			});
}  

 function AgendaDetail(val){
  //  alert(val);
var dataString = 'buzzid='+ val;
//alert(dataString)
$.ajax
		({
		type: "POST",
		url: "ajax_Agendadetails.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal2").click();
		document.getElementById("Ajaxidapi2").innerHTML = data;
		}
			});
}	

 function MoreDetails(val){
  //  alert(val);
var dataString = 'buzzid='+ val;
//alert(dataString)
$.ajax
		({
		type: "POST",
		url: "ajax_buzzdetails.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal").click();
		document.getElementById("Ajaxidapi").innerHTML = data;
		}
			});
}

function delclass(val){
   // alert(val);
   if(confirm("Are you sure you would like to cancel this lesson?"))
{
var type= "Cancel";
	var dataString = 'bussid='+ val +'&type='+type;
	//alert(dataString);
	$.ajax
		({
		type: "POST",
		url: "ajax_buesschnage.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
			if(data=="Api Error"){
		alert("APIs went wrong please try again");
		}else
		if(data!=""){
		document.location.href='student_timetable?page=booked&my='+data;
		}else{
		alert("something went wrong please try again");
		}
		}
			});
}
}
function Compclass(val){
   // alert(val);
    if(confirm("Are you sure you want to mark this lesson as complete?"))
{
var type= "Completed";
	var dataString = 'bussid='+ val +'&type='+type;
	//alert(dataString);
	$.ajax
		({
		type: "POST",
		url: "ajax_buesschnage.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		if(data!=""){
		document.location.href='student_timetable?page=booked&my='+data;
		}else{
		alert("something went wrong please try again");
		}
		}
			});
}
}

function Getclassurl(val){
var type= "Joinclass";
	var dataString = 'bussid='+ val +'&type='+type;
	//alert(dataString);
	$.ajax
		({
		type: "POST",
		url: "ajax_buesschnage.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		if(data=="Api Error"){
		alert("APIs went wrong please try again");
		}else if(data==101){
		alert("something went wrong please try again");
		}else if(data!=""){
		   window.open(data, '_blank');
		}else{
		alert("something went wrong please try again");
		}
		}
			});
}

function Reviewbuss(val){
   // alert(val);
  
var dataString = 'buss_id='+ val;
$.ajax
		({
		type: "POST",
		url: "ajax_tutorreview.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal4").click();
		document.getElementById("Ajaxidapi4").innerHTML = data;
		}
			});
}

function addreviewBuss(){
var type="SRT"
 if($('#star5').is(':checked')==true){
 var rateing=$("#star5").val();
 }else if ($('#star4').is(':checked')==true){
  var rateing=$("#star4").val();
 }else if ($('#star3').is(':checked')==true){
  var rateing=$("#star3").val();
 }else if ($('#star2').is(':checked')==true){
  var rateing=$("#star2").val();
 }else if ($('#star1').is(':checked')==true){
  var rateing=$("#star1").val();
  }
  var reviewss = $("#reviewss").val();
   var bussid = $("#bussid").val();
   if(rateing == "" || rateing == undefined)
	{
		alert("Please Enter Your Rating");
		rating.focus();
		return false;
	}
	if(reviewss == "")
	{
		alert("Please Enter Your Review");
		review.focus();
		return false;
	}
   	var dataString = 'reviewss='+ reviewss+'&rateing='+ rateing+'&bussid='+ bussid+'&type='+ type;
   //	alert(dataString)
   $.ajax
		({
		type: "POST",
		url: "ajax_bussreviews.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
	//	alert(data)
		if(data!=""){
		alert("Your feedback details have been saved"); 
		document.location.href='student_timetable?page=completed&my='+data;
		}else {
		alert("Something went wrong please try again");
		document.getElementById("close-modal").click();
		}
		}
			});
  }



                
                $("#bookingSearch").click(()=>{
                    let searchDate = "Yes"
                    if(searchDate==="" || searchDate===null || searchDate===undefined) {
                        $.alert({
                           type:"red",
                           title:false,
                           content : "Please select date."
                        });
                    } else {
                        var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
                        $.ajax({
                            type: "post",
                            data: "mybookingthis&searchDate="+searchDate,
                            beforeSend() {
                               // b.show();
                            },
                            success(e) {
                                $("body").removeAttr("style"), $("#BookingsDisp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
                            },
                    });
                    }
                });
                $("#cancelSearch").click(()=>{
                     let searchDate = "Yes"
                    if(searchDate==="" || searchDate===null || searchDate===undefined) {
                        $.alert({
                           type:"red",
                           title:false,
                           content : "Please select date."
                        });
                    } else {
                        var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
                        $.ajax({
                            type: "post",
                            data: "bookingsCanceled&searchDate="+searchDate,
                            beforeSend() {
                               // b.show();
                            },
                            success(e) {
                                $("body").removeAttr("style"), $("#CancelDisp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
                            },
                    });
                    }
                });
                $("#compltedSearch").click(()=>{
                     let searchDate = "Yes"
                    if(searchDate==="" || searchDate===null || searchDate===undefined) {
                        $.alert({
                           type:"red",
                           title:false,
                           content : "Please select date."
                        });
                    } else {
                        var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
                        $.ajax({
                            type: "post",
                            data: "lessioncompleted&searchDate="+searchDate,
                            beforeSend() {
                               // b.show();
                            },
                            success(e) {
                                $("body").removeAttr("style"), $("#completedDisp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
                            },
                    });
                    }
                });
                $("#reportedSearch").click(()=>{
                     let searchDate = "Yes"
                    if(searchDate==="" || searchDate===null || searchDate===undefined) {
                        $.alert({
                           type:"red",
                           title:false,
                           content : "Please select date."
                        });
                    } else {
                        var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
                        $.ajax({
                            type: "post",
                            data: "reportedLession&searchDate="+searchDate,
                            beforeSend() {
                               // b.show();
                            },
                            success(e) {
                                $("body").removeAttr("style"), $("#reportedDesp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
                            },
                    });
                    }
                });
                
                
                
            var myModal = new bootstrap.Modal(document.getElementById("contentModal"), { keyboard: !1 });
            function chatShow(a) {
                $.ajax({
                    type: "post",
                    url: "./buzz_chat_internal.php",
                    data: { chatPopUp: "", UID: a },
                    beforeSend: function () {
                        myModal.show();
                    },
                    success: function (a) {
                        if ("" !== a && null != a) {
                            $("#contentDiv").html(a);
                            let b = document.getElementById("chatmsgsCont");
                            b.scrollTop = b.scrollHeight;
                        } else $("#contentDiv").html("<h5>Opps! Somthing went wrong.</h5>");
                    },
                });
            }
            function sendMessage(b) {
                var a = $("#idevChatInp").val().trim();
                a.length < 1
                    ? ($("#idevChatInp").focus(), $.alert({ type: "orange", title: !1, content: "Please enter message" }))
                    : a.length > 300
                    ? ($("#idevChatInp").focus(), $.alert({ type: "orange", title: !1, content: "you are not allowed to enter more then 300 characters" }))
                    : $.ajax({
                          type: "post",
                          url: "./buzz_chat_internal.php",
                          dataType: "JSON",
                          data: { sendMsg: "", gid: b, msg: a },
                          beforeSend: function () {
                              $("#sendMsgButton").prop("disabled", !0), $("#sendMsgButton").html("Sendnig <i class='mdi mdi-spin mdi-loading'></i>");
                          },
                          success: function (a) {
                              if (1 == a.save) {
                                  $("#idevChatInp").val(""),
                                      $("#idevChatInp").focus(),
                                      $("#sendMsgButton").prop("disabled", !1),
                                      $("#sendMsgButton").html("Send Message"),
                                      $("#chatmsgsCont").html(a.html),
                                      a.totalMsgs >= 50 &&
                                          $("#sbtn").html(`<div class="alert bg-soft-danger fw-medium" role="alert"><i class="uil uil-exclamation-octagon fs-5 align-middle me-1"></i> Hey, sorry you’ve reached your
                                                                    maximum number of messages in this channel and won’t
                                                                    be able to send any more</div>`);
                                  let b = document.getElementById("chatmsgsCont");
                                  b.scrollTop = b.scrollHeight;
                              } else {
                                  $("#sendMsgButton").prop("disabled", !1), $("#sendMsgButton").html("Send Message"), $.alert({ type: "orange", title: !1, content: "Message not sent. Somthing went wrong!" });
                                  let c = document.getElementById("chatmsgsCont");
                                  c.scrollTop = c.scrollHeight;
                              }
                          },
                      });
            }
            $(".btn-close").click(() => {
                $("#contentDiv").html('<h5>Loading your chat , please wait <i class="mdi mdi-spin mdi-loading"></i></h5>'), myModal.hide();
            });

                
        </script>
    </body>

</html>
<?php mysqli_close($tutor_db);?>