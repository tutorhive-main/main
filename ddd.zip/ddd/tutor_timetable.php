<?php
    error_reporting(0);
    ob_start();
    ini_set('session.gc_maxlifetime', '28800');
    session_start();
    if( !isset($_SESSION['username_name']) || $_SESSION['verifhive']== "No" || $_SESSION['admin_type'] !== "Tutor")
     {
       header("Location: login");
     }
     
     $userId = $_SESSION['tutor_admin_id'];
    
    include_once("common/connection.php");
    $tutor_time = date('H:i'); 
    $tutor_date122 = date('Y-m');
	
    $data34 = [
    'TUTORNOTSTATUS' => 1,
	'TH_RECEIVER' => $userId,
	'checknot' => 0,
];
$sqlupdate134 = "UPDATE tutor_hive_sendbuzz SET TUTORNOTSTATUS=:TUTORNOTSTATUS WHERE TH_RECEIVER=:TH_RECEIVER AND TUTORNOTSTATUS=:checknot";
$stmtuodate134= $tutor_db->prepare($sqlupdate134);
$stmtuodate134->execute($data34);


if(isset($_POST['submitlink'])){ 
 $linkid=$_POST['bussiddd'];
 $meetlink=$_POST['meeetinglink'];

 $data333 = [
    'MEETING_LINK' => $meetlink,
	'TH_BUZZ_ID' => $linkid,
];
$sqlupdate1333 = "UPDATE tutor_hive_sendbuzz SET MEETING_LINK=:MEETING_LINK WHERE TH_BUZZ_ID=:TH_BUZZ_ID";
$stmtuodate1333= $tutor_db->prepare($sqlupdate1333);
$stmtuodate1333->execute($data333);
}
 if(isset($_POST['requestthis'])){ 
 $pagination_fetch111 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_BOOKED_STATUS!=1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 AND TH_BUZZ_MONTHS>='$tutor_date122' ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");	
$totalMonths1 = $pagination_fetch111->fetch();				
	
        $pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_BOOKED_STATUS!=1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetchAll(PDO::FETCH_ASSOC);
    if($_GET['page']=="request" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
   } else if ($totalMonths1['TH_BUZZ_MONTHS']!=""){
 $selMonth =$totalMonths1['TH_BUZZ_MONTHS'];
  }else {
  $selMonth =$totalMonths[0]['TH_BUZZ_MONTHS'];
  }
       
        $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
										a.TH_BUZZ_MONTHS,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.TH_BUZZ_ID,
                                        a.TH_ISPRICE_PAY,
										a.TH_BOOKED_STATUS,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_RECEIVER,
										a.TH_SENDER,
										a.TH_AGENDA,
										a.GROUP_ID,
										a.SB_SSID,
										a.MEETING_LINK,
										a.START_URL
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_SENDER = b.USER_ID
                                    WHERE
                                        a.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth' AND a.TH_STATUS = 1 AND a.TH_BOOKED_STATUS!=1 AND  a.TH_TUTOR_CANCEL_STATUS!=1 AND a.TH_TUTOR_COMPLETED_STATUS!=1 AND a.TH_STUDENT_CANCEL_STATUS!=1 AND a.TH_STUDENT_COMPLETED_STATUS!=1 AND a.TH_REJECT_STATUS!=1 AND a.UNPAID_CANCELLED!=1 GROUP BY a.GROUP_ID ORDER BY a.TH_BUZZ_DATE,a.TH_BUZZ_START_TIME ASC");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
 ?>  
 <div style="text-align:center;">
                                        <?php
                                            if((int)$total_rows>0) {
                                            $col=9;
                                           
                                            foreach($totalMonths as $tm) {
                                        ?>
                                            <a href="?page=request&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primary"<?php }else { ?> class="btn btn-primary" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
<div class="col-12 mt-3  card border-0 fade show active p-3 rounded shadow">
  <?php 
								 $i=1;
								
								 foreach ($fetchBokkingData as $fdb) { 
								  if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
								  $groupMyquery = $tutor_db->query("SELECT u.FIRST_NAME,u.LAST_NAME,s.TH_BOOKED_STATUS,s.PAYMENT_STATUS,s.TH_BUZZ_ID,s.TH_SENDER FROM tutor_hive_sendbuzz s INNER JOIN tutorhive_users u ON s.TH_SENDER = u.USER_ID WHERE s.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND s.SB_SSID=".$fdb['SB_SSID']." AND s.TH_BOOKED_STATUS=0 AND s.TH_REJECT_STATUS=0 AND s.TH_TUTOR_CANCEL_STATUS=0 AND s.TH_STUDENT_CANCEL_STATUS=0 AND s.UNPAID_CANCELLED=0 AND s.TH_TUTOR_COMPLETED_STATUS=0 AND s.TH_STUDENT_COMPLETED_STATUS=0");
$countofnog =0;								  
$countofnog = $groupMyquery->rowCount();
}?>
<ul class="nav nav-pills shadow flex-column flex-sm-row d-md-inline-flex mb-0 p-1 bg-white-color rounded position-relative overflow-hidden" style="border:1px solid #ebe8e8">
    <li class="py-2 active rounded d-lg-block d-md-none d-none">
                                            <div class="text-center">
                                                <img src="assets/images/hex.PNG" style="width:30%">
                                            </div>
                                    </li>
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>Group Lessons<?php }else {?>1:1 Lessons <?php } ?> <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){ echo "Intro Call - FREE"; }else {?> - £<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".",""); }?> </h5>
                                            </div>
                                    </li><!--end nav item-->
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php echo $fdb['TH_BUZZ_SUBJECT']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                    
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center" style="float:right;">
                                                <h5 class="mb-0"><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?> <?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                </ul>
<div class="ht" >
 <?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){
  if((int)$countofnog>0){
 $groupdetailsfch = $groupMyquery->fetchAll(PDO::FETCH_ASSOC);
  foreach ($groupdetailsfch as $gdf) { ?>
<div class="row">
<div class="col-2"><a href="#" onClick="MoreDetails(<?php echo $gdf['TH_BUZZ_ID'] ?>)"  alt="More Details" title="More Details" class="btn btn-sm btn-primary" style="border-radius:50%; padding:0px 5px;"><i class="mdi mdi-account" style="font-size:20px;"></i></a></div>
<div class="col-3"><p><?php echo $gdf['FIRST_NAME']." ".$gdf['LAST_NAME']; ?></p></div>
<div class="col-1">
<a href="" alt="message" title="message" class="btn btn-sm btn-primary" style="padding:0px 5px;font-size: 20px;border-radius: 50%;"><i class="mdi mdi-email" ></i></a>
</div>
<div class="col-2"></div>
<div class="col-4"><a onClick="acceptBuss(<?php echo $gdf['TH_BUZZ_ID'] ?>)" alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Accept</a>
<a onClick="rejectBuss(<?php echo $gdf['TH_BUZZ_ID'] ?>)" alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Reject</a></div>
</div>
<?php } }}else { ?>
<div class="row">
<div class="col-2"><a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)"  alt="More Details" title="More Details" class="btn btn-sm btn-primary" style="border-radius:50%; padding:0px 5px;"><i class="mdi mdi-account" style="font-size:20px;"></i></a></div>
<div class="col-3"><p><?php echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME']; ?></p></div>
<div class="col-1"><?php $gid = $fdb['GROUP_ID'];
						        $chatCount = $tutor_db->query("SELECT COUNT(`GROUP_ID`) as chatcount FROM `buzz_chat_internal` WHERE `GROUP_ID`='$gid'")->fetch(PDO::FETCH_ASSOC);
						
						?>
						<a style="position : relative ;" href="#" onClick="chatShow('<?php echo $fdb['TH_BUZZ_ID'] ?>')" class="text-success">
						    <img src="assets/images/chatd.png"  alt="Chat" title="Chat" class="intimetabl" /> 
						    <span style="font-size: 12px;padding: 1px 5px;border-radius: 50%;background: #000;position: absolute;right: 0;"><?php echo $chatCount['chatcount'] ?></span>
						    </a></div>
<div class="col-2"></div>
<div class="col-4"><a onClick="acceptBuss(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Accept</a>
<a onClick="rejectBuss(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Reject</a></div>
</div>
<?php } ?>
</div>
<?php } ?>
</div>
<?php } else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Request lessons</h4>
          </div>
<?php } exit;} 

if(isset($_POST['mybookingthis'])){ 
 $pagination_fetch111 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_BOOKED_STATUS=1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 AND TH_BUZZ_MONTHS>='$tutor_date122' ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");	
$totalMonths1 = $pagination_fetch111->fetch();				
	
        $pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_BOOKED_STATUS=1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetchAll(PDO::FETCH_ASSOC);
    if($_GET['page']=="booked" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
   } else if ($totalMonths1['TH_BUZZ_MONTHS']!=""){
 $selMonth =$totalMonths1['TH_BUZZ_MONTHS'];
  }else {
  $selMonth =$totalMonths[0]['TH_BUZZ_MONTHS'];
  }
       
        $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
										a.TH_BUZZ_MONTHS,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.TH_BUZZ_ID,
                                        a.TH_ISPRICE_PAY,
										a.TH_BOOKED_STATUS,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_RECEIVER,
										a.TH_SENDER,
										a.TH_AGENDA,
										a.GROUP_ID,
										a.SB_SSID,
										a.MEETING_LINK,
										a.START_URL
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_SENDER = b.USER_ID
                                    WHERE
                                        a.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth' AND a.TH_STATUS = 1 AND a.TH_BOOKED_STATUS=1 AND a.TH_TUTOR_CANCEL_STATUS!=1 AND a.TH_TUTOR_COMPLETED_STATUS!=1 AND a.TH_STUDENT_CANCEL_STATUS!=1 AND a.TH_STUDENT_COMPLETED_STATUS!=1 AND a.TH_REJECT_STATUS!=1 AND a.UNPAID_CANCELLED!=1 GROUP BY a.GROUP_ID ORDER BY a.TH_BUZZ_DATE,a.TH_BUZZ_START_TIME ASC");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
 ?>  
 <div style="text-align:center;">
                                        <?php
                                            if((int)$total_rows>0) {
                                            $col=9;
                                           
                                            foreach($totalMonths as $tm) {
                                        ?>
                                            <a href="?page=booked&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primary"<?php }else { ?> class="btn btn-primary" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
<div class="col-12 mt-3  card border-0 fade show active p-3 rounded shadow">
  <?php 
								 $i=1;
								
								 foreach ($fetchBokkingData as $fdb) { 
								  if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){
								   $countofnog=0;
								  $paysucc=0;
								  $payfail=0;
								 $groupstname=""; 
								  $groupMyquery = $tutor_db->query("SELECT u.FIRST_NAME,u.LAST_NAME,s.TH_BOOKED_STATUS,s.PAYMENT_STATUS,s.TH_BUZZ_ID,s.TH_SENDER FROM tutor_hive_sendbuzz s INNER JOIN tutorhive_users u ON s.TH_SENDER = u.USER_ID WHERE s.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND s.SB_SSID=".$fdb['SB_SSID']." AND s.TH_BOOKED_STATUS=1 AND s.TH_REJECT_STATUS=0 AND s.TH_TUTOR_CANCEL_STATUS=0 AND s.TH_STUDENT_CANCEL_STATUS=0 AND s.UNPAID_CANCELLED=0 AND s.TH_TUTOR_COMPLETED_STATUS=0 AND s.TH_STUDENT_COMPLETED_STATUS=0");
$countofnog = $groupMyquery->rowCount();
								if($countofnog > 0) {
                                 $groupdetailsfch = $groupMyquery->fetchAll(PDO::FETCH_ASSOC);
								  foreach ($groupdetailsfch as $gdf) { 
								   $groupstname.=$gdf['FIRST_NAME']." ".$gdf['LAST_NAME']."<br>";
								   if($gdf['PAYMENT_STATUS']==1){
								   $paysucc++;
								   }else {
								   $payfail++;
								   }
									}
									$ttt=rtrim($groupstname, ', ');
									}
								  }
?>

<ul class="nav nav-pills shadow flex-column flex-sm-row d-md-inline-flex mb-0 p-1 bg-white-color rounded position-relative overflow-hidden" style="border:1px solid #ebe8e8">
    <li class="py-2 active rounded">
                                            <div class="text-center">
                                                <img src="assets/images/hex.PNG" style="width:30%">
                                            </div>
                                    </li>
                                     <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>Group <?php echo $countofnog; ?>/6 <?php }else {?>1:1 Lessons <?php }  if($fdb['TH_TUTOR_METHOD']=="Intro Call"){ echo "Intro Call - FREE"; }else {?> - £<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".",""); }?> </h5>
                                            </div>
                                    </li><!--end nav item-->
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php echo $fdb['TH_BUZZ_SUBJECT']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                    
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center" style="float:right;">
                                                <h5 class="mb-0"><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?> <?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                </ul>
<div class=""  style="padding: 20px 0px 20px 0px !important;">
<div class="row">
<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<span style="color: #15b815;font-weight: 700;"><?php echo $paysucc; ?> Paid</span><br>
<span style="color: #fd440d;font-weight: 700;"><?php echo $payfail; ?> Unpaid</span>
<?php }else { 
 if($fdb['PAYMENT_STATUS']==1){?>
 <span style="color: #15b815;font-weight: 700;">Paid</span>
 <?php }else { ?>
 <span style="color: #fd440d;font-weight: 700;">Unpaid</span>
<?php }} ?>
</div>
<div class="col-lg-3" >
<p><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){echo $ttt; }else { echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME'];} ?></p>
</div>

<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Edit Agenda</a><?php } else { echo "No Agenda";} ?>
</div>

<div class="col-lg-3" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){
$groupMyquery12 = $tutor_db->query("SELECT START_URL FROM tutor_hive_sendbuzz  WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND SB_SSID=".$fdb['SB_SSID']." AND TH_BOOKED_STATUS=1 AND TH_REJECT_STATUS=0 AND TH_TUTOR_CANCEL_STATUS=0 AND TH_STUDENT_CANCEL_STATUS=0 AND UNPAID_CANCELLED=0 AND TH_TUTOR_COMPLETED_STATUS=0 AND TH_STUDENT_COMPLETED_STATUS=0 AND PAYMENT_STATUS=1 AND START_URL!=''");
$groupmeetcount = $groupMyquery12->rowCount();
$groupfech = $groupMyquery12->fetch();
if($groupmeetcount>0){
?>
<?php if($tutor_date1==$fdb['TH_BUZZ_DATE'] && $tutor_time>="08:00" && $fdb['TH_BUZZ_END_TIME']>$tutor_time){?>
<?php if ($fdb['TH_BUZZ_DATE'] == $tutor_date1 && $tutor_time >= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -15 minutes"))){ ?>
<a href="<?php echo $groupfech['START_URL']; ?>" target="_blank" alt="Join Now" title="Join Now" class="btn btn-soft-primary" style="padding: 2px 14px;">Join Now</a> 
<?php }else {?>
<a href="<?php echo $groupfech['START_URL']; ?>" target="_blank" alt="Meeting Link" title="Meeting Link" class="btn btn-soft-primary" style="padding: 2px 14px;">Meeting Link</a> 
<?php } } }?>
<a href="viewgroup_tutordel1.php?uiddu=<?php echo $fdb['SB_SSID']; ?>&mymm=<?php echo $fdb['TH_BUZZ_MONTHS']; ?>"  alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;margin-left: 6px;">View group details</a>
<?php }else {?>
<?php if($fdb['PAYMENT_STATUS']==1 && $fdb['TH_BOOKED_STATUS']==1){
if($fdb['TH_TUTOR_METHOD']=="Online" || $fdb['TH_TUTOR_METHOD']=="Intro Call"){  ?>
<?php if($tutor_date1==$fdb['TH_BUZZ_DATE'] && $tutor_time>="08:00" && $fdb['TH_BUZZ_END_TIME']>$tutor_time){?>
<?php if ($fdb['TH_BUZZ_DATE'] == $tutor_date1 && $tutor_time >= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -15 minutes"))){ ?>
<a href="<?php echo $fdb['START_URL']; ?>" target="_blank" alt="Join Now" title="Join Now" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;">Join Now</a> 
<?php }else {?>
<a href="<?php echo $fdb['START_URL']; ?>" target="_blank" alt="Meeting Link" title="Meeting Link" class="btn btn-soft-primary ms-2" style="padding: 2px 14px;">Meeting Link</a> 
<?php }}}else { echo "In-person";}
  if ($fdb['TH_BUZZ_DATE'] < $tutor_date1 && $fdb['PAYMENT_STATUS']==1 && $fdb['TH_BOOKED_STATUS']==1){ echo "Completed"; }else if ($tutor_time > date('H:i', strtotime($fdb['TH_BUZZ_END_TIME']))  && $fdb['TH_BUZZ_DATE']== $tutor_date1 && $fdb['PAYMENT_STATUS']==1 && $fdb['TH_BOOKED_STATUS']==1){ echo "Completed"; } else {echo "Confirmed";}
} else { echo "Payment Pending"; } ?>
<?php } ?>
</div>

<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<a href="" alt="message" title="message" class="btn btn-sm btn-primary" style="padding:0px 5px;font-size: 20px;border-radius: 50%;"><i class="mdi mdi-email" ></i></a>
<?php }else { ?>
<a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)"  alt="More Details" title="More Details" class="btn btn-sm btn-primary" style="border-radius:50%; padding:0px 5px;"><i class="mdi mdi-account" style="font-size:20px;"></i></a>
<?php $gid = $fdb['GROUP_ID'];
						        $chatCount = $tutor_db->query("SELECT COUNT(`GROUP_ID`) as chatcount FROM `buzz_chat_internal` WHERE `GROUP_ID`='$gid'")->fetch(PDO::FETCH_ASSOC);
						
						?>
						<a style="position : relative ;" href="#" onClick="chatShow('<?php echo $fdb['TH_BUZZ_ID'] ?>')" class="text-success">
						    <img src="assets/images/chatd.png"  alt="Chat" title="Chat" class="intimetabl" /> 
						    <span style="font-size: 12px;padding: 1px 5px;border-radius: 50%;background: #000;position: absolute;right: 0;"><?php echo $chatCount['chatcount'] ?></span>
						    </a>
<?php if ($fdb['TH_BUZZ_DATE']> $tutor_date1){?>
						<a href="#" onClick="delclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Cancel" title="Cancel" class="text-danger"><img src="assets/images/icons-cancel.svg" class="intimetabl" /></a>
						 <?php }else if($fdb['TH_BUZZ_DATE']== $tutor_date1 && $tutor_time <= date('H:i', strtotime($fdb['TH_BUZZ_START_TIME'] . " -1 hours"))){  ?>
						<a href="#" onClick="delclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Cancel" title="Cancel" class="text-danger"><img src="assets/images/icons-cancel.svg" class="intimetabl" /></a>
						<?php } ?>
						<?php  if ($fdb['TH_BUZZ_DATE'] < $tutor_date1 && $fdb['PAYMENT_STATUS']==1 && $fdb['TH_BOOKED_STATUS']==1){ ?>
						<a href="#" onClick="Compclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Complete" title="Complete" class="text-success"><img src="assets/images/icons-completed.svg" class="intimetabl" /></a>
						<?php }else if ($tutor_time > date('H:i', strtotime($fdb['TH_BUZZ_END_TIME']))  && $fdb['TH_BUZZ_DATE']== $tutor_date1 && $fdb['PAYMENT_STATUS']==1 && $fdb['TH_BOOKED_STATUS']==1){ ?>
						<a href="#" onClick="Compclass(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="Complete" title="Complete" class="text-success"><img src="assets/images/icons-completed.svg" class="intimetabl" /></a>
						<?php } } ?>
</div>
</div>
</div>
<?php } ?>
</div>
<?php } else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Booked lessons</h4>
          </div>
<?php } exit;}

if(isset($_POST['bookingsCanceled'])){ 
$pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND (TH_TUTOR_CANCEL_STATUS = 1 OR TH_STUDENT_CANCEL_STATUS=1 OR UNPAID_CANCELLED=1) ORDER BY TH_BUZZ_DATE DESC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetch();
     if($_GET['page']=="canceled" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
  }else {
  $selMonth =$totalMonths['TH_BUZZ_MONTHS'];
  }
       
        $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
										a.TH_BUZZ_MONTHS,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.PAYMENT_STATUS,
                                        a.TH_ISPRICE_PAY,
										a.TH_BUZZ_REGDATE,
										a.TH_TUTOR_CANCEL_STATUS,
										a.TH_STUDENT_CANCEL_STATUS,
										a.TH_BUZZ_ID,
										a.SB_SSID,
										a.TH_AGENDA,
										a.UNPAID_CANCELLED
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_SENDER = b.USER_ID
                                    WHERE
                                        a.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth' AND (a.`TH_TUTOR_CANCEL_STATUS` = 1 OR a.TH_STUDENT_CANCEL_STATUS=1 OR a.UNPAID_CANCELLED=1) GROUP BY a.GROUP_ID ORDER BY a.TH_BUZZ_DATE ASC");
        $bokingsCount = $prepMyquery->rowCount();
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
    ?>
 <div style="text-align:center;">
                                       <?php
										
										
                                            if((int)$total_rows>0) {
											 $pagination_fetch1 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND (TH_TUTOR_CANCEL_STATUS = 1 OR TH_STUDENT_CANCEL_STATUS=1 OR UNPAID_CANCELLED=1) ORDER BY TH_BUZZ_DATE ASC");
											  $totalMonths1 = $pagination_fetch1->fetchAll(PDO::FETCH_ASSOC);
                                            $col=9;
                                           
                                            foreach($totalMonths1 as $tm) {
											
                                        ?>
										
                                            <a href="?page=canceled&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primary"<?php }else { ?> class="btn btn-primary" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
<div class="col-12 mt-3  card border-0 fade show active p-3 rounded shadow">
<?php  $i=1;
								 foreach ($fetchBokkingData as $fdb) { 
								  if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
								  $countofnog=0;
								  $paysucc=0;
								  $payfail=0;
								 $groupstname="";
								  $groupMyquery = $tutor_db->query("SELECT u.FIRST_NAME,u.LAST_NAME,s.TH_BOOKED_STATUS,s.PAYMENT_STATUS FROM tutor_hive_sendbuzz s INNER JOIN tutorhive_users u ON s.TH_SENDER = u.USER_ID WHERE s.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND s.SB_SSID=".$fdb['SB_SSID']." AND (s.TH_TUTOR_CANCEL_STATUS=1 OR s.TH_STUDENT_CANCEL_STATUS=1 OR s.UNPAID_CANCELLED=1)");
								$countofnog = $groupMyquery->rowCount();
								if($countofnog > 0) {
                                 $groupdetailsfch = $groupMyquery->fetchAll(PDO::FETCH_ASSOC);
								  foreach ($groupdetailsfch as $gdf) { 
								   $groupstname.=$gdf['FIRST_NAME']." ".$gdf['LAST_NAME']."<br>";
								   if($gdf['PAYMENT_STATUS']==1){
								   $paysucc++;
								   }else {
								   $payfail++;
								   }
									}
									$ttt=rtrim($groupstname, ', ');
									}
								  }
								 ?>
								 <ul class="nav nav-pills shadow flex-column flex-sm-row d-md-inline-flex mb-0 p-1 bg-white-color rounded position-relative overflow-hidden" style="border:1px solid #ebe8e8">
    <li class="py-2 active rounded">
                                            <div class="text-center">
                                                <img src="assets/images/hex.PNG" style="width:30%">
                                            </div>
                                    </li>
                                     <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>Group <?php echo $countofnog; ?>/6 <?php }else {?>1:1 Lessons <?php }  if($fdb['TH_TUTOR_METHOD']=="Intro Call"){ echo "Intro Call - FREE"; }else {?> - £<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".",""); }?> </h5>
                                            </div>
                                    </li><!--end nav item-->
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php echo $fdb['TH_BUZZ_SUBJECT']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                    
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center" style="float:right;">
                                                <h5 class="mb-0"><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?> <?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                </ul>
								<div class=""  style="padding: 20px 0px 20px 0px !important;">
<div class="row">
<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<a href="viewgroup_tutorcancel1.php?uiddu=<?php echo $fdb['SB_SSID']; ?>&mymm=<?php echo $fdb['TH_BUZZ_MONTHS']; ?>" alt="Details" title="Details" class="btn btn-sm btn-primary" style="padding:0px 5px;font-size: 20px;border-radius: 50%;"><i class="mdi mdi-more" style="font-size:20px;"></i></a>
<?php }else { ?>
<a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)"  alt="More Details" title="More Details" class="btn btn-sm btn-primary" style="border-radius:50%; padding:0px 5px;"><i class="mdi mdi-account" style="font-size:20px;"></i></a>
<!--<a style="position : relative ;" href="messaged.php?ftimeid=<?php echo $fdb['TH_SENDER'] ?>"class="text-success"><img src="assets/images/chatd.png" alt="Chat" title="Chat" class="intimetabl"> </a>-->
<?php } ?>
</div>
<div class="col-lg-3" >
<p><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){echo $ttt; }else { echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME'];} ?></p>
</div>

<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail1(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Agenda</a><?php } else { echo "No Agenda";} ?>
</div>

<div class="col-lg-3" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<a href="viewgroup_tutorcancel1.php?uiddu=<?php echo $fdb['SB_SSID']; ?>&mymm=<?php echo $fdb['TH_BUZZ_MONTHS']; ?>"  alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;margin-left: 6px;">View group details</a>
<?php }else {?>
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ echo "-"; }else{?><?php if($fdb['TH_TUTOR_CANCEL_STATUS']==1){ echo "Cancelled By TUTOR";} else if($fdb['TH_STUDENT_CANCEL_STATUS']==1) { echo "Cancelled By STUDENT"; }else if ($fdb['UNPAID_CANCELLED']==1){ echo "Cancelled By Un-Paid";} }?>
<?php } ?>
</div>
<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<span style="color: #15b815;font-weight: 700;"><?php echo $paysucc; ?> Paid</span><br>
<span style="color: #fd440d;font-weight: 700;"><?php echo $payfail; ?> Unpaid</span>
<?php }else { 
 if($fdb['PAYMENT_STATUS']==1){?>
 <span style="color: #15b815;font-weight: 700;">Paid</span>
 <?php }else { ?>
 <span style="color: #fd440d;font-weight: 700;">Unpaid</span>
<?php }} ?>
</div>
</div>
</div>
<?php } ?>
</div>
<?php } else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Canceled lessons</h4>
          </div>
<?php } exit;} 

 if(isset($_POST['lessioncompleted'])){
 
 $pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND (TH_TUTOR_COMPLETED_STATUS = 1 OR TH_STUDENT_COMPLETED_STATUS=1) ORDER BY TH_BUZZ_DATE DESC ");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetch();
     if($_GET['page']=="completed" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
  }else {
  $selMonth =$totalMonths['TH_BUZZ_MONTHS'];
  }
	
        $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
										a.TH_BUZZ_MONTHS,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.PAYMENT_STATUS,
                                        a.TH_ISPRICE_PAY,
										a.TH_BUZZ_REGDATE,
									    a.TH_BUZZ_ID,
										a.TH_AGENDA,
										a.SB_SSID,
										a.STUDENT_RATING,
										a.STUDENT_REVIEW,
										a.TH_TUTOR_PDF,
										a.PDF_PASSWORD
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_SENDER = b.USER_ID
                                    WHERE
                                        a.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth'  AND (a.`TH_TUTOR_COMPLETED_STATUS` = 1 OR a.TH_STUDENT_COMPLETED_STATUS=1) GROUP BY a.GROUP_ID ORDER BY a.TH_BUZZ_DATE ASC ");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);?>
		<div style="text-align:center;">
                                        <?php
                                            if((int)$total_rows>0) {
											 $pagination_fetch1 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND (TH_TUTOR_COMPLETED_STATUS = 1 OR TH_STUDENT_COMPLETED_STATUS=1) ORDER BY TH_BUZZ_DATE ASC ");
											 $totalMonths1 = $pagination_fetch1->fetchAll(PDO::FETCH_ASSOC);
                                            $col=9;
                                           
                                            foreach($totalMonths1 as $tm) {
                                        ?>
                                            <a href="?page=completed&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primary"<?php }else { ?> class="btn btn-primary" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
<div class="col-12 mt-3  card border-0 fade show active p-3 rounded shadow">
 <?php 
								 $i=1;
								 foreach ($fetchBokkingData as $fdb) { 
								  if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
								  $countofnog=0;
								   $paysucc=0;
								  $payfail=0;
								 $groupstname="";
								  $groupMyquery = $tutor_db->query("SELECT u.FIRST_NAME,u.LAST_NAME,s.TH_BOOKED_STATUS,s.PAYMENT_STATUS FROM tutor_hive_sendbuzz s INNER JOIN tutorhive_users u ON s.TH_SENDER = u.USER_ID WHERE s.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND s.SB_SSID=".$fdb['SB_SSID']." AND (s.TH_TUTOR_COMPLETED_STATUS=1 OR s.TH_STUDENT_COMPLETED_STATUS=1)");
								$countofnog = $groupMyquery->rowCount();
								if($countofnog > 0) {
                                 $groupdetailsfch = $groupMyquery->fetchAll(PDO::FETCH_ASSOC);
								  foreach ($groupdetailsfch as $gdf) { 
								   $groupstname.=$gdf['FIRST_NAME']." ".$gdf['LAST_NAME']."<br>";
								    if($gdf['PAYMENT_STATUS']==1){
								   $paysucc++;
								   }else {
								   $payfail++;
								   }
									}
									$ttt=rtrim($groupstname, ', ');
									}
								  }
								 ?>
								 <ul class="nav nav-pills shadow flex-column flex-sm-row d-md-inline-flex mb-0 p-1 bg-white-color rounded position-relative overflow-hidden" style="border:1px solid #ebe8e8">
    <li class="py-2 active rounded">
                                            <div class="text-center">
                                                <img src="assets/images/hex.PNG" style="width:30%">
                                            </div>
                                    </li>
                                     <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>Group <?php echo $countofnog; ?>/6 <?php }else {?>1:1 Lessons <?php }  if($fdb['TH_TUTOR_METHOD']=="Intro Call"){ echo "Intro Call - FREE"; }else {?> - £<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".",""); }?> </h5>
                                            </div>
                                    </li><!--end nav item-->
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php echo $fdb['TH_BUZZ_SUBJECT']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                    
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center" style="float:right;">
                                                <h5 class="mb-0"><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?> <?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                </ul>
								
								<div class=""  style="padding: 20px 0px 20px 0px !important;">
<div class="row">
<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<a href="viewgroup_tutorcomplete1.php?uiddu=<?php echo $fdb['SB_SSID']; ?>&mymm=<?php echo $fdb['TH_BUZZ_MONTHS']; ?>" alt="Details" title="Details" class="btn btn-sm btn-primary" style="padding:0px 5px;font-size: 20px;border-radius: 50%;"><i class="mdi mdi-more" style="font-size:20px;"></i></a>
<?php }else { ?>
<a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)"  alt="More Details" title="More Details" class="btn btn-sm btn-primary" style="border-radius:50%; padding:0px 5px;"><i class="mdi mdi-account" style="font-size:20px;"></i></a>
<!--<a style="position : relative ;" href="messaged.php?ftimeid=<?php echo $fdb['TH_SENDER'] ?>"class="text-success"><img src="assets/images/chatd.png" alt="Chat" title="Chat" class="intimetabl"> </a>-->
<?php } ?>
</div>
<div class="col-lg-3" >
<p><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){echo $ttt; }else { echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME'];} ?></p>
</div>

<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail1(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Agenda</a><?php } else { echo "No Agenda";} ?>
</div>

<div class="col-lg-3" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<a href="viewgroup_tutorcomplete1.php?uiddu=<?php echo $fdb['SB_SSID']; ?>&mymm=<?php echo $fdb['TH_BUZZ_MONTHS']; ?>"  alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;margin-left: 6px;">View group details</a>
<?php }else {?>
Completed
<?php } ?>
</div>
<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<span style="color: #15b815;font-weight: 700;"><?php echo $paysucc; ?> Paid</span><br>
<span style="color: #fd440d;font-weight: 700;"><?php echo $payfail; ?> Unpaid</span>
<?php }else { 
 if($fdb['PAYMENT_STATUS']==1){?>
 <span style="color: #15b815;font-weight: 700;">Paid</span>
 <?php }else { ?>
 <span style="color: #fd440d;font-weight: 700;">Unpaid</span>
<?php }} ?>
</div>
</div>
</div>
<?php } ?>
</div>
<?php } else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Completed lessons</h4>
          </div>
<?php } exit;} 

  if(isset($_POST['reportedLession'])){
       $pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS=1 ORDER BY TH_BUZZ_DATE DESC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetch();
     if($_GET['page']=="reported" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
  }else {
  $selMonth =$totalMonths['TH_BUZZ_MONTHS'];
  }
	
	 $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
										a.TH_BUZZ_MONTHS,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.TH_BUZZ_ID,
                                        a.TH_ISPRICE_PAY,
										a.TH_BOOKED_STATUS,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_REJECT_STATUS,
										a.SB_SSID,
										a.TH_AGENDA
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_SENDER = b.USER_ID
                                    WHERE
                                        a.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth' AND a.TH_STATUS = 1 AND a.TH_TUTOR_CANCEL_STATUS!=1 AND a.TH_TUTOR_COMPLETED_STATUS!=1 AND a.TH_STUDENT_CANCEL_STATUS!=1 AND a.TH_STUDENT_COMPLETED_STATUS!=1 AND  a.TH_REJECT_STATUS=1 GROUP BY a.GROUP_ID ORDER BY a.TH_BUZZ_DATE ASC");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC); ?>
		<div style="text-align:center;">
                                        <?php
                                            if((int)$total_rows>0) {
											 $pagination_fetch1 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS=1 ORDER BY TH_BUZZ_DATE ASC");
											  $totalMonths1 = $pagination_fetch1->fetchAll(PDO::FETCH_ASSOC);
                                            $col=9;
                                           
                                            foreach($totalMonths1 as $tm) {
                                        ?>
                                           <a href="?page=reported&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primary"<?php }else { ?> class="btn btn-primary" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
<div class="col-12 mt-3  card border-0 fade show active p-3 rounded shadow">
 <?php 
								 $i=1;
								 foreach ($fetchBokkingData as $fdb) { 
								  if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
								   $countofnog=0;
								   $paysucc=0;
								  $payfail=0;
								 $groupstname="";
								  $groupMyquery = $tutor_db->query("SELECT u.FIRST_NAME,u.LAST_NAME,s.TH_BOOKED_STATUS,s.PAYMENT_STATUS FROM tutor_hive_sendbuzz s INNER JOIN tutorhive_users u ON s.TH_SENDER = u.USER_ID WHERE s.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND s.SB_SSID=".$fdb['SB_SSID']." AND s.TH_REJECT_STATUS=1");
								$countofnog = $groupMyquery->rowCount();
								if($countofnog > 0) {
                                 $groupdetailsfch = $groupMyquery->fetchAll(PDO::FETCH_ASSOC);
								  foreach ($groupdetailsfch as $gdf) { 
								   $groupstname.=$gdf['FIRST_NAME']." ".$gdf['LAST_NAME']."<br>";
								   if($gdf['PAYMENT_STATUS']==1){
								   $paysucc++;
								   }else {
								   $payfail++;
								   }
									}
									$ttt=rtrim($groupstname, ', ');
									}
								  }
								 ?>
								 <ul class="nav nav-pills shadow flex-column flex-sm-row d-md-inline-flex mb-0 p-1 bg-white-color rounded position-relative overflow-hidden" style="border:1px solid #ebe8e8">
    <li class="py-2 active rounded">
                                            <div class="text-center">
                                                <img src="assets/images/hex.PNG" style="width:30%">
                                            </div>
                                    </li>
                                     <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>Group <?php echo $countofnog; ?>/6 <?php }else {?>1:1 Lessons <?php }  if($fdb['TH_TUTOR_METHOD']=="Intro Call"){ echo "Intro Call - FREE"; }else {?> - £<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".",""); }?> </h5>
                                            </div>
                                    </li><!--end nav item-->
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php echo $fdb['TH_BUZZ_SUBJECT']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                    
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center" style="float:right;">
                                                <h5 class="mb-0"><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?> <?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                </ul>
								<div class=""  style="padding: 20px 0px 20px 0px !important;">
<div class="row">
<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<a href="viewgroup_tutorreject1.php?uiddu=<?php echo $fdb['SB_SSID']; ?>&mymm=<?php echo $fdb['TH_BUZZ_MONTHS']; ?>" alt="Details" title="Details" class="btn btn-sm btn-primary" style="padding:0px 5px;font-size: 20px;border-radius: 50%;"><i class="mdi mdi-more" style="font-size:20px;"></i></a>
<?php }else { ?>
<a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)"  alt="More Details" title="More Details" class="btn btn-sm btn-primary" style="border-radius:50%; padding:0px 5px;"><i class="mdi mdi-account" style="font-size:20px;"></i></a>
<!--<a style="position : relative ;" href="messaged.php?ftimeid=<?php echo $fdb['TH_SENDER'] ?>"class="text-success"><img src="assets/images/chatd.png" alt="Chat" title="Chat" class="intimetabl"> </a>-->
<?php } ?>
</div>
<div class="col-lg-3" >
<p><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){echo $ttt; }else { echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME'];} ?></p>
</div>

<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['SB_SSID']!="" && $fdb['TH_BUZZ_DATE']>'2023-01-01'){?><a href="#" onClick="AgendaDetail1(<?php echo $fdb['SB_SSID'] ?>)" alt="Agenda" title="Agenda" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Agenda</a><?php } else { echo "No Agenda";} ?>
</div>

<div class="col-lg-3" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<a href="viewgroup_tutorreject1.php?uiddu=<?php echo $fdb['SB_SSID']; ?>&mymm=<?php echo $fdb['TH_BUZZ_MONTHS']; ?>"  alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;margin-left: 6px;">View group details</a>
<?php }else {?>
Rejected
<?php } ?>
</div>
<div class="col-lg-2" style="text-align:center;">
<?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>
<span style="color: #15b815;font-weight: 700;"><?php echo $paysucc; ?> Paid</span><br>
<span style="color: #fd440d;font-weight: 700;"><?php echo $payfail; ?> Unpaid</span>
<?php }else { 
 if($fdb['PAYMENT_STATUS']==1){?>
 <span style="color: #15b815;font-weight: 700;">Paid</span>
 <?php }else { ?>
 <span style="color: #fd440d;font-weight: 700;">Unpaid</span>
<?php }} ?>
</div>
</div>
</div>
<?php } ?>
</div>
<?php } else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Reported lessons</h4>
          </div>
<?php } exit;} ?>
<!doctype html>
<html lang="en" dir="ltr">

    <head>
        <meta charset="utf-8" />
        <title>TutorHive - Tutor Timetable </title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
        <meta name="description" content="Premium Bootstrap 5 Landing Page Template" />
        <meta name="keywords" content="Saas, Software, multi-uses, HTML, Clean, Modern" />
        <meta name="author" content="Shreethemes" />
        <meta name="email" content="support@shreethemes.in" />
        <meta name="website" content="https://shreethemes.in" />
        <meta name="Version" content="v4.2.0" />
        <script src="https://polyfill.io/v3/polyfill.min.js?features=default"></script>
        <?php include('common/headerlinks.php');?>
        <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
        <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.css">
        <link rel="stylesheet" href="./assets/OwlCarousel/dist/assets/owl.carousel.min.css">
        <link rel="stylesheet" href="./assets/OwlCarousel/dist/assets/owl.theme.default.min.css">
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <style>
           .buzzSet .avil{background:#ffd85d;color:#000;padding:10px;border-radius:10px;font-weight:900;border:2px solid #000;border-left:20px solid}.buzzSet .form-check .form-check-input{border:2px solid #0e0e0e}.buzzSet .avil h5{font-size:16px;display:flex;margin:0;align-items:center}.buzzSet .avil h5 span.mdi.mdi-teach{font-size:30px;margin-right:10px}.buzzSet .form-control{background:#ffd85d!important;border:2px solid #000;font-weight:900}.buzzSet .form-control:focus{border-color:#fff}.buzzSet{padding:20px}.userpop{position:relative}.closeBtnBuzz{background:0 0;font-size:25px;position:absolute;right:15px;color:#ffd85d;top:16px;font-weight:bolder;border:none}.closeBtn{background:0 0;font-size:25px;position:absolute;right:-10px;top:-10px;font-weight:bolder;border:none}.backBtnBuzz{background:0 0;font-size:25px;position:absolute;left:15px;color:#ffd85d;top:16px;font-weight:bolder;border:none}#finalBuzz .backBtnBuzz,#finalBuzz .closeBtnBuzz{color:#000}.modal-content{border-radius:30px;border:10px solid #ffd85d!important;box-shadow:0 0 30px 10px #484743}.profile-header{background:#ffd85d;padding:30px 10px;border-radius:10px 10px 0 0}.flatpickr-calendar.arrowTop:after,.flatpickr-calendar.arrowTop:before{border-bottom-color:#ffd85d}.bg-theme,.flatpickr-day selected,.flatpickr-time .flatpickr-am-pm,.flatpickr-time .flatpickr-time-separator,.flatpickr-time input{background-color:#ffd85d!important}.flatpickr-day.endRange,.flatpickr-day.endRange.inRange,.flatpickr-day.endRange.nextMonthDay,.flatpickr-day.endRange.prevMonthDay,.flatpickr-day.endRange:focus,.flatpickr-day.endRange:hover,.flatpickr-day.selected,.flatpickr-day.selected.inRange,.flatpickr-day.selected.nextMonthDay,.flatpickr-day.selected.prevMonthDay,.flatpickr-day.selected:focus,.flatpickr-day.selected:hover,.flatpickr-day.startRange,.flatpickr-day.startRange.inRange,.flatpickr-day.startRange.nextMonthDay,.flatpickr-day.startRange.prevMonthDay,.flatpickr-day.startRange:focus,.flatpickr-day.startRange:hover{background:#000;-webkit-box-shadow:none;box-shadow:none;color:#ffd85d;border-color:#000}.flatpickr-day.inRange,.flatpickr-day.nextMonthDay.inRange,.flatpickr-day.nextMonthDay.today.inRange,.flatpickr-day.nextMonthDay:focus,.flatpickr-day.nextMonthDay:hover,.flatpickr-day.prevMonthDay.inRange,.flatpickr-day.prevMonthDay.today.inRange,.flatpickr-day.prevMonthDay:focus,.flatpickr-day.prevMonthDay:hover,.flatpickr-day.today.inRange,.flatpickr-day.today:focus,.flatpickr-day.today:hover,.flatpickr-day:focus,.flatpickr-day:hover,flatpickr-day.today:hover{border-color:#000;background:#000;color:#ffd85d}.flatpickr-day.endRange,.flatpickr-day.endRange.inRange,.flatpickr-day.endRange.nextMonthDay,.flatpickr-day.endRange.prevMonthDay,.flatpickr-day.endRange:focus,.flatpickr-day.endRange:hover,.flatpickr-day.selected.inRange,.flatpickr-day.selected.nextMonthDay,.flatpickr-day.selected.prevMonthDay,.flatpickr-day.selected:focus,.flatpickr-day.selected:hover,.flatpickr-day.startRange,.flatpickr-day.startRange.inRange,.flatpickr-day.startRange.nextMonthDay,.flatpickr-day.startRange.prevMonthDay,.flatpickr-day.startRange:focus,.flatpickr-day.startRange:hover{background:#000!important;-webkit-box-shadow:none;box-shadow:none;color:#ffd85d;font-weight:900;border-color:#000}.flatpickr-calendar{background:#ffd85d}.flatpickr-day,.flatpickr-time .flatpickr-am-pm,.flatpickr-time input.flatpickr-minute,.flatpickr-time input.flatpickr-second,span.flatpickr-weekday{font-weight:900;color:#000}.border-theme{border-color:#ffd85d!important}.color-theme{color:#ffd85d!important}.profile-image{position:relative;display:flex;justify-content:center;min-height:100px}.profile-image>img{width:100px;height:100px;border-radius:50px!important;background:#ffd85d;box-shadow:0 0 5px #262521;padding:4px;position:absolute;top:-25px}.user-disc ul>span::marker{color:#ffd85d}.user-disc .bg-warning,.user-info .bg-warning{background-color:#ffd85d!important}#map{width:100%;height:650px}.userpop h5{margin:5px 0 0 0;font-size:16px}.mapCard{overflow:hidden;background:#ffd85d;border-radius:5px;padding:0 20px;text-align:center;margin-bottom:10px;}.gm-style .gm-style-iw-c{font-weight:900}.map-user-thumb{width:100px;height:100px;border-radius:50px!important;background:#ffd85d;box-shadow:0 0 5px #262521;padding:4px}@media (max-width:500px){.gm-style .gm-style-iw-c{width:100%}}.imgmun{height:30px;width:40px}.fltrthid{float:right}@media (max-width:767px){body{font-size:14px}.col-sm-6{width:50%}.col-xs-6{width:50%}.p-4{padding:5px!important}.col-sm-12{width:100%}.col-xs-12{width:100%}.mt-4{margin-top:.5rem!important}.imgmun{height:25px;width:30px}.ms-2{margin-left:0!important}.fltrthid{float:left}.munpad{padding-bottom:7px}.breadcrumb .breadcrumb-item{font-size:14px}}#mapCanvas{width:100%;height:650px}.hexa,.hexa div{margin:0 auto;transform-origin:50% 50%;overflow:hidden;width:115px;height:103px}.hex2>img{width:100%;height:100%}.hexa{transform:rotate(150deg)}.hex1{transform:rotate(-60deg)}.hex2{transform:rotate(-60deg)}#style-3::-webkit-scrollbar-track{border-radius:10px;-webkit-box-shadow:inset 0 0 3px rgba(0,0,0,.3);background-color:#f5f5f5}#style-3::-webkit-scrollbar{border-radius:10px;width:3px;height:8px;background-color:#f5f5f5}#style-3::-webkit-scrollbar-thumb{border-radius:10px;background-color:#ffd85d}::-webkit-scrollbar-track{border-radius:10px}::-webkit-scrollbar{border-radius:10px;width:10px;background-color:#f5f5f5}::-webkit-scrollbar-thumb{border-radius:10px;background-color:#ffd85d}.owl-nav{position:relative;bottom:150px;display:flex;justify-content:space-between;font-size:50px}@media (max-width:500px){.owl-nav{bottom:195px}}
        
        .select2 .select2-container .select2-container--default .select2-container--focus{width:-webkit-fill-available!important}.select2-container--default .select2-results__option--highlighted[aria-selected]{background-color:#ffd85d}.select2-container .select2-selection--single{height:42.5px!important;border-radius: 0px;}.select2-container--default .select2-selection--single .select2-selection__rendered{line-height:42.5px}.select2-container--default .select2-selection--single .select2-selection__arrow{height:42.5px}
        .select2-container--default .select2-selection--single , .select2-container--default .select2-search--dropdown .select2-search__field , .select2-dropdown{
            border-color:#ffd85d;
        }
        
        
        .timetable .timetable-header{
            min-height: 100px;
            background-color: #ffd85d;
            color: #000;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 3px 3px 0 0;
            margin-bottom: 10px;
        }
        .timetable .timetable-header > h3 {
            color:inherit;
            font-size:2rem;
            text-align:center;
        }
        
        .timetable .navigation > .nav {
            position: absolute;
            top: -25px;
            left: 1%;
            right: 1%;
            background-color: #ffe981;
            border-radius: 50px;
            box-shadow: 0px 1px 5px #c2c2c2;
            padding: 9px 0px;
            font-size: 16px;
        }
        
        .timetable .navigation .nav-pills .nav-link.active{
            background: #ffffff;
            color: #ffd85d!important;
            border-radius: 50px;
        }
        
       .timetable .navigation .nav-pills .nav-link {
           font-weight:bolder;
       }
        .page-wrapper .page-content .layout-specing{
            padding-top:70px !important;
        }
        
        .studentDetails {
            text-align:left;
            text-indent:0px;
        }
        @media (max-width: 767px) {
            .studentDetails {
                text-indent:0px;
            }
        }
		
			.form-control:disabled {
    background-color: #ffffff;
}
.btn-soft-primary {
    background-color: rgb(0 0 0)!important;
    border: 1px solid rgb(0 0 0)!important;
    color: #ffffff!important;
   
}
.btn-soft-primaryss {
    background-color: #000;
    border: 1px solid #000!important;
    color: #ffffff!important;
   
}
.btn-soft-primarynn {
    background-color: #fce7a6;
    border: 1px solid #fce7a6!important;
    color: #000!important;
   
}
.btn-soft-primary:hover {
    background-color: #ffd85d!important;
    border-color: #ffd85d!important;
    color: #000!important;
}

.rating { 
border: none;
float: left;
}
.rating > input { display: none; } 
.rating > label:before { 
margin: 0 5px;
font-size: 1.25em;
font-family: FontAwesome;
display: none;
content: "\f005";
}
.rating > .half:before { 
content: "\f089";
position: absolute;
}
.rating > label { 
color: #ddd; 
float: right; 
}
.rating > input:checked ~ label, 
.rating:not(:checked) > label:hover,  
.rating:not(:checked) > label:hover ~ label { color: #ffd85d;  }
.rating > input:checked + label:hover, 
.rating > input:checked ~ label:hover,
.rating > label:hover ~ input:checked ~ label, 
.rating > input:checked ~ label:hover ~ label { color: #ffd85d;  } 
  .rating1 { 
border: none;
float: left;
}
.rating1 > input { display: none; } 
.rating1 > label:before { 
margin: 0 5px;
font-size: 1.25em;
font-family: FontAwesome;
display: inline-block;
content: "\f005";
}
.rating1 > .half:before { 
content: "\f089";
position: absolute;
}
.rating1 > label { 
color: #ddd; 
float: right; 
}
.rating1 > input:checked ~ label  { color: #ffd85d;  }
.rating1 > label:hover ~ input:checked ~ label, 
.rating1 > input:checked ~ label:hover ~ label { color: #ffd85d;  }
.pb-10{
    padding-bottom: 12px !important;
}
.btn {
    padding: 2px 14px;
   
}
.intimetabl{
width:30px;
height:30px;
}

.fonsig{
font-size:20px;
}

@media (max-width: 767px) {
p {
   font-size: 12px;
}
.h6, h6 {
    font-size: 14px;
}
.h5, h5 {
    font-size: 16px;
}
.mt-4 {
    margin-top: 0.7rem!important;
}
.form-control {
    font-size: 12px;
    line-height: 18px;
}
.p-4 {
    padding: 1.0rem!important;
}
.p-3 {
    padding: 0.3rem!important;
}
th, td {
font-size:9px;
}
.btn-group-sm>.btn, .btn.btn-sm {
    padding: 2px 6px;
    font-size: 8px;
}
.preferdays label span {
    padding: 4px 8px;
    background: #ffd85d;
    color: #000;
    font-size: 12px;
    cursor: pointer;
    border-radius: 5px;
}
.timetable .timetable-header > h3 {
    font-size: 20px;
}
.timetable .navigation .nav-pills .nav-link.active {
    font-size: 14px;
}
.timetable .navigation .nav-pills .nav-link {
    font-size: 14px;
}
.mt-5 {
    margin-top: 1.5rem!important;
}
.table>:not(caption)>*>* {
    padding: 2px;
	}
	.mapCard {
   padding: 0px 0px;  
}
.py-2 {
     padding-top: 0rem!important; 
    padding-bottom: .5rem!important;
}
.btn {
    padding: 2px 4px;
    font-size: 10px;
}
.intimetabl{
width:12px;
height:12px;
}
.fonsig{
font-size:16px;
}
}
.ht{padding: 30px 0px 30px 60px;}
@media(max-width:991px){.ht{padding: 30px 0px 30px 0px;}}


@media (max-width: 1396px){
.page-wrapper.toggled .sidebar-wrapper {
    left: -300px!important;
}
.page-wrapper.toggled .top-header {
    left: 0!important;
}
.page-wrapper .page-content .top-header .header-bar .logo-icon {
    display: block!important;
}
.page-wrapper .page-content .top-header .header-bar .logo-icon .big {
    display: block!important;
}
.page-wrapper.toggled .page-content {
    padding-left: 0px!important;
}
}

@media (max-width: 767px){
.page-wrapper .page-content .top-header .header-bar .logo-icon .small {
    display: none!important;
}
}

@media screen and (min-width: 1396px){
.page-wrapper.toggled .page-content {
    padding-left: 300px!important;
}
}

@media (max-width: 1275px) {
.noteicond{
width:20px;
height:20px;}
.form-check-label, .form-label {
    font-weight: 700;
    font-size: 12px;
}
}
@media (max-width: 1111px) {
.noteicond{
width:16px!important;
height:16px!important;}
.form-check-label, .form-label {
    font-weight: 700;
    font-size: 10px!important;
}
}
@media (max-width: 1486px) {
    .nk1{
        font-size:14px;
    }
}
@media (max-width: 1485px) {
    .nk1{
        font-size:12px;
    }
}
@media (max-width: 1295px) {
    .nk2{
        font-size:12px;
    }
}


        </style>

    </head>

    <body>

        <div class="page-wrapper toggled">
             <?php include('common/leftmenu.php');?>

            <main class="page-content bg-light">
                 <?php  include('common/header.php');?>
                <div>
                    <div class="layout-specing">
                        <div class="row justify-content-center align-items-center">
                            <div class="col col-md-12 ">
                                <div class="card">
                                    <div class="card-body card-body pt-0 px-0">
                                        <div class="timetable">
                                            <div class="timetable-header">
                                                 <h3 id="timetable-title">New Booking Requests</h3>
                                            </div>
                                            <div class="navigation position-relative">
                                                <ul class="nav nav-pills justify-content-center">
                                                   <!-- <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('avil-tab','avil','Set Availability')" id="avil-tab" data-bs-toggle="tab" data-bs-target="#avil" type="button" role="tab" >Availability</button>
                                                    </li>-->
                                                    <li class="nav-item">
                                                        <button class="nav-link active" onClick="tabclick('Request')" id="request-tab" data-bs-toggle="tab" data-bs-target="#request" type="button" role="tab">Requests</button>
                                                    </li>
                                                    <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('Booked')" id="booked-tab" data-bs-toggle="tab" data-bs-target="#booked" type="button" role="tab">Booked</button>
                                                    </li>
                                                    <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('Cancelled')" id="cancelled-tab" data-bs-toggle="tab" data-bs-target="#cancelled" type="button" role="tab">Cancelled</button>
                                                    </li>
                                                    <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('Completed')" id="completed-tab" data-bs-toggle="tab" data-bs-target="#completed" type="button" role="tab">Completed</button>
                                                    </li>
                                                    <li class="nav-item">
                                                        <button class="nav-link" onClick="tabclick('Rejected')" id="reported-tab" data-bs-toggle="tab" data-bs-target="#reported" type="button" role="tab">Rejected</button>
                                                    </li>
                                                </ul>
                                            </div>
                                            <div class="tab-content mt-5 p-2" id="myTabContent">
                                                <div class="tab-pane fade active show" id="request" role="tabpanel" aria-labelledby="request-tab" style="max-width: fit-content;margin: auto;">
												<div id="RequestDisp" class="my-3">
												  <?php 
													   $pagination_fetch111 = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_BOOKED_STATUS!=1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 AND TH_BUZZ_MONTHS>='$tutor_date122' ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");	
$totalMonths1 = $pagination_fetch111->fetch();								  												  
													   $pagination_fetch = $tutor_db->query("SELECT DISTINCT `TH_BUZZ_MONTHS` FROM `tutor_hive_sendbuzz` WHERE TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND TH_STATUS = 1 AND TH_BOOKED_STATUS!=1 AND TH_TUTOR_CANCEL_STATUS!=1 AND TH_TUTOR_COMPLETED_STATUS!=1 AND TH_STUDENT_CANCEL_STATUS!=1 AND TH_STUDENT_COMPLETED_STATUS!=1 AND TH_REJECT_STATUS!=1 AND UNPAID_CANCELLED!=1 ORDER BY TH_BUZZ_DATE,TH_BUZZ_START_TIME ASC");
	$total_rows = $pagination_fetch->rowCount();
    $totalMonths = $pagination_fetch->fetchAll(PDO::FETCH_ASSOC);
   // $selMonth = (!isset($_GET['my']) && empty($_GET['my'])) ? $totalMonths[0]['TH_BUZZ_MONTHS'] : $_GET['my'];
  if($_GET['page']=="request" && $_GET['my']!=""){
  $selMonth =$_GET['my'];
 } else if ($totalMonths1['TH_BUZZ_MONTHS']!=""){
 $selMonth =$totalMonths1['TH_BUZZ_MONTHS'];
  }else {
 $selMonth =$totalMonths[0]['TH_BUZZ_MONTHS'];
  }
													  $prepMyquery = $tutor_db->query("SELECT
                                        b.USER_TYPE,
                                        b.FIRST_NAME,
                                        b.LAST_NAME,
                                        b.PROFILE_PIC,
                                        a.TH_BUZZ_DATE,
										a.TH_BUZZ_MONTHS,
                                        a.TH_BUZZ_START_TIME,
                                        a.TH_BUZZ_END_TIME,
                                        a.TH_BUZZ_SUBJECT,
                                        a.TH_BUZZ_LESSION_TYPE,
                                        a.TH_BUZZ_LEVEL,
                                        a.TH_TUTOR_METHOD,
                                        a.TH_TOTAL_PRICE,
										a.TH_BUZZ_ID,
                                        a.TH_ISPRICE_PAY,
										a.TH_BOOKED_STATUS,
										a.PAYMENT_STATUS,
										a.TH_BUZZ_REGDATE,
										a.TH_RECEIVER,
										a.TH_SENDER,
										a.SB_SSID,
										a.TH_AGENDA,
										a.GROUP_ID,
										a.SB_SSID,
										a.MEETING_LINK,
										a.START_URL
                                    FROM
                                        tutor_hive_sendbuzz a
                                    INNER JOIN tutorhive_users b ON
                                        a.TH_SENDER = b.USER_ID
                                    WHERE
                                        a.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND a.TH_BUZZ_MONTHS ='$selMonth' AND a.TH_STATUS = 1 AND a.TH_BOOKED_STATUS!=1 AND a.TH_TUTOR_CANCEL_STATUS!=1 AND a.TH_TUTOR_COMPLETED_STATUS!=1 AND a.TH_STUDENT_CANCEL_STATUS!=1 AND a.TH_STUDENT_COMPLETED_STATUS!=1 AND a.TH_REJECT_STATUS!=1 AND a.UNPAID_CANCELLED!=1 GROUP BY a.GROUP_ID ORDER BY a.TH_BUZZ_DATE,a.TH_BUZZ_START_TIME ASC");
        $bokingsCount = $prepMyquery->rowCount();
    
    if($bokingsCount > 0) {
        $fetchBokkingData = $prepMyquery->fetchAll(PDO::FETCH_ASSOC);
    // echo $bokingsCount;   
    ?>
	<div style="text-align:center;">
                                        <?php
                                            if((int)$total_rows>0) {
                                            $col=9;
                                           
                                            foreach($totalMonths as $tm) {
                                        ?>
                                            <a href="?page=request&my=<?php echo $tm['TH_BUZZ_MONTHS']; ?>" <?php if($selMonth==$tm['TH_BUZZ_MONTHS']) { ?> class="btn btn-soft-primary"<?php }else { ?> class="btn btn-primary" <?php } ?>><?php echo date_format(date_create($tm['TH_BUZZ_MONTHS']."-01"),"F"); ?></a>
                                        <?php  $col-=2; } } ?>
                                    </div>
<div class="col-12 mt-3  card border-0 fade show active p-3 rounded shadow">
  <?php 
								 $i=1;
								
								 foreach ($fetchBokkingData as $fdb) { 
								  if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){ 
								  $groupMyquery = $tutor_db->query("SELECT u.FIRST_NAME,u.LAST_NAME,s.TH_BOOKED_STATUS,s.PAYMENT_STATUS,s.TH_BUZZ_ID,s.TH_SENDER FROM tutor_hive_sendbuzz s INNER JOIN tutorhive_users u ON s.TH_SENDER = u.USER_ID WHERE s.TH_RECEIVER =".$_SESSION['tutor_admin_id']." AND s.SB_SSID=".$fdb['SB_SSID']." AND s.TH_BOOKED_STATUS=0 AND s.TH_REJECT_STATUS=0 AND s.TH_TUTOR_CANCEL_STATUS=0 AND s.TH_STUDENT_CANCEL_STATUS=0 AND s.UNPAID_CANCELLED=0 AND s.TH_TUTOR_COMPLETED_STATUS=0 AND s.TH_STUDENT_COMPLETED_STATUS=0");
$countofnog =0;								  
$countofnog = $groupMyquery->rowCount();
}?>
<ul class="nav nav-pills shadow flex-column flex-sm-row d-md-inline-flex mb-0 p-1 bg-white-color rounded position-relative overflow-hidden" style="border:1px solid #ebe8e8">
    <li class="py-2 active rounded d-lg-block d-md-none d-none">
                                            <div class="text-center">
                                                <img src="assets/images/hex.PNG" style="width:30%">
                                            </div>
                                    </li>
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){?>Group Lessons<?php }else {?>1:1 Lessons <?php } ?> <?php if($fdb['TH_TUTOR_METHOD']=="Intro Call"){ echo "Intro Call - FREE"; }else {?> - £<?php echo number_format($fdb['TH_TOTAL_PRICE'],2,".",""); }?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center">
                                                <h5 class="mb-0"><?php echo $fdb['TH_BUZZ_SUBJECT']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                    
                                    <li class="py-2 px-5 active rounded">
                                            <div class="text-center" style="float:right;">
                                                <h5 class="mb-0"><?php echo date_format(date_create($fdb['TH_BUZZ_DATE']),"D  dS M Y");?> <?php echo $fdb['TH_BUZZ_START_TIME']?> - <?php echo $fdb['TH_BUZZ_END_TIME']?></h5>
                                            </div>
                                    </li><!--end nav item-->
                                </ul>
<div class="ht" >
 <?php if($fdb['TH_BUZZ_LESSION_TYPE']=="Group"){
  if((int)$countofnog>0){
 $groupdetailsfch = $groupMyquery->fetchAll(PDO::FETCH_ASSOC);
  foreach ($groupdetailsfch as $gdf) { ?>
<div class="row">
<div class="col-2"><a href="#" onClick="MoreDetails(<?php echo $gdf['TH_BUZZ_ID'] ?>)"  alt="More Details" title="More Details" class="btn btn-sm btn-primary" style="border-radius:50%; padding:0px 5px;"><i class="mdi mdi-account" style="font-size:20px;"></i></a></div>
<div class="col-3"><p><?php echo $gdf['FIRST_NAME']." ".$gdf['LAST_NAME']; ?></p></div>
<div class="col-1">
<a href="" alt="message" title="message" class="btn btn-sm btn-primary" style="padding:0px 5px;font-size: 20px;border-radius: 50%;"><i class="mdi mdi-email" ></i></a>
</div>
<div class="col-2"></div>
<div class="col-4"><a onClick="acceptBuss(<?php echo $gdf['TH_BUZZ_ID'] ?>)" alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Accept</a>
<a onClick="rejectBuss(<?php echo $gdf['TH_BUZZ_ID'] ?>)" alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Reject</a></div>
</div>
<?php } }}else { ?>
<div class="row">
<div class="col-2"><a href="#" onClick="MoreDetails(<?php echo $fdb['TH_BUZZ_ID'] ?>)"  alt="More Details" title="More Details" class="btn btn-sm btn-primary" style="border-radius:50%; padding:0px 5px;"><i class="mdi mdi-account" style="font-size:20px;"></i></a></div>
<div class="col-3"><p><?php echo $fdb['FIRST_NAME']." ".$fdb['LAST_NAME']; ?></p></div>
<div class="col-1">
<?php $gid = $fdb['GROUP_ID'];
						        $chatCount = $tutor_db->query("SELECT COUNT(`GROUP_ID`) as chatcount FROM `buzz_chat_internal` WHERE `GROUP_ID`='$gid'")->fetch(PDO::FETCH_ASSOC);
						
						?>
						<a style="position : relative ;" href="#" onClick="chatShow('<?php echo $fdb['TH_BUZZ_ID'] ?>')" class="text-success">
						    <img src="assets/images/chatd.png"  alt="Chat" title="Chat" class="intimetabl" /> 
						    <span style="font-size: 12px;padding: 1px 5px;border-radius: 50%;background: #000;position: absolute;right: 0;"><?php echo $chatCount['chatcount'] ?></span>
						    </a>
</div>
<div class="col-2"></div>
<div class="col-4"><a onClick="acceptBuss(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Accept</a>
<a onClick="rejectBuss(<?php echo $fdb['TH_BUZZ_ID'] ?>)" alt="View Group Datails" title="View Group Datails" class="btn btn-sm btn-primary" style="padding:3px 10px;font-size: 14px;">Reject</a></div>
</div>
<?php } ?>
</div>
<?php } ?>
</div>
<?php } else { ?>
          <div class="mapCard">
              <h4 class="text-center m-0 fs-3 py-3">No Request lessons</h4>
          </div>
<?php } ?>  
</div>                                           
                                              </div>
				<div class="tab-pane fade" id="booked" role="tabpanel" aria-labelledby="booked-tab" style="max-width: fit-content;margin: auto;">
				 <div id="BookingsDisp" class="my-3"></div>						  
                </div>
				<div class="tab-pane fade" id="cancelled" role="tabpanel" aria-labelledby="cancelled-tab" style="max-width: fit-content;margin: auto;">
				<div id="CancelDisp" class="my-3"></div>									  
                </div>
				<div class="tab-pane fade" id="completed" role="tabpanel" aria-labelledby="completed-tab" style="max-width: fit-content;margin: auto;">
				 <div id="completedDisp" class="my-3"></div>									  
                </div>
				<div class="tab-pane fade" id="reported" role="tabpanel" aria-labelledby="reported-tab" style="max-width: fit-content;margin: auto;">
				  <div id="reportedDesp" class="my-3"></div>								  
                </div>
                                         
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
				<a href="javascript:void(0)"id="requestres1"  onClick="requestfunf1()" style="display:none"> Click Here1</a>	
				<a href="javascript:void(0)"id="requestres2"  onClick="requestfunf2()" style="display:none"> Click Here1</a>
				<a href="javascript:void(0)"id="requestres3"  onClick="requestfunf3()" style="display:none"> Click Here1</a>
				<a href="javascript:void(0)"id="requestres4"  onClick="requestfunf4()" style="display:none"> Click Here1</a>
				<a href="javascript:void(0)"id="requestres5"  onClick="requestfunf5()" style="display:none"> Click Here1</a>
					
                    
                <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#LoginForm" id="ClickModal" class="btn btn-primary m-1" style="display:none"> Click Here</a>
				 <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#acceptForm" id="ClickModal1" class="btn btn-primary m-1" style="display:none"> Click Here</a>
				 <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#ajandaForm" id="ClickModal2" class="btn btn-primary m-1" style="display:none"> Click Here</a>
				 <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#reviwForm" id="ClickModal4" class="btn btn-primary m-1" style="display:none"> Click Here</a>
				 <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#waitLoader" id="openloader" class="btn btn-primary m-1" style="display:none"> Click Here</a>
				  <a href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#updateLink" id="ClickModa333" class="btn btn-primary m-1" style="display:none"> Click Here</a>
				 
               
                <!-- loaderModal -->
               <div class="modal fade" id="waitLoader" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="display: none;">
                  <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                      <div class="modal-body text-center color-theme">
                        <h4>Loading <i class="mdi mdi-spin mdi-loading"></i></h4>
                      </div>
                    </div>
                  </div>
                </div>
                
                <!--Content Modal-->
                <div class="modal " id="contentModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                  <div class="modal-dialog modal-dialog-centered" style="max-width:650px">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h6 class="modal-title fw-bold">Buzz Chat <br> <small class="text-black-50 fw-normal fs-6 ">( Note : Allowed only 50 conversations )</small> </h6>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><span class="mdi mdi-close-thick"></span></button>
                            
                        </div>
                        <div class="modal-body color-theme" id="contentDiv">
                            <h5>Loading your chat , please wait <i class="mdi mdi-spin mdi-loading"></i></h5>
                        </div>
                    </div>
                  </div>
                </div>
                
               <footer class="shadow  d-flex align-items-center justify-content-center">
                    <div class="container">
                        <div class="row ">
                            <div class="col-12 ">
                                <p class="mb-0 text-center">Copyright © 2022 TutorHive. All Rights Reserved</p>
                            </div>
                        </div>
                    </div>
                </footer>
            </main>
        </div>
		
		<div class="modal fade" id="acceptForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                          <div id="Ajaxidapi1"></div> 
                                        </div>
                                    </div>
      
	   <div class="modal fade" id="LoginForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                         <div id="Ajaxidapi"></div>  
                                        </div>
                                    </div>
									
									 <div class="modal fade" id="updateLink" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                         <div id="Ajaxidapi333"></div>  
                                        </div>
                                    </div>
									
									<div class="modal fade" id="ajandaForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                          <div id="Ajaxidapi2"></div> 
                                        </div>
                                    </div>
									
									<div class="modal fade" id="reviwForm" tabindex="-1" aria-labelledby="LoginForm-title" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered">
                                         <div id="Ajaxidapi4"></div>  
                                        </div>
                                    </div>
	  
		 <?php include('common/footerlinks.php');?>
		 <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
		 <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
		 <script src="./assets/OwlCarousel/dist/owl.carousel.min.js"></script>
		 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-confirm/3.3.2/jquery-confirm.min.js"></script>
		 
		 
		 <?php if($_GET['page']=='booked'){?>
			            <script>
						$(document).ready(function(){
			            document.getElementById("booked-tab").click();
						});
			            </script>
	 <?php } if($_GET['page']=='canceled'){?>
			            <script>
						$(document).ready(function(){
			            document.getElementById("cancelled-tab").click();
						});
			            </script>
			  <?php } if($_GET['page']=='completed'){?>
			   <script>
						$(document).ready(function(){
			            document.getElementById("completed-tab").click();
						});
			            </script>
						<?php } if($_GET['page']=='reported'){?>
			   <script>
						$(document).ready(function(){
			            document.getElementById("reported-tab").click();
						});
			            </script>
			  <?php }  ?>	
	
       <script>
function tabclick(val){ 
if(val=="Request"){
document.getElementById("timetable-title").innerHTML= "New Booking Requests";
document.getElementById("requestres1").click();
}else if(val=="Booked"){
document.getElementById("timetable-title").innerHTML= val;
document.getElementById("requestres2").click();
}else if(val=="Cancelled"){
document.getElementById("timetable-title").innerHTML= val;
document.getElementById("requestres3").click();
}else if(val=="Completed"){
document.getElementById("timetable-title").innerHTML= val;
document.getElementById("requestres4").click();
}else if(val=="Rejected"){
document.getElementById("timetable-title").innerHTML= val;
document.getElementById("requestres5").click();
}
}	

function Linkupdate(val){
  //  alert(val);
var dataString333 = 'buzzid='+ val;
//alert(dataString333);
$.ajax
		({
		type: "POST",
		url: "ajax_updatelinkui.php",
		data: dataString333,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModa333").click();
		document.getElementById("Ajaxidapi333").innerHTML = data;
		}
			});
}	

function AgendaDetail(val){
  //  alert(val);
var dataString = 'buzzid='+ val;
//alert(dataString)
$.ajax
		({
		type: "POST",
		url: "ajax_Agendadetails1.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal2").click();
		document.getElementById("Ajaxidapi2").innerHTML = data;
		}
			});
}

function AgendaDetail1(val){
  //  alert(val);
var dataString = 'buzzid='+ val;
//alert(dataString)
$.ajax
		({
		type: "POST",
		url: "ajax_Agendadetails.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal2").click();
		document.getElementById("Ajaxidapi2").innerHTML = data;
		}
			});
}

function getAgenda(){
 var agendaedit = $('#agendaedit').val();
 var editnoaganda = $('#editnoaganda').val();
  if(agendaedit==""){
         alert("Please enter agenda");
          agendaedit.focus();
           return false; 
          }
//alert(agendaedit);
// alert(editnoaganda); 
 
 var dataString111 = 'agendaedit='+ agendaedit +'&editnoaganda='+editnoaganda;
//	alert(dataString111);
	$.ajax
		({
		type: "POST",
		url: "ajax_editagendgroupset.php",
		data: dataString111,
		cache: false,
		success: function(data)
		{
		//alert(data)
		if(data==1){
		location.reload()
		}else{
		alert("something went wrong please try again");
		}
		}
	});
}	

function MoreDetails(val){
  //  alert(val);
var dataString = 'buzzid='+ val;
//alert(dataString)
$.ajax
		({
		type: "POST",
		url: "ajax_buzzdetails.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal").click();
		document.getElementById("Ajaxidapi").innerHTML = data;
		}
			});
}

function Acceptotrect(val){
  //  alert(val);
var dataString = 'acceptid='+ val;
//alert(dataString)
$.ajax
		({
		type: "POST",
		url: "ajax_buzzaccept.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal1").click();
		document.getElementById("Ajaxidapi1").innerHTML = data;
		}
			});
}



function delclass(val){
   // alert(val);
   if(confirm("Are you sure you would like to cancel this lesson?"))
{
var type= "Cancel";
	var dataString = 'bussid='+ val +'&type='+type;
	//alert(dataString);
	document.getElementById("openloader").click();
	$.ajax
		({
		type: "POST",
		url: "ajax_buesschnage.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
			if(data=="Api Error"){
		alert("APIs went wrong please try again");
		location.reload()
		}else if(data!=""){
		document.location.href='tutor_timetable?page=booked&my='+data;
		}else{
		alert("something went wrong please try again");
		location.reload()
		}
		}
			});
}
}

 function acceptBuss(val){
    //alert(val);
	var acttyprless = $('#acttyprless').val();
	//alert(acttyprless)
	if(acttyprless === "Intro Call "){
	var contype="Are you sure you would like to accept this intro call?";
//	alert("test");
	}else{
	var contype="Are you sure you would like to accept this lesson?";
	//alert("test12");
	}
	
if(confirm(contype))
{
var type= "Accept";
	var dataString = 'bussid='+ val +'&type='+type ;
	//alert(dataString);
   	document.getElementById("openloader").click();
	$.ajax
		({
		type: "POST",
		url: "ajax_buesschnage.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
	//alert(data)
		if(data=="Api Error"){
		alert("APIs went wrong please try again");
			location.reload()
		}else if(data=="Same"){
		alert("Tutor and student emails same please check");
			location.reload()
		}else if(data!=""){
		document.location.href='tutor_timetable?page=request&my='+data;
		}else{
		alert("something went wrong please try again");
			location.reload()
		}
		}
			});
			}
}

 function rejectBuss(val){
   //alert(val);
if(confirm("Are you sure you would like to reject this lesson? "))
{
var type= "Reject";
	var dataString = 'bussid='+ val +'&type='+type;
	//alert(dataString);
	$.ajax
		({
		type: "POST",
		url: "ajax_buesschnage.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		if(data!=""){
		document.location.href='tutor_timetable?page=request&my='+data;
		}else{
		alert("something went wrong please try again");
		location.reload()
		}
		}
			});
			}
}

function Compclass(val){
   // alert(val);
    if(confirm("Are you sure you want to mark this lesson as complete?"))
{
var type= "Completed";
	var dataString = 'bussid='+ val +'&type='+type;
	//alert(dataString);
		document.getElementById("openloader").click();
	$.ajax
		({
		type: "POST",
		url: "ajax_buesschnage.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
			if(data=="Api Error"){
		alert("APIs went wrong please try again");
			location.reload()
		}else if(data!=""){
		document.location.href='tutor_timetable?page=booked&my='+data;
		}else{
		alert("something went wrong please try again");
			location.reload()
		}
		}
			});
}
}

function Getclassurl(val){
var type= "Joinclass";
	var dataString = 'bussid='+ val +'&type='+type;
	//alert(dataString);
	$.ajax
		({
		type: "POST",
		url: "ajax_buesschnage.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		if(data=="Api Error"){
		alert("APIs went wrong please try again");
		}else if(data==101){
		alert("something went wrong please try again");
		}else if(data!=""){
		   window.open(data, '_blank');
		}else{
		alert("something went wrong please try again");
		}
		}
			});
}

 function Reviewbuss(val){
   // alert(val);
  
var dataString = 'buss_id='+ val;
$.ajax
		({
		type: "POST",
		url: "ajax_tutorreview.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
		//alert(data)
		document.getElementById("ClickModal4").click();
		document.getElementById("Ajaxidapi4").innerHTML = data;
		}
			});
}

function addreviewBuss(){
var type="TRS"
 if($('#star5').is(':checked')==true){
 var rateing=$("#star5").val();
 }else if ($('#star4').is(':checked')==true){
  var rateing=$("#star4").val();
 }else if ($('#star3').is(':checked')==true){
  var rateing=$("#star3").val();
 }else if ($('#star2').is(':checked')==true){
  var rateing=$("#star2").val();
 }else if ($('#star1').is(':checked')==true){
  var rateing=$("#star1").val();
  }
  var reviewss = $("#reviewss").val();
   var bussid = $("#bussid").val();
   if(rateing == "" || rateing == undefined)
	{
		alert("Please Enter Your Rating");
		rating.focus();
		return false;
	}
	if(reviewss == "")
	{
		alert("Please Enter Your Review");
		review.focus();
		return false;
	}
   	var dataString = 'reviewss='+ reviewss+'&rateing='+ rateing+'&bussid='+ bussid+'&type='+ type;
   //	alert(dataString)
   $.ajax
		({
		type: "POST",
		url: "ajax_bussreviews.php",
		data: dataString,
		cache: false,
		success: function(data)
		{
	//	alert(data)
		if(data!=""){
		alert("Your feedback details have been saved"); 
		document.location.href='tutor_timetable?page=completed&my='+data;
		}else {
		alert("Something went wrong please try again");
		document.getElementById("close-modal").click();
		}
		}
			});
   
   
  }
  </script>
  <script>
function requestfunf1(){              
var searchDate = "Yes"
//alert(searchDate);
if(searchDate==="" || searchDate===null || searchDate===undefined) {
$.alert({
type:"red",
title:false,
content : "Please select date."
});
} else {
var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
$.ajax({
type: "post",
data: "requestthis&searchDate="+searchDate,
beforeSend() {
// b.show();
},
success(e) {
$("body").removeAttr("style"), $("#RequestDisp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
},
});
}
}
</script>
<script>
 function requestfunf2(){    
                    var searchDate = "Yes"
					//alert(searchDate);
                    if(searchDate==="" || searchDate===null || searchDate===undefined) {
                        $.alert({
                           type:"red",
                           title:false,
                           content : "Please select date."
                        });
                    } else {
                        var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
                        $.ajax({
                            type: "post",
                            data: "mybookingthis&searchDate="+searchDate,
                            beforeSend() {
                               // b.show();
                            },
                            success(e) {
                                $("body").removeAttr("style"), $("#BookingsDisp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
                            },
                    });
                    }
                    }
			  </script>
			  <script>
                function requestfunf3(){    
                     let searchDate = "Yes"
                    if(searchDate==="" || searchDate===null || searchDate===undefined) {
                        $.alert({
                           type:"red",
                           title:false,
                           content : "Please select date."
                        });
                    } else {
                        var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
                        $.ajax({
                            type: "post",
                            data: "bookingsCanceled&searchDate="+searchDate,
                            beforeSend() {
                               // b.show();
                            },
                            success(e) {
                                $("body").removeAttr("style"), $("#CancelDisp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
                            },
                    });
                    }
                    }
				</script>
				<script>
                function requestfunf4(){  
                     let searchDate = "Yes"
                    if(searchDate==="" || searchDate===null || searchDate===undefined) {
                        $.alert({
                           type:"red",
                           title:false,
                           content : "Please select date."
                        });
                    } else {
                        var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
                        $.ajax({
                            type: "post",
                            data: "lessioncompleted&searchDate="+searchDate,
                            beforeSend() {
                               // b.show();
                            },
                            success(e) {
                                $("body").removeAttr("style"), $("#completedDisp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
                            },
                    });
                    }
                }
				</script>
				<script>
                function requestfunf5(){  
                     let searchDate = "Yes"
                    if(searchDate==="" || searchDate===null || searchDate===undefined) {
                        $.alert({
                           type:"red",
                           title:false,
                           content : "Please select date."
                        });
                    } else {
                        var b = new bootstrap.Modal(document.getElementById("waitLoader"), { keyboard: !1 });
                        $.ajax({
                            type: "post",
                            data: "reportedLession&searchDate="+searchDate,
                            beforeSend() {
                               // b.show();
                            },
                            success(e) {
                                $("body").removeAttr("style"), $("#reportedDesp").html(e), $("#waitLoader").css("display", "none"), $("#waitLoader").removeClass("show"), $(".modal-backdrop.fade.show").remove();
                            },
                    });
                    }
                }
				</script>
				<script>
                
                var myModal = new bootstrap.Modal(document.getElementById("contentModal"), { keyboard: !1 });
                function chatShow(a) {
                    $.ajax({
                        type: "post",
                        url: "./buzz_chat_internal.php",
                        data: { chatPopUp: "", UID: a },
                        beforeSend: function () {
                            myModal.show();
                        },
                        success: function (a) {
                            if ("" !== a && null != a) {
                                $("#contentDiv").html(a);
                                let b = document.getElementById("chatmsgsCont");
                                b.scrollTop = b.scrollHeight;
                            } else $("#contentDiv").html("<h5>Opps! Somthing went wrong.</h5>");
                        },
                    });
                }
                function sendMessage(b) {
                    var a = $("#idevChatInp").val().trim();
                    a.length < 1
                        ? ($("#idevChatInp").focus(), $.alert({ type: "orange", title: !1, content: "Please enter message" }))
                        : a.length > 300
                        ? ($("#idevChatInp").focus(), $.alert({ type: "orange", title: !1, content: "you are not allowed to enter more then 300 characters" }))
                        : $.ajax({
                              type: "post",
                              url: "./buzz_chat_internal.php",
                              dataType: "JSON",
                              data: { sendMsg: "", gid: b, msg: a },
                              beforeSend: function () {
                                  $("#sendMsgButton").prop("disabled", !0), $("#sendMsgButton").html("Sendnig <i class='mdi mdi-spin mdi-loading'></i>");
                              },
                              success: function (a) {
                                  if (1 == a.save) {
                                      $("#idevChatInp").val(""),
                                          $("#idevChatInp").focus(),
                                          $("#sendMsgButton").prop("disabled", !1),
                                          $("#sendMsgButton").html("Send Message"),
                                          $("#chatmsgsCont").html(a.html),
                                          a.totalMsgs >= 50 &&
                                              $("#sbtn").html(`<div class="alert bg-soft-danger fw-medium" role="alert"><i class="uil uil-exclamation-octagon fs-5 align-middle me-1"></i> Hey, sorry you’ve reached your
                                                                    maximum number of messages in this channel and won’t
                                                                    be able to send any more</div>`);
                                      let b = document.getElementById("chatmsgsCont");
                                      b.scrollTop = b.scrollHeight;
                                  } else {
                                      $("#sendMsgButton").prop("disabled", !1), $("#sendMsgButton").html("Send Message"), $.alert({ type: "orange", title: !1, content: "Message not sent. Somthing went wrong!" });
                                      let c = document.getElementById("chatmsgsCont");
                                      c.scrollTop = c.scrollHeight;
                                  }
                              },
                          });
                }
                $(".btn-close").click(() => {
                    $("#contentDiv").html('<h5>Loading your chat , please wait <i class="mdi mdi-spin mdi-loading"></i></h5>'), myModal.hide();
                });


        </script>	
    </body>

</html>
<?php mysqli_close($tutor_db);?>